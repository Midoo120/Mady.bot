/**
 * 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ - WhatsApp Bot
 * حقوق النشر © 2024
 * 
 * البوت ده متاح للتعديل والتطوير تحت رخصة MIT.
 * 
 * ✦ شكر خاص:
 * - مكتبة Baileys
 * - نظام Pair Code المطوّر
 */

require('./settings')
const { Boom } = require('@hapi/boom')
const fs = require('fs')
const chalk = require('chalk')
const FileType = require('file-type')
const path = require('path')
const axios = require('axios')
const { handleMessages, handleGroupParticipantUpdate, handleStatus } = require('./main');
const PhoneNumber = require('awesome-phonenumber')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif')

/* ✅ تم حذف await من هنا */
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetch, sleep, reSize } = require('./lib/myfunc')

const {
default: makeWASocket,
useMultiFileAuthState,
DisconnectReason,
fetchLatestBaileysVersion,
generateForwardMessageContent,
prepareWAMessageMedia,
generateWAMessageFromContent,
generateMessageID,
downloadContentFromMessage,
jidDecode,
proto,
jidNormalizedUser,
makeCacheableSignalKeyStore,
delay
} = require("@whiskeysockets/baileys")

const NodeCache = require("node-cache")
const pino = require("pino")
const readline = require("readline")

const store = require('./lib/lightweight_store')
store.readFromFile()

const settings = require('./settings')
setInterval(() => store.writeToFile(), settings.storeWriteInterval || 10000)

/* 🧹 تنظيف الرام */
setInterval(() => {
if (global.gc) {
global.gc()
console.log('🧹 تم تنظيف الرام بنجاح')
}
}, 60000)

/* ⚠️ مراقبة استهلاك الرام */
setInterval(() => {
const used = process.memoryUsage().rss / 1024 / 1024
if (used > 400) {
console.log('⚠️ الرام عليت جامد… البوت هيعمل ريستارت!')
process.exit(1)
}
}, 30000)

let phoneNumber = "201274340933"
let owner = JSON.parse(fs.readFileSync('./data/owner.json'))

/* اسم البوت */
global.botname = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬"
global.themeemoji = "✦"

const pairingCode = !!phoneNumber || process.argv.includes("--pairing-code")

const rl = process.stdin.isTTY ? readline.createInterface({ input: process.stdin, output: process.stdout }) : null

const question = (text) => {
if (rl) {
return new Promise((resolve) => rl.question(text, resolve))
} else {
return Promise.resolve(settings.ownerNumber || phoneNumber)
}
}

async function startXeonBotInc() {
try {

let { version } = await fetchLatestBaileysVersion()
const { state, saveCreds } = await useMultiFileAuthState("./session")
const msgRetryCounterCache = new NodeCache()

const XeonBotInc = makeWASocket({
version,
logger: pino({ level: 'silent' }),
printQRInTerminal: !pairingCode,
browser: ["Ubuntu","Chrome","20.0.04"],
auth: {
creds: state.creds,
keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }))
},
markOnlineOnConnect: true,
generateHighQualityLinkPreview: true,
syncFullHistory: false,
msgRetryCounterCache
})

XeonBotInc.ev.on('creds.update', saveCreds)

store.bind(XeonBotInc.ev)

/* استقبال الرسائل */
XeonBotInc.ev.on('messages.upsert', async chatUpdate => {
try {

const mek = chatUpdate.messages[0]
if (!mek.message) return

await handleMessages(XeonBotInc, chatUpdate, true)

} catch (err) {
console.error("خطأ في معالجة الرسائل:", err)
}
})

XeonBotInc.public = true

/* عند الاتصال */
XeonBotInc.ev.on('connection.update', async (s) => {

const { connection } = s

if (connection === 'connecting') {
console.log(chalk.yellow('🔄 جارِ الاتصال بواتساب… استني يا معلم'))
}

if (connection === 'open') {

console.log(chalk.green("╔══════════════════════════════╗ ║   🤖 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ اشتغل ياباشا   ║ ╚══════════════════════════════╝"))

const botNumber = XeonBotInc.user.id.split(':')[0] + '@s.whatsapp.net';

/* ✅ تم التصحيح هنا */
await XeonBotInc.sendMessage(botNumber,{
text:`╭━━━〔 🤖 تم التشغيل 〕━━━╮
┃
┃ ✦ البوت اشتغل زي الفل
┃ ✦ كله تمام يا كبير 😎
┃
┃ ⏰ الوقت: ${new Date().toLocaleString()}
┃
╰━━━━━━━━━━━━━━━━╯`
})

}

if (connection === 'close') {
console.log(chalk.red('❌ الاتصال اتقفل… البوت هيحاول يرجع تاني'))
startXeonBotInc()
}

})

return XeonBotInc

} catch (error) {
console.error('خطأ تشغيل:', error)
startXeonBotInc()
}
}

startXeonBotInc()

process.on('uncaughtException', err => {
console.error('خطأ غير متوقع:', err)
})

process.on('unhandledRejection', err => {
console.error('Promise Error:', err)
})

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)

/* ✅ تم التصحيح هنا */
console.log(chalk.redBright(`تم تحديث الملف: ${__filename}`))

delete require.cache[file]
require(file)
})