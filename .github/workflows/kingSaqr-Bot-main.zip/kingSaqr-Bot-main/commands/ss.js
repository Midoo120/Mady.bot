const fetch = require('node-fetch');

async function handleSsCommand(sock, chatId, message, match) {
    try {
        const sender = message.key.participant || message.key.remoteJid;
        const user = sender.split('@')[0];

        // 🧾 لو مفيش لينك
        if (!match) {
            const helpText = `
╔═══〔 📸 أداة تصوير المواقع 〕═══╗
║
║ 📌 الاستخدام:
║ • .ss <link>
║ • .ssweb <link>
║ • .screenshot <link>
║
║ 🧠 مثال:
║ .ss https://google.com
║
║ 👤 الطلب بواسطة:
║ @${user}
║
╚════════════════════╝
`.trim();

            await sock.sendMessage(
                chatId,
                {
                    text: helpText,
                    mentions: [sender]
                },
                { quoted: message }
            );
            return;
        }

        // ⌨️ يكتب…
        await sock.presenceSubscribe(chatId);
        await sock.sendPresenceUpdate('composing', chatId);

        const url = match.trim();

        // 🔎 تحقق من اللينك
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            return sock.sendMessage(
                chatId,
                {
                    text: `
❌ بص يا @${user}

حط لينك صح يبدأ بـ
http://
أو
https://

وحاول تاني 😅
`.trim(),
                    mentions: [sender]
                },
                { quoted: message }
            );
        }

        // 🌐 API
        const apiUrl =
            `https://api.siputzx.my.id/api/tools/ssweb?url=${encodeURIComponent(url)}&theme=light&device=desktop`;

        const response = await fetch(apiUrl, {
            headers: { accept: '*/*' }
        });

        if (!response.ok) {
            throw new Error(`API responded with status: ${response.status}`);
        }

        const imageBuffer = await response.buffer();

        // 📤 إرسال السكرين
        await sock.sendMessage(
            chatId,
            {
                image: imageBuffer,
                caption: `
╔═══〔 📸 تم التصوير بنجاح 〕═══╗
║
║ 🌍 الموقع:
║ ${url}
║
║ 👤 بواسطة:
║ @${user}
║
╚════════════════════╝
`.trim(),
                mentions: [sender]
            },
            { quoted: message }
        );

    } catch (error) {
        console.error('❌ Error in ss command:', error);

        const sender = message.key.participant || message.key.remoteJid;
        const user = sender.split('@')[0];

        await sock.sendMessage(
            chatId,
            {
                text: `
╔═══〔 ❌ حصلت مشكلة 〕═══╗
║
║ بص يا @${user}
║
║ معرفتش أصور الموقع 😅
║ جرب تاني كمان شوية
║
║ 📌 ممكن يكون السبب:
║ • اللينك غلط
║ • الموقع قافل التصوير
║ • الموقع واقع
║ • الـ API نايم شوية 😂
║
╚════════════════════╝
`.trim(),
                mentions: [sender]
            },
            { quoted: message }
        );
    }
}

module.exports = {
    handleSsCommand
};