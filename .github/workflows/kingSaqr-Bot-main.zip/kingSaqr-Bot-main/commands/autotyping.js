/**

* 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ - WhatsApp Bot
* Autotyping Command - Shows fake typing status
  */

const fs = require('fs');
const path = require('path');
const isOwnerOrSudo = require('../lib/isOwner');

// Path to store the configuration
const configPath = path.join(__dirname, '..', 'data', 'autotyping.json');

// Initialize configuration file if it doesn't exist
function initConfig() {
if (!fs.existsSync(configPath)) {
fs.writeFileSync(configPath, JSON.stringify({ enabled: false }, null, 2));
}
return JSON.parse(fs.readFileSync(configPath));
}

// Toggle autotyping feature
async function autotypingCommand(sock, chatId, message) {
try {
const senderId = message.key.participant || message.key.remoteJid;
const isOwner = await isOwnerOrSudo(senderId, sock, chatId);

    if (!message.key.fromMe && !isOwner) {
        await sock.sendMessage(chatId, {
            text: '❌ الأمر ده متاح للمالك بس!',
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
            }
        });
        return;
    }

    const args =
        message.message?.conversation?.trim().split(' ').slice(1) ||
        message.message?.extendedTextMessage?.text?.trim().split(' ').slice(1) ||
        [];

    const config = initConfig();
    
    if (args.length > 0) {
        const action = args[0].toLowerCase();
        if (action === 'on' || action === 'enable') {
            config.enabled = true;
        } else if (action === 'off' || action === 'disable') {
            config.enabled = false;
        } else {
            await sock.sendMessage(chatId, {
                text: '❌ اختيار غلط!\nاستخدم: .autotyping on / off',
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                }
            });
            return;
        }
    } else {
        config.enabled = !config.enabled;
    }

    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    
    await sock.sendMessage(chatId, {
        text: `✅ تم ${config.enabled ? 'تشغيل' : 'إيقاف'} الأوتو تايبنج بنجاح!`,
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
        }
    });
    
} catch (error) {
    console.error('Error in autotyping command:', error);
    await sock.sendMessage(chatId, {
        text: '❌ حصل خطأ أثناء تنفيذ الأمر!',
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
        }
    });
}

}

function isAutotypingEnabled() {
try {
const config = initConfig();
return config.enabled;
} catch {
return false;
}
}

module.exports = {
autotypingCommand,
isAutotypingEnabled
};