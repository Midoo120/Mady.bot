const compliments = [
"إنت جدع نادر يا صاحبي 👑",
"والله إنت راجل يتشال على الراس 🤝",
"دماغك تقيلة وبتفهمها وهي طايرة 🧠🔥",
"إنت عشرة بجد مش أي حد ❤️",
"وجودك لوحده بيأمّن الضهر 💪",
"إنت صاحب جدعنة مالهاش كتالوج 😎",
"اللي يعرفك كسبان والله ✨",
"إنت وش الخير في أي حتة 🌟",
"جدعنتك تدرس بصراحة 📚🔥",
"إنت راجل تعتمد عليه وقت الجد 👊",
"صاحب يتربط في القلب مش في الموبايل 🫶",
"إنت كاريزما ماشية على رجلين 😌",
"ضحكتك بتفكّ الضيقة والله 😄",
"إنت تقيل من يومك يا معلم 🧿",
"وجودك بيرفع المعنويات ×10 🚀",
"إنت ابن أصول ومتربي صح 👌",
"كلمتك سيف ومابتنكسرش ⚔️",
"إنت فخر لأي حد يعرفك 🏆",
"دمك خفيف بس وقت الجد جبل ⛰️",
"إنت برنس في زمن كله فِيك 👑🔥"
];

const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

async function complimentCommand(sock, chatId, message) {
    try {
        if (!message || !chatId) return;

        let userToCompliment;

        // ───── منشن ─────
        if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
            userToCompliment =
                message.message.extendedTextMessage.contextInfo.mentionedJid[0];
        }
        // ───── رد ─────
        else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToCompliment =
                message.message.extendedTextMessage.contextInfo.participant;
        }

        if (!userToCompliment) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ⚠️ يا نجم 〕━━━╮

منشن الشخص أو اعملّه رد  
علشان أظبطله أحلى مجاملة 😎

╰━━━〔 🤖 ${botName} 〕━━━╯`
            }, { quoted: message });
            return;
        }

        const compliment =
            compliments[Math.floor(Math.random() * compliments.length)];

        const text =
`╭━━━〔 💬 بص بقى 〕━━━╮

يا @${userToCompliment.split('@')[0]} 👤

${compliment}

╰━━━〔 🤖 ${botName} 〕━━━╯`;

        await sock.sendMessage(
            chatId,
            {
                text,
                mentions: [userToCompliment]
            },
            { quoted: message }
        );

    } catch (error) {
        console.error('Error in compliment command:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❌ حصل لخبطة 〕━━━╮

استنى ثانية كده وجرب تاني يا كبير 😅

╰━━━〔 🤖 ${botName} 〕━━━╯`
            },
            { quoted: message }
        );
    }
}

module.exports = { complimentCommand };