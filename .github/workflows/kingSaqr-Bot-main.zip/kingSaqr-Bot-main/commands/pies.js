const fetch = require('node-fetch');

const BASE = 'https://shizoapi.onrender.com/api/pies';
const VALID_COUNTRIES = ['china', 'indonesia', 'japan', 'korea', 'hijab'];

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 📥 Fetch Image
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

async function fetchPiesImageBuffer(country) {
	const url = `${BASE}/${country}?apikey=shizo`;
	const res = await fetch(url);

	if (!res.ok) throw new Error(`HTTP ${res.status}`);

	const contentType = res.headers.get('content-type') || '';
	if (!contentType.includes('image'))
		throw new Error('API did not return an image');

	return res.buffer();
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 🎴 Main Command
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

async function piesCommand(sock, chatId, message, args) {

	const sub = (args && args[0] ? args[0] : '').toLowerCase();

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 📜 Menu
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

	if (!sub) {
		await sock.sendMessage(chatId, {
			text: `
╭━━━〔 🥧 أوامر PIES 〕━━━╮
┃
┃ اكتب الدولة بعد الأمر
┃
┃ مثال:
┃ .pies japan
┃
┃ الدول المتاحة:
┃ china
┃ indonesia
┃ japan
┃ korea
┃ hijab
┃
╰━━━━━━━━━━━━━━━━━━╯`
		}, { quoted: message });
		return;
	}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// ❌ Invalid Country
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

	if (!VALID_COUNTRIES.includes(sub)) {
		await sock.sendMessage(chatId, {
			text: `
╭━━━〔 ❌ دولة غير مدعومة 〕━━━╮
┃
┃ الدولة: ${sub}
┃ مش متاحة حالياً
┃
┃ جرّب:
┃ ${VALID_COUNTRIES.join(' • ')}
┃
╰━━━━━━━━━━━━━━━━━━━━╯`
		}, { quoted: message });
		return;
	}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 🖼️ Send Image
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

	try {

		const imageBuffer =
			await fetchPiesImageBuffer(sub);

		await sock.sendMessage(
			chatId,
			{
				image: imageBuffer,
				caption: `
╭━━━〔 🥧 PIES 〕━━━╮
┃
┃ 🌍 الدولة:
┃ ${sub}
┃
┃ 🤖 بواسطة:
┃ Mady — BOT
┃
╰━━━━━━━━━━━━━━╯`
			},
			{ quoted: message }
		);

	} catch (err) {

		console.error('Error in pies command:', err);

		await sock.sendMessage(chatId, {
			text: `
╭━━━〔 ⚠️ خطأ 〕━━━╮
┃
┃ مقدرتش أجيب الصورة ❌
┃ حاول تاني بعد شوية
┃
╰━━━━━━━━━━━━━━╯`
		}, { quoted: message });
	}
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 🔁 Alias
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

async function piesAlias(sock, chatId, message, country) {

	try {

		const imageBuffer =
			await fetchPiesImageBuffer(country);

		await sock.sendMessage(
			chatId,
			{
				image: imageBuffer,
				caption: `
╭━━━〔 🥧 PIES 〕━━━╮
┃
┃ 🌍 الدولة:
┃ ${country}
┃
┃ 🤖 Mady — BOT
┃
╰━━━━━━━━━━━━━━╯`
			},
			{ quoted: message }
		);

	} catch (err) {

		console.error(
			`Error in pies alias (${country}) command:`,
			err
		);

		await sock.sendMessage(chatId, {
			text: `
╭━━━〔 ⚠️ خطأ 〕━━━╮
┃
┃ فشل تحميل الصورة ❌
┃ حاول تاني بعد شوية
┃
╰━━━━━━━━━━━━━━╯`
		}, { quoted: message });
	}
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

module.exports = {
	piesCommand,
	piesAlias,
	VALID_COUNTRIES
};

/*
╭──────────────────╮
│   Mady — BOT   │
│   PIES SYSTEM    │
╰──────────────────╯
*/