const axios = require('axios');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { uploadImage } = require('../lib/uploadImage');

async function getQuotedOrOwnImageUrl(sock, message) {
    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    if (quoted?.imageMessage) {
        const stream = await downloadContentFromMessage(quoted.imageMessage, 'image');
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        const buffer = Buffer.concat(chunks);
        return await uploadImage(buffer);
    }

    if (message.message?.imageMessage) {
        const stream = await downloadContentFromMessage(message.message.imageMessage, 'image');
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        const buffer = Buffer.concat(chunks);
        return await uploadImage(buffer);
    }

    return null;
}

async function reminiCommand(sock, chatId, message, args) {
    try {
        let imageUrl = null;
        
        if (args.length > 0) {
            const url = args.join(' ');
            if (isValidUrl(url)) {
                imageUrl = url;
            } else {
                return sock.sendMessage(chatId, { 
                    text: `
╭━━━〔 ❌ 𝗧𝗚𝗟𝗜𝗧 𝗟𝗜𝗡𝗞 〕━━━╮
┃
┃ ✖️ اللينك اللي بعته مش شغال يا نجم
┃
┃ 📌 ابعت لينك صورة صح:
┃ `.remini https://example.com/image.jpg`
┃
╰━━━━━━━━━━━━━━━╯
` 
                }, { quoted: message });
            }
        } else {
            imageUrl = await getQuotedOrOwnImageUrl(sock, message);
            
            if (!imageUrl) {
                return sock.sendMessage(chatId, { 
                    text: `
╭━━━〔 🧠 𝗥𝗘𝗠𝗜𝗡𝗜 𝗔𝗜 〕━━━╮
┃
┃ 📸 أمر تحسين الصور بالذكاء الاصطناعي
┃
┃ ✦ الاستخدام:
┃ • `.remini <لينك>`
┃ • رد على صورة + الأمر
┃ • ابعت صورة مع الأمر
┃
┃ 🧪 مثال:
┃ `.remini https://example.com/img.jpg`
┃
╰━━━━━━━━━━━━━━━╯
` 
                }, { quoted: message });
            }
        }

        const apiUrl = `https://api.princetechn.com/api/tools/remini?apikey=prince_tech_api_azfsbshfb&url=${encodeURIComponent(imageUrl)}`;
        
        const response = await axios.get(apiUrl, {
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0'
            }
        });

        if (response.data && response.data.success && response.data.result) {
            const result = response.data.result;
            
            if (result.image_url) {
                const imageResponse = await axios.get(result.image_url, {
                    responseType: 'arraybuffer',
                    timeout: 30000
                });
                
                if (imageResponse.status === 200 && imageResponse.data) {
                    await sock.sendMessage(chatId, {
                        image: imageResponse.data,
                        caption: `
╭━━━〔 ✨ 𝗥𝗘𝗠𝗜𝗡𝗜 𝗦𝗨𝗖𝗖𝗘𝗦𝗦 〕━━━╮
┃
┃ 🧠 تم تحسين الصورة بالذكاء الاصطناعي
┃ 📸 الجودة بقت HD فشخ 🔥
┃
┃ 🤖 𝗘𝗡𝗛𝗔𝗡𝗖𝗘𝗗 𝗕𝗬
┃ 『 𝗞𝗡𝗜𝗚𝗛𝗧 — 𝗕𝗢𝗧 』
┃
╰━━━━━━━━━━━━━━━━╯
`
                    }, { quoted: message });
                } else {
                    throw new Error('Failed to download enhanced image');
                }
            } else {
                throw new Error(result.message || 'Failed to enhance image');
            }
        } else {
            throw new Error('API returned invalid response');
        }

    } catch (error) {
        console.error('Remini Error:', error.message);
        
        let errorMessage = `
╭━━━〔 ❌ 𝗘𝗥𝗥𝗢𝗥 〕━━━╮
┃
┃ حصلت مشكلة و الصورة متحسّنتش
┃ جرّب تاني كدا يا معلم
┃
╰━━━━━━━━━━━━━━━╯
`;

        if (error.response?.status === 429) {
            errorMessage = `
╭━━━〔 ⏰ 𝗥𝗔𝗧𝗘 𝗟𝗜𝗠𝗜𝗧 〕━━━╮
┃
┃ السيستم مضغوط دلوقتي
┃ استنى شوية و جرّب تاني
┃
╰━━━━━━━━━━━━━━━━╯
`;
        } else if (error.response?.status === 400) {
            errorMessage = `
╭━━━〔 ❌ 𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗜𝗠𝗔𝗚𝗘 〕━━━╮
┃
┃ اللينك أو الصورة مش صالحين
┃ ابعت صورة أو لينك تاني
┃
╰━━━━━━━━━━━━━━━━━╯
`;
        } else if (error.code === 'ECONNABORTED') {
            errorMessage = `
╭━━━〔 ⏰ 𝗧𝗜𝗠𝗘𝗢𝗨𝗧 〕━━━╮
┃
┃ الطلب أخد وقت طويل
┃ جرّب تاني بعد شوية
┃
╰━━━━━━━━━━━━━━━╯
`;
        }

        await sock.sendMessage(chatId, { 
            text: errorMessage 
        }, { quoted: message });
    }
}

function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

module.exports = { reminiCommand };