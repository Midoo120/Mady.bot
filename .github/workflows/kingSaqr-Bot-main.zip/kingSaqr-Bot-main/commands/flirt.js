const fetch = require('node-fetch');

async function flirtCommand(sock, chatId, message) {
    const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

    try {
        const shizokeys = 'shizo';
        const res = await fetch(
            `https://shizoapi.onrender.com/api/texts/flirt?apikey=${shizokeys}`
        );

        if (!res.ok) {
            throw await res.text();
        }

        const json = await res.json();
        const flirtMessage = json.result;

        // ❤️ رسالة الفليرت
        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❤️ Flirt Time 〕━━━╮

${flirtMessage}

╰━━━〔 🤖 ${botName} 〕━━━╯`
            },
            { quoted: message }
        );

    } catch (error) {
        console.error('Error in flirt command:', error);

        // ❌ رسالة الخطأ
        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❌ ${botName} 〕━━━╮

معرفتش أجيب كلام فليرت دلوقتي 😢  
جرّب تاني بعد شوية يا روش ❤️

╰━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
    }
}

module.exports = { flirtCommand };