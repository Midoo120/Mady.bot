const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const settings = require('../settings');
const webp = require('node-webpmux');
const crypto = require('crypto');

async function stickercropCommand(sock, chatId, message) {

// 📌 الرسالة المقتبس عليها
const messageToQuote = message;

// 🎯 تحديد الرسالة الهدف (لو رد)
let targetMessage = message;

if (message.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
    const quotedInfo =
    message.message.extendedTextMessage.contextInfo;

    targetMessage = {
        key: {
            remoteJid: chatId,
            id: quotedInfo.stanzaId,
            participant: quotedInfo.participant
        },
        message: quotedInfo.quotedMessage
    };
}

const mediaMessage =
    targetMessage.message?.imageMessage ||
    targetMessage.message?.videoMessage ||
    targetMessage.message?.documentMessage ||
    targetMessage.message?.stickerMessage;

// ❌ مفيش ميديا
if (!mediaMessage) {
    await sock.sendMessage(chatId,{
        text:

`⚠️ لازم ترد على صورة / فيديو / ستيكر مع الأمر .crop

أو ابعت صورة مع الكابشن .crop`
},{ quoted: messageToQuote });
return;
}

try {

    // ⬇️ تحميل الميديا
    const mediaBuffer =
    await downloadMediaMessage(
        targetMessage,
        'buffer',
        {},
        {
            logger: undefined,
            reuploadRequest:
            sock.updateMediaMessage
        }
    );

    if (!mediaBuffer) {
        await sock.sendMessage(chatId,{
            text:

'❌ فشل تحميل الميديا، حاول تاني.'
});
return;
}

    // 📁 مجلد مؤقت
    const tmpDir =
    path.join(process.cwd(),'tmp');

    if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir,{recursive:true});
    }

    const tempInput =
    path.join(tmpDir,`temp_${Date.now()}`);

    const tempOutput =
    path.join(tmpDir,
    `crop_${Date.now()}.webp`);

    fs.writeFileSync(tempInput,mediaBuffer);

    // 🎬 تحديد لو متحرك
    const isAnimated =
        mediaMessage.mimetype?.includes('gif') ||
        mediaMessage.mimetype?.includes('video') ||
        mediaMessage.seconds > 0;

    // 📏 حجم الملف
    const fileSizeKB =
    mediaBuffer.length / 1024;

    const isLargeFile =
    fileSizeKB > 5000;

    // 🎞️ أوامر FFmpeg
    let ffmpegCommand;

    if (isAnimated) {

        if (isLargeFile) {

            ffmpegCommand =

"ffmpeg -i "${tempInput}" -t 2 -vf "crop=min(iw\\,ih):min(iw\\,ih),scale=512:512,fps=8" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 30 -compression_level 6 -b:v 100k "${tempOutput}"";

        } else {

            ffmpegCommand =

"ffmpeg -i "${tempInput}" -t 3 -vf "crop=min(iw\\,ih):min(iw\\,ih),scale=512:512,fps=12" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 50 -compression_level 6 -b:v 150k "${tempOutput}"";
}

    } else {

        ffmpegCommand =

"ffmpeg -i "${tempInput}" -vf "crop=min(iw\\,ih):min(iw\\,ih),scale=512:512,format=rgba" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 75 -compression_level 6 "${tempOutput}"";
}

    await new Promise((resolve,reject)=>{
        exec(ffmpegCommand,(error)=>{
            if(error) reject(error);
            else resolve();
        });
    });

    // 📦 قراءة الناتج
    let webpBuffer =
    fs.readFileSync(tempOutput);

    // 🏷️ ميتاداتا
    const img = new webp.Image();
    await img.load(webpBuffer);

    const json = {
        'sticker-pack-id':
        crypto.randomBytes(32).toString('hex'),
        'sticker-pack-name':
        settings.packname || 'King Saqr',
        'emojis':['✂️']
    };

    const exifAttr = Buffer.from([

0x49,0x49,0x2A,0x00,0x08,0x00,0x00,0x00,
0x01,0x00,0x41,0x57,0x07,0x00,0x00,0x00,
0x00,0x00,0x16,0x00,0x00,0x00
]);

    const jsonBuffer =
    Buffer.from(JSON.stringify(json),'utf8');

    const exif =
    Buffer.concat([exifAttr,jsonBuffer]);

    exif.writeUIntLE(
    jsonBuffer.length,14,4);

    img.exif = exif;

    const finalBuffer =
    await img.save(null);

    // 📤 إرسال السـتيكر
    await sock.sendMessage(chatId,{
        sticker: finalBuffer
    },{ quoted: messageToQuote });

    // 🧹 تنظيف الملفات
    fs.unlinkSync(tempInput);
    fs.unlinkSync(tempOutput);

} catch (error) {

    console.error(

'خطأ في أمر crop:', error);

    await sock.sendMessage(chatId,{
        text:

'❌ فشل قصّ السـتيكر! جرّب صورة تانية.'
});
}
}

module.exports = stickercropCommand;