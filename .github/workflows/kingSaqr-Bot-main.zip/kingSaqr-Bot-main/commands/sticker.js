const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const settings = require('../settings');
const webp = require('node-webpmux');
const crypto = require('crypto');

async function stickerCommand(sock, chatId, message) {

// 📌 الرسالة اللي البوت هيرد عليها
const messageToQuote = message;

// 📌 الرسالة اللي فيها الميديا
let targetMessage = message;

// لو الأمر كان رد على رسالة
if (message.message?.extendedTextMessage?.contextInfo?.quotedMessage) {

    const quotedInfo =
    message.message
    .extendedTextMessage
    .contextInfo;

    targetMessage = {
        key: {
            remoteJid: chatId,
            id: quotedInfo.stanzaId,
            participant: quotedInfo.participant
        },
        message: quotedInfo.quotedMessage
    };
}

// 🎯 تحديد نوع الميديا
const mediaMessage =
    targetMessage.message?.imageMessage ||
    targetMessage.message?.videoMessage ||
    targetMessage.message?.documentMessage;

if (!mediaMessage) {
    await sock.sendMessage(chatId,{
        text:

'⚠️ رد على صورة / فيديو بـ .sticker\nأو ابعت ميديا وحط الأمر في الكابشن.',
contextInfo:{
forwardingScore:999,
isForwarded:true,
}
},{ quoted: messageToQuote });
return;
}

try {

    // ⬇️ تحميل الميديا
    const mediaBuffer =
    await downloadMediaMessage(
        targetMessage,
        'buffer',
        {},
        {
            logger:undefined,
            reuploadRequest:
            sock.updateMediaMessage
        }
    );

    if (!mediaBuffer) {
        await sock.sendMessage(chatId,{
            text:

'❌ فشل تحميل الميديا، حاول تاني.',
contextInfo:{
forwardingScore:999,
isForwarded:true,
}
});
return;
}

    // 📁 إنشاء مجلد tmp
    const tmpDir =
    path.join(process.cwd(),'tmp');

    if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir,
        { recursive:true });
    }

    // 🗂️ مسارات مؤقتة
    const tempInput =
    path.join(tmpDir,
    `temp_${Date.now()}`);

    const tempOutput =
    path.join(tmpDir,
    `sticker_${Date.now()}.webp`);

    fs.writeFileSync(
    tempInput, mediaBuffer);

    // 🎞️ هل الميديا متحركة؟
    const isAnimated =
        mediaMessage.mimetype
        ?.includes('gif') ||
        mediaMessage.mimetype
        ?.includes('video') ||
        mediaMessage.seconds > 0;

    // ⚙️ أمر FFmpeg
    const ffmpegCommand =
    isAnimated

? "ffmpeg -i "${tempInput}" -vf "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 75 -compression_level 6 "${tempOutput}""

: "ffmpeg -i "${tempInput}" -vf "scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 75 -compression_level 6 "${tempOutput}"";

    await new Promise((resolve,reject)=>{
        exec(ffmpegCommand,(error)=>{
            if(error) reject(error);
            else resolve();
        });
    });

    // 📥 قراءة الستيكر
    let webpBuffer =
    fs.readFileSync(tempOutput);

    // 🏷️ إضافة الميتاداتا
    const img = new webp.Image();
    await img.load(webpBuffer);

    const json = {
        'sticker-pack-id':
        crypto.randomBytes(32)
        .toString('hex'),

        'sticker-pack-name':
        settings.packname
        || 'King Saqr',

        'emojis':['🤖']
    };

    const exifAttr = Buffer.from([

0x49,0x49,0x2A,0x00,0x08,0x00,0x00,0x00,
0x01,0x00,0x41,0x57,0x07,0x00,0x00,0x00,
0x00,0x00,0x16,0x00,0x00,0x00
]);

    const jsonBuffer =
    Buffer.from(
    JSON.stringify(json),'utf8');

    const exif =
    Buffer.concat([
        exifAttr,
        jsonBuffer
    ]);

    exif.writeUIntLE(
    jsonBuffer.length,14,4);

    img.exif = exif;

    const finalBuffer =
    await img.save(null);

    // 📤 إرسال الستيكر
    await sock.sendMessage(chatId,{
        sticker: finalBuffer
    },{ quoted: messageToQuote });

    // 🧹 تنظيف الملفات
    try {
        fs.unlinkSync(tempInput);
        fs.unlinkSync(tempOutput);
    } catch {}

} catch (error) {

    console.error(

'خطأ في أمر sticker:',error);

    await sock.sendMessage(chatId,{
        text:

'❌ فشل إنشاء الستيكر!\nحاول مرة تانية.',
contextInfo:{
forwardingScore:999,
isForwarded:true,
}
});
}
}

module.exports = stickerCommand;