const axios = require('axios');
const { fetchBuffer } = require('../lib/myfunc');

async function imagineCommand(sock, chatId, message) {

    const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

    try {

        // قراءة النص
        const prompt =
            message.message?.conversation?.trim() ||
            message.message?.extendedTextMessage?.text?.trim() ||
            '';

        // حذف الأمر نفسه
        const imagePrompt = prompt.slice(8).trim();

        // لو مفيش وصف
        if (!imagePrompt) {
            return await sock.sendMessage(
                chatId,
                {
                    text:
`╭━━━〔 ⚠️ ${botName} 〕━━━╮

فين وصف الصورة؟ 🎨

📌 مثال:
.imagine قطة بتلبس نظارة شمس

╰━━━━━━━━━━━━━━━━━━╯`
                },
                { quoted: message }
            );
        }

        // رسالة الانتظار
        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 🎨 ${botName} 〕━━━╮

جارِ رسم تحفتك الفنية… 🖌️  
استنى شوية بس 😌

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );

        // تحسين البرومبت
        const enhancedPrompt = enhancePrompt(imagePrompt);

        // طلب الصورة من الـ API
        const response = await axios.get(
            `https://shizoapi.onrender.com/api/ai/imagine?apikey=shizo&query=${encodeURIComponent(enhancedPrompt)}`,
            { responseType: 'arraybuffer' }
        );

        const imageBuffer = Buffer.from(response.data);

        // إرسال الصورة
        await sock.sendMessage(
            chatId,
            {
                image: imageBuffer,
                caption:
`╭━━━〔 🖼️ ${botName} 〕━━━╮

✔ تم إنشاء الصورة بنجاح

📝 الوصف:
${imagePrompt}

استمتع بالإبداع ✨

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );

    } catch (error) {

        console.error('Error in imagine command:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❌ ${botName} 〕━━━╮

فشل إنشاء الصورة 😢

جرب تكتب وصف أوضح  
أو حاول تاني بعد شوية

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
    }
}


// تحسين البرومبت
function enhancePrompt(prompt) {

    const qualityEnhancers = [
        'high quality',
        'detailed',
        'masterpiece',
        'best quality',
        'ultra realistic',
        '4k',
        'highly detailed',
        'professional photography',
        'cinematic lighting',
        'sharp focus'
    ];

    const numEnhancers = Math.floor(Math.random() * 2) + 3;

    const selectedEnhancers = qualityEnhancers
        .sort(() => Math.random() - 0.5)
        .slice(0, numEnhancers);

    return `${prompt}, ${selectedEnhancers.join(', ')}`;
}

module.exports = imagineCommand;