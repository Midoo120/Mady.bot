const fetch = require('node-fetch');

async function memeCommand(sock, chatId, message) {
    try {
        const url = 'https://shizoapi.onrender.com/api/memes/cheems?apikey=shizo';
        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }

        const contentType = response.headers.get('content-type');

        if (!contentType || !contentType.includes('image')) {
            throw new Error('Invalid response type');
        }

        const imageBuffer = await response.buffer();

        const buttons = [
            { buttonId: '.meme', buttonText: { displayText: '🎭 ميم تاني' }, type: 1 },
            { buttonId: '.joke', buttonText: { displayText: '😂 نكتة' }, type: 1 }
        ];

        await sock.sendMessage(
            chatId,
            {
                image: imageBuffer,
                caption: "🐕 شيمز بيقولك:\n\n> اتفضل الميم 😂",
                buttons,
                headerType: 1
            },
            { quoted: message }
        );

    } catch (error) {
        console.error('Error in meme command:', error);

        await sock.sendMessage(
            chatId,
            { text: '❌ حصل خطأ وأنا بجيب الميم… جرّب تاني بعد شوية.' },
            { quoted: message }
        );
    }
}

module.exports = memeCommand;