const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

async function ensureGroupAndAdmin(sock, chatId, senderId) {

    const isGroup = chatId.endsWith('@g.us');

    if (!isGroup) {
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ⚠️ ${botName} 〕━━━╮

الأمر ده شغال في الجروبات بس ❌

╰━━━━━━━━━━━━━━━━━━╯`
        });
        return { ok: false };
    }

    const isAdmin = require('../lib/isAdmin');
    const adminStatus = await isAdmin(sock, chatId, senderId);

    if (!adminStatus.isBotAdmin) {
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ⚠️ ${botName} 〕━━━╮

لازم تدي البوت أدمن الأول 🛡️

╰━━━━━━━━━━━━━━━━━━╯`
        });
        return { ok: false };
    }

    if (!adminStatus.isSenderAdmin) {
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 🚫 ${botName} 〕━━━╮

الأوامر دي للأدمن بس 👮

╰━━━━━━━━━━━━━━━━━━╯`
        });
        return { ok: false };
    }

    return { ok: true };
}

// 📝 تغيير الوصف
async function setGroupDescription(sock, chatId, senderId, text, message) {

    const check = await ensureGroupAndAdmin(sock, chatId, senderId);
    if (!check.ok) return;

    const desc = (text || '').trim();

    if (!desc) {
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❓ ${botName} 〕━━━╮

الاستخدام:

.setgdesc الوصف الجديد

╰━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
        return;
    }

    try {
        await sock.groupUpdateDescription(chatId, desc);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ✅ ${botName} 〕━━━╮

تم تغيير وصف الجروب بنجاح ✨

╰━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });

    } catch {
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ ${botName} 〕━━━╮

فشل تغيير الوصف 😢

╰━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
    }
}

// 🏷️ تغيير الاسم
async function setGroupName(sock, chatId, senderId, text, message) {

    const check = await ensureGroupAndAdmin(sock, chatId, senderId);
    if (!check.ok) return;

    const name = (text || '').trim();

    if (!name) {
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❓ ${botName} 〕━━━╮

الاستخدام:

.setgname الاسم الجديد

╰━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
        return;
    }

    try {
        await sock.groupUpdateSubject(chatId, name);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ✅ ${botName} 〕━━━╮

تم تغيير اسم الجروب بنجاح 🏷️

╰━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });

    } catch {
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ ${botName} 〕━━━╮

فشل تغيير الاسم 😢

╰━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
    }
}

// 🖼️ تغيير صورة الجروب
async function setGroupPhoto(sock, chatId, senderId, message) {

    const check = await ensureGroupAndAdmin(sock, chatId, senderId);
    if (!check.ok) return;

    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const imageMessage = quoted?.imageMessage || quoted?.stickerMessage;

    if (!imageMessage) {
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 📸 ${botName} 〕━━━╮

اعمل ريبلاي على صورة أو ستيكر  
واكتب:

.setgpp

╰━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
        return;
    }

    try {
        const tmpDir = path.join(process.cwd(), 'tmp');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

        const stream = await downloadContentFromMessage(imageMessage, 'image');
        let buffer = Buffer.from([]);

        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        const imgPath = path.join(tmpDir, `gpp_${Date.now()}.jpg`);
        fs.writeFileSync(imgPath, buffer);

        await sock.updateProfilePicture(chatId, { url: imgPath });

        try { fs.unlinkSync(imgPath); } catch {}

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ✅ ${botName} 〕━━━╮

تم تغيير صورة الجروب بنجاح 🖼️✨

╰━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });

    } catch {
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ ${botName} 〕━━━╮

فشل تغيير الصورة 😢

╰━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
    }
}

module.exports = {
    setGroupDescription,
    setGroupName,
    setGroupPhoto
};