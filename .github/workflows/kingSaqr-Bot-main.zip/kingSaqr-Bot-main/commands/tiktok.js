const { ttdl } = require("ruhend-scraper");
const axios = require('axios');

const processedMessages = new Set();

async function tiktokCommand(sock, chatId, message) {
    try {
        // 🧠 منع التكرار
        if (processedMessages.has(message.key.id)) return;
        processedMessages.add(message.key.id);

        setTimeout(() => {
            processedMessages.delete(message.key.id);
        }, 5 * 60 * 1000);

        const text =
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text;

        if (!text) {
            return sock.sendMessage(chatId, {
                text: '❌ ابعت لينك تيك توك بعد الأمر.'
            }, { quoted: message });
        }

        const url = text.split(' ').slice(1).join(' ').trim();

        if (!url) {
            return sock.sendMessage(chatId, {
                text: '❌ حط لينك الفيديو بعد الأمر.'
            }, { quoted: message });
        }

        // 🔍 فحص اللينك
        const patterns = [
            /tiktok\.com/,
            /vt\.tiktok\.com/,
            /vm\.tiktok\.com/
        ];

        if (!patterns.some(p => p.test(url))) {
            return sock.sendMessage(chatId, {
                text: '❌ ده مش لينك TikTok صالح.'
            }, { quoted: message });
        }

        // 🔄 React تحميل
        await sock.sendMessage(chatId, {
            react: { text: '⏳', key: message.key }
        });

        // 📡 API
        const apiUrl =
            `https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(url)}`;

        let videoUrl = null;
        let title = null;

        try {
            const res = await axios.get(apiUrl, { timeout: 15000 });

            if (res.data?.status && res.data?.data) {
                const data = res.data.data;

                if (data.urls?.length) {
                    videoUrl = data.urls[0];
                } else if (data.video_url) {
                    videoUrl = data.video_url;
                } else if (data.download_url) {
                    videoUrl = data.download_url;
                }

                title = data.metadata?.title || 'TikTok Video';
            }
        } catch (e) {
            console.error('Siputzx API failed:', e.message);
        }

        // 🔁 Fallback ttdl
        if (!videoUrl) {
            try {
                const dl = await ttdl(url);
                const media = dl?.data?.[0];

                if (media?.url) {
                    videoUrl = media.url;
                }
            } catch (e) {
                console.error('ttdl failed:', e.message);
            }
        }

        if (!videoUrl) {
            return sock.sendMessage(chatId, {
                text: '❌ فشل تحميل الفيديو.\nجرب لينك تاني.'
            }, { quoted: message });
        }

        // ⬇️ تحميل Buffer
        let videoBuffer;

        try {
            const vid = await axios.get(videoUrl, {
                responseType: 'arraybuffer',
                timeout: 60000
            });

            videoBuffer = Buffer.from(vid.data);
        } catch {
            // fallback URL send
            return sock.sendMessage(chatId, {
                video: { url: videoUrl },
                caption:
`🎬 تم التحميل بواسطة الملك صقر 🦅

📝 Title:
${title}`
            }, { quoted: message });
        }

        // 📤 إرسال الفيديو
        await sock.sendMessage(chatId, {
            video: videoBuffer,
            mimetype: 'video/mp4',
            caption:
`🎬┃TikTok Downloader
━━━━━━━━━━━━━━
🦅 تم التحميل بواسطة الملك صقر

📝 العنوان:
${title}

🚀 Enjoy!`
        }, { quoted: message });

        // ✅ React نجاح
        await sock.sendMessage(chatId, {
            react: { text: '✅', key: message.key }
        });

    } catch (error) {
        console.error('TikTok Command Error:', error);

        await sock.sendMessage(chatId, {
            text:
`❌ حصل خطأ أثناء التحميل.

🔁 حاول تاني بعد شوية.`
        }, { quoted: message });
    }
}

module.exports = tiktokCommand;