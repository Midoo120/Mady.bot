const axios = require('axios');
const yts = require('yt-search');

async function songCommand(sock, chatId, message) {
    try {
        const sender =
            message.key.participant ||
            message.key.remoteJid;

        const raw =
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text ||
            '';

        if (!raw) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 🎧 تحميل أغنية 〕━━━╮
┃
┃ ❌ اكتب اسم الأغنية يا نجم
┃
┃ 📌 مثال:
┃ .song tamally maak
┃
╰━━━━━━━━━━━━━━━━╯`
            }, { quoted: message });
            return;
        }

        const args = raw.split(/\s+/).slice(1).join(' ');
        if (!args) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ⚠️ تنبيه 〕━━━╮
┃
┃ قولّي اسم الأغنية الأول
┃ يا @${sender.split('@')[0]} 🎤
┃
╰━━━━━━━━━━━━━━╯`,
                mentions: [sender]
            }, { quoted: message });
            return;
        }

        // Search
        const search = await yts(args);
        if (!search.videos.length) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 🚫 مفيش نتايج 〕━━━╮
┃
┃ ملقتش أي حاجة بالاسم دا
┃ جرّب تكتبها صح يا برو
┃
╰━━━━━━━━━━━━━━━━╯`
            }, { quoted: message });
            return;
        }

        const video = search.videos[0];

        // Duration limit
        if (video.seconds > 1200) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ⏳ طويلة شوية 〕━━━╮
┃
┃ الأغنية أطول من 20 دقيقة
┃ ومش هتنفع تتحمّل
┃
╰━━━━━━━━━━━━━━━━╯`
            }, { quoted: message });
            return;
        }

        // Info card
        await sock.sendMessage(chatId, {
            image: { url: video.thumbnail },
            caption:
`╭━━━〔 🎶 جاري التحميل 〕━━━╮
┃
┃ 📝 الاسم :
┃ ${video.title}
┃
┃ ⏱ المدة :
┃ ${video.timestamp}
┃
┃ 👤 الطلب بواسطة :
┃ @${sender.split('@')[0]}
┃
┃ ⌛ استنى ثواني…
┃
╰━━━━━━━━━━━━━━━━━━╯`,
            mentions: [sender]
        }, { quoted: message });

        // APIs
        const api = `https://izumiiiiiiii.dpdns.org/downloader/youtube?url=${encodeURIComponent(video.url)}&format=mp3`;
        const { data } = await axios.get(api);

        const audioUrl = data?.result?.download;
        if (!audioUrl) throw new Error('No download');

        // Send audio
        await sock.sendMessage(chatId, {
            audio: { url: audioUrl },
            mimetype: 'audio/mpeg',
            fileName: `${video.title}.mp3`
        }, { quoted: message });

    } catch (err) {
        console.error(err);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ حصلت مشكلة 〕━━━╮
┃
┃ معرفتش أحمل الأغنية
┃ جرّب تاني بعد شوية
┃
╰━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
    }
}

module.exports = songCommand;