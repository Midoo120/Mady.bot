const axios = require('axios');
const fs = require('fs');
const path = require('path');

async function facebookCommand(sock, chatId, message) {
    const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

    try {
        const text =
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text;

        const url = text.split(' ').slice(1).join(' ').trim();

        // ───────────── فحص الرابط ─────────────
        if (!url) {
            return await sock.sendMessage(
                chatId,
                {
                    text:
`╭━━━〔 📥 تحميل فيسبوك 〕━━━╮

ارسل رابط فيديو فيسبوك بعد الأمر

مثال:
.fb https://facebook.com/...

╰━━━〔 🤖 ${botName} 〕━━━╯`
                },
                { quoted: message }
            );
        }

        if (!url.includes('facebook.com')) {
            return await sock.sendMessage(
                chatId,
                {
                    text:
`╭━━━〔 ❌ خطأ 〕━━━╮

الرابط ليس تابع لفيسبوك ❗

╰━━━〔 🤖 ${botName} 〕━━━╯`
                },
                { quoted: message }
            );
        }

        // ريأكشن تحميل
        await sock.sendMessage(chatId, {
            react: { text: '⏳', key: message.key }
        });

        // ───────────── API ─────────────
        const apiUrl =
            `https://api.hanggts.xyz/download/facebook?url=${encodeURIComponent(url)}`;

        const response = await axios.get(apiUrl);
        const data = response.data;

        let fbvid =
            data?.result?.media?.video_hd ||
            data?.result?.media?.video_sd ||
            data?.result?.url ||
            data?.data?.url ||
            data?.url;

        let title =
            data?.result?.info?.title ||
            data?.result?.title ||
            data?.title ||
            "Facebook Video";

        if (!fbvid) {
            return await sock.sendMessage(
                chatId,
                {
                    text:
`╭━━━〔 ❌ فشل التحميل 〕━━━╮

تعذر تحميل الفيديو ❗

الاسباب المحتملة:
• الفيديو خاص 🔒  
• الرابط خطأ  
• الفيديو محذوف  

╰━━━〔 🤖 ${botName} 〕━━━╯`
                },
                { quoted: message }
            );
        }

        // ───────────── إرسال الفيديو ─────────────
        const caption =
`╭━━━〔 📥 تم التحميل 〕━━━╮

📝 العنوان:
${title}

تم التحميل بواسطة:
🤖 ${botName}

╰━━━━━━━━━━━━━━╯`;

        await sock.sendMessage(
            chatId,
            {
                video: { url: fbvid },
                mimetype: "video/mp4",
                caption
            },
            { quoted: message }
        );

    } catch (error) {
        console.error('Error in Facebook command:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❌ خطأ 〕━━━╮

حصل خطأ أثناء التحميل 😢  
حاول تاني بعد شوية

╰━━━〔 🤖 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 〕━━━╯`
            },
            { quoted: message }
        );
    }
}

module.exports = facebookCommand;