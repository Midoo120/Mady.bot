async function shipCommand(sock, chatId, msg) {
    try {
        // ميتاداتا الجروب
        const metadata = await sock.groupMetadata(chatId);
        const members = metadata.participants.map(v => v.id);

        if (members.length < 2) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ❌ مين هتشحن لمين ؟ 〕━━━╮
┃
┃ الجروب مفيهوش غير واحد 😂
┃ هتشحنه لنفسه يعني ؟
┃
╰━━━━━━━━━━━━━━━━╯`
            }, { quoted: msg });
            return;
        }

        // اختيار عشوائي
        let firstUser =
            members[Math.floor(Math.random() * members.length)];

        let secondUser;
        do {
            secondUser =
                members[Math.floor(Math.random() * members.length)];
        } while (secondUser === firstUser);

        const mention = id => '@' + id.split('@')[0];

        // نسبة الحب العشوائية
        const love =
            Math.floor(Math.random() * 101);

        let status;

        if (love < 20)
            status = '🚫 علاقة فاشلة قبل ما تبدأ';
        else if (love < 50)
            status = '🙂 معرفة سطحية';
        else if (love < 80)
            status = '💘 في إعجاب واضح';
        else if (love < 100)
            status = '🔥 حب مولع الدنيا';
        else
            status = '💍 كتبوا الكتاب خلاص';

        // الرسالة المزخرفة
        const text =
`╭━━━〔 💞 نظام الشِيب 〕━━━╮

👤 ${mention(firstUser)}
❤️
👤 ${mention(secondUser)}

━━━━━━━━━━━━━━━
💖 نسبة التوافق: *${love}%*
📊 الحالة: ${status}
━━━━━━━━━━━━━━━

ربنا يتمم بخير بقا 😂🤍
╰━━━━━━━━━━━━━━━╯`;

        await sock.sendMessage(chatId, {
            text,
            mentions: [firstUser, secondUser]
        }, { quoted: msg });

    } catch (error) {
        console.error('Ship Error:', error);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ حصل خلل 〕━━━╮
┃
┃ معرفتش أشحنهم 😔
┃ أتأكد إن دا جروب الأول
┃
╰━━━━━━━━━━━━━━━╯`
        }, { quoted: msg });
    }
}

module.exports = shipCommand;