const fetch = require('node-fetch');

async function truthCommand(sock, chatId, message) {
    try {
        const shizokeys = 'shizo';

        const res = await fetch(
            `https://shizoapi.onrender.com/api/texts/truth?apikey=${shizokeys}`
        );

        if (!res.ok) {
            throw await res.text();
        }

        const json = await res.json();
        const truthMessage = json.result;

        // إرسال سؤال الصراحة
        await sock.sendMessage(chatId, {
            text: `🎭 *سؤال صراحة*\n\n${truthMessage}\n\n🔥 جاوب بصراحة بقى… مفيش هروب!`
        }, { quoted: message });

    } catch (error) {
        console.error('Error in truth command:', error);

        await sock.sendMessage(chatId, {
            text: '❌ مقدرتش أجيب سؤال صراحة دلوقتي… جرّب تاني بعد شوية.'
        }, { quoted: message });
    }
}

module.exports = { truthCommand };