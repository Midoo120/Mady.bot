const fetch = require('node-fetch');

async function shayariCommand(sock, chatId, message) {
    try {
        const response = await fetch(
            'https://shizoapi.onrender.com/api/texts/shayari?apikey=shizo'
        );

        const data = await response.json();

        if (!data || !data.result) {
            throw new Error('Invalid API Response');
        }

        // نص الشاعري مزخرف
        const text =
`╭━━━〔 🪶 شِعر حب تقيل 〕━━━╮

${data.result}

━━━━━━━━━━━━━━━
💌 لو الكلام عجبك ابعته
للي في بالك بقا 😏❤️
╰━━━━━━━━━━━━━━━╯`;

        // الأزرار
        const buttons = [
            {
                buttonId: '.shayari',
                buttonText: { displayText: '🪶 شعر تاني' },
                type: 1
            },
            {
                buttonId: '.roseday',
                buttonText: { displayText: '🌹 Rose Day' },
                type: 1
            }
        ];

        await sock.sendMessage(
            chatId,
            {
                text,
                buttons,
                headerType: 1
            },
            { quoted: message }
        );

    } catch (error) {
        console.error('Error in shayari command:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❌ حصل خلل 〕━━━╮
┃
┃ السيرفر نايم شوية 😴
┃ جرّب تاني بعدين
┃
╰━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
    }
}

module.exports = { shayariCommand };