const isAdmin = require('../lib/isAdmin');

async function muteCommand(sock, chatId, senderId, message, durationInMinutes) {

    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

    // البوت مش أدمن
    if (!isBotAdmin) {
        await sock.sendMessage(chatId, {
            text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ⚠️
╭━━━〔 صلاحيـات البـوت 〕━━━╮
لازم تخليني أدمن الأول 👮🏻‍♂️
عشان أقدر أعمل ميوت للجروب ❌
╰━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
        return;
    }

    // اللي استخدم الأمر مش أدمن
    if (!isSenderAdmin) {
        await sock.sendMessage(chatId, {
            text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 🚫
╭━━━〔 أمـر مقفـول 〕━━━╮
الأمر ده للأدمن بس 👑
متجيش على شغلي بقى 😏
╰━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
        return;
    }

    try {
        // قفل الجروب
        await sock.groupSettingUpdate(chatId, 'announcement');

        // لو فيه مدة
        if (durationInMinutes !== undefined && durationInMinutes > 0) {

            const durationInMilliseconds = durationInMinutes * 60 * 1000;

            await sock.sendMessage(chatId, {
                text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 🔇
╭━━━〔 تم كتم الجروب 〕━━━╮
⏳ المدة: ${durationInMinutes} دقيقة
محدش يقدر يكتب دلوقتي ❌
╰━━━━━━━━━━━━━━━━╯`
            }, { quoted: message });

            // فك الميوت تلقائي
            setTimeout(async () => {
                try {
                    await sock.groupSettingUpdate(chatId, 'not_announcement');

                    await sock.sendMessage(chatId, {
                        text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 🔊
╭━━━〔 تم فك الكتم 〕━━━╮
الجروب رجع يشتغل تاني ✅
اتفضلوا اتكلموا براحتكم 😎
╰━━━━━━━━━━━━━━━━╯`
                    });

                } catch (unmuteError) {
                    console.error('Error unmuting group:', unmuteError);
                }
            }, durationInMilliseconds);

        } else {

            await sock.sendMessage(chatId, {
                text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 🔇
╭━━━〔 تم كتم الجروب 〕━━━╮
اتقفل لحد ما الأدمن يفكه 🔒
╰━━━━━━━━━━━━━━━━╯`
            }, { quoted: message });
        }

    } catch (error) {
        console.error('Error muting/unmuting the group:', error);

        await sock.sendMessage(chatId, {
            text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❌
╭━━━〔 حصل خطأ 〕━━━╮
مش عارف أكتم الجروب 😔
جرب تاني بعد شوية ⏳
╰━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
    }
}

module.exports = muteCommand;