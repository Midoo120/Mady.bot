const isAdmin = require('../lib/isAdmin');

async function kickCommand(sock, chatId, senderId, mentionedJids, message) {

    const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";
    const isOwner = message.key.fromMe;

    if (!isOwner) {
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

        // البوت مش أدمن
        if (!isBotAdmin) {
            await sock.sendMessage(
                chatId,
                {
                    text:
`╭━━━〔 ⚠️ ${botName} 〕━━━╮

لازم تخليني أدمن الأول 👮‍♂️
عشان أقدر أطرد الأعضاء

╰━━━━━━━━━━━━━━━━━━╯`
                },
                { quoted: message }
            );
            return;
        }

        // الشخص مش أدمن
        if (!isSenderAdmin) {
            await sock.sendMessage(
                chatId,
                {
                    text:
`╭━━━〔 ⛔ ${botName} 〕━━━╮

الأمر دا للأدمن بس 👑
مش متاح لكل الأعضاء

╰━━━━━━━━━━━━━━━━━━╯`
                },
                { quoted: message }
            );
            return;
        }
    }

    // تحديد الشخص
    let usersToKick = [];

    if (mentionedJids && mentionedJids.length > 0) {
        usersToKick = mentionedJids;
    }
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        usersToKick = [message.message.extendedTextMessage.contextInfo.participant];
    }

    if (usersToKick.length === 0) {
        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❗ ${botName} 〕━━━╮

منشن على الشخص
أو اعمل ريبلاي على رسايله

عشان أطرده 👢

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
        return;
    }

    // حماية البوت
    const botId = sock.user?.id || '';
    const botPhone = botId.split('@')[0];

    const isTryingToKickBot = usersToKick.some(
        user => user.includes(botPhone)
    );

    if (isTryingToKickBot) {
        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 🤖 ${botName} 〕━━━╮

إنت بتهزر؟ 😂
مش هطرد نفسي طبعاً

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
        return;
    }

    // تنفيذ الطرد
    try {
        await sock.groupParticipantsUpdate(
            chatId,
            usersToKick,
            "remove"
        );

        const usernames = usersToKick.map(
            jid => `@${jid.split('@')[0]}`
        );

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 👢 ${botName} 〕━━━╮

تم طرد العضو بنجاح ✅

${usernames.join('\n')}

مع السلامة يا نجم 👋

╰━━━━━━━━━━━━━━━━━━╯`,
                mentions: usersToKick
            }
        );

    } catch (error) {
        console.error('Error in kick command:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❌ ${botName} 〕━━━╮

فشل طرد العضو 😅
جرب تاني بعد شوية

╰━━━━━━━━━━━━━━━━━━╯`
            }
        );
    }
}

module.exports = kickCommand;