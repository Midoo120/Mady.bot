const fetch = require('node-fetch');

const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

async function dareCommand(sock, chatId, message) {
    try {
        const shizokeys = 'shizo';

        const res = await fetch(
            `https://shizoapi.onrender.com/api/texts/dare?apikey=${shizokeys}`
        );

        if (!res.ok) {
            throw await res.text();
        }

        const json = await res.json();
        const dareText = json.result;

        // ───────────── رسالة التحدي ─────────────
        const dareMessage =
`╭━━━〔 🔥 تحدي لك 〕━━━╮

${dareText}

╰━━━〔 🤖 ${botName} 〕━━━╯`;

        await sock.sendMessage(
            chatId,
            { text: dareMessage },
            { quoted: message }
        );

    } catch (error) {
        console.error('Error in dare command:', error);

        // ───────────── رسالة الخطأ ─────────────
        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❌ خطأ 〕━━━╮

فشل جلب التحدي 😢  
حاول تاني بعد شوية

╰━━━〔 🤖 ${botName} 〕━━━╯`
            },
            { quoted: message }
        );
    }
}

module.exports = { dareCommand };