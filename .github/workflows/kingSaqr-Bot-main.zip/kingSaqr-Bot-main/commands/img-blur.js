const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const sharp = require('sharp');

async function blurCommand(sock, chatId, message, quotedMessage) {

    const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

    try {

        let imageBuffer;

        // لو ريبلاي على صورة
        if (quotedMessage) {

            if (!quotedMessage.imageMessage) {
                return await sock.sendMessage(
                    chatId,
                    {
                        text:
`╭━━━〔 ⚠️ ${botName} 〕━━━╮

❌ لازم ترد على صورة عشان أعملها بلور

╰━━━━━━━━━━━━━━━━━━╯`
                    },
                    { quoted: message }
                );
            }

            const quoted = {
                message: {
                    imageMessage: quotedMessage.imageMessage
                }
            };

            imageBuffer = await downloadMediaMessage(
                quoted,
                'buffer',
                {},
                {}
            );

        }

        // لو الصورة في نفس الرسالة
        else if (message.message?.imageMessage) {

            imageBuffer = await downloadMediaMessage(
                message,
                'buffer',
                {},
                {}
            );

        }

        // مفيش صورة
        else {
            return await sock.sendMessage(
                chatId,
                {
                    text:
`╭━━━〔 ⚠️ ${botName} 〕━━━╮

فين الصورة؟ 🧐

📌 ابعت صورة مع الأمر  
أو اعمل ريبلاي على صورة

مثال:
.blur

╰━━━━━━━━━━━━━━━━━━╯`
                },
                { quoted: message }
            );
        }

        // تصغير + تحسين الجودة
        const resizedImage = await sharp(imageBuffer)
            .resize(800, 800, {
                fit: 'inside',
                withoutEnlargement: true
            })
            .jpeg({ quality: 80 })
            .toBuffer();

        // تطبيق البلور
        const blurredImage = await sharp(resizedImage)
            .blur(10)
            .toBuffer();

        // إرسال الصورة
        await sock.sendMessage(
            chatId,
            {
                image: blurredImage,
                caption:
`╭━━━〔 🌫️ ${botName} 〕━━━╮

✔ تم تمويه الصورة بنجاح

استمتع بالخصوصية 😎

╰━━━━━━━━━━━━━━━━━━╯`,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true
                }
            },
            { quoted: message }
        );

    } catch (error) {

        console.error('Error in blur command:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❌ ${botName} 〕━━━╮

فشل تمويه الصورة 😢

حاول تاني بعد شوية

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
    }
}

module.exports = blurCommand;