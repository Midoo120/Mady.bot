const moment = require('moment-timezone');
const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');

async function githubCommand(sock, chatId, message) {
  try {
    const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

    // ✅ GitHub API الصحيح
    const res = await fetch(
      'https://api.github.com/repos/kingsaqr/Bot-king-Saqr4'
    );

    if (!res.ok) throw new Error('API Error');

    const json = await res.json();

    // 🕒 تنسيق الوقت
    const lastUpdate = moment(json.updated_at)
      .tz('Africa/Cairo')
      .format('DD/MM/YYYY - hh:mm A');

    // 💎 الرسالة المزخرفة
    let txt = `
╭━━━〔 🐙 GitHub Info 〕━━━╮

📦 الاسم :
➤ ${json.name}

⭐ النجوم :
➤ ${json.stargazers_count}

🍴 الفوركات :
➤ ${json.forks_count}

👀 المشاهدات :
➤ ${json.watchers_count}

💾 الحجم :
➤ ${(json.size / 1024).toFixed(2)} MB

🕒 آخر تحديث :
➤ ${lastUpdate}

🔗 الرابط :
${json.html_url}

╰━━━〔 🤖 ${botName} 〕━━━╯
`.trim();

    // 🖼️ صورة البوت
    const imgPath = path.join(__dirname, '../assets/bot_image.jpg');
    const imgBuffer = fs.readFileSync(imgPath);

    await sock.sendMessage(
      chatId,
      {
        image: imgBuffer,
        caption: txt
      },
      { quoted: message }
    );

  } catch (error) {
    console.error(error);

    await sock.sendMessage(
      chatId,
      {
        text:
`╭━━━〔 ❌ 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 〕━━━╮

فشلـت أجيب معلومات الريبو 😢  
تأكد من الرابط أو جرّب تاني

╰━━━━━━━━━━━━━━━━━━╯`
      },
      { quoted: message }
    );
  }
}

module.exports = githubCommand;