const { isAdmin } = require('../lib/isAdmin');

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 🔱 Promote Command
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

async function promoteCommand(sock, chatId, mentionedJids, message) {
    let userToPromote = [];
    
    // لو في منشن
    if (mentionedJids && mentionedJids.length > 0) {
        userToPromote = mentionedJids;
    }
    // لو ريبلاي
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToPromote = [
            message.message.extendedTextMessage.contextInfo.participant
        ];
    }
    
    if (userToPromote.length === 0) {
        await sock.sendMessage(chatId, { 
            text: `
╭━━━〔 ⚠️ تنبيه يا نجم 〕━━━╮
┃
┃ لازم تمنشن الشخص
┃ أو ترد على رسالته
┃ عشان أرقّيه 👑
┃
╰━━━━━━━━━━━━━━━━╯
`
        });
        return;
    }

    try {
        await sock.groupParticipantsUpdate(
            chatId,
            userToPromote,
            "promote"
        );
        
        const usernames = userToPromote.map(
            jid => `@${jid.split('@')[0]}`
        );

        const promoterJid = sock.user.id;

        const promotionMessage = `
╭━━━〔 👑 تـــمـــت التــرقــيــة 〕━━━╮
┃
┃ 🎉 مبروك يا نجم اتـرقيـت!
┃
┃ 👥 الأعضاء الجداد:
┃ ${usernames.map(u => `┃ • ${u}`).join('\n')}
┃
┃ 🛡️ بقى معاه صلاحيات أدمن
┃ فـ خلو بالكم بقا 😎
┃
┃ 👑 بواسطة:
┃ @${promoterJid.split('@')[0]}
┃
┃ 📅 التاريخ:
┃ ${new Date().toLocaleString('ar-EG')}
┃
┃ 🤖 𝗞𝗡𝗜𝗚𝗛𝗧 — 𝗕𝗢𝗧
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯
`;

        await sock.sendMessage(chatId, { 
            text: promotionMessage,
            mentions: [...userToPromote, promoterJid]
        });

    } catch (error) {
        console.error('Error in promote command:', error);

        await sock.sendMessage(chatId, { 
            text: `
╭━━━〔 ❌ فشل الترقية 〕━━━╮
┃
┃ حصلت مشكلة وأنا برقيه 😔
┃ اتأكد إني أدمن الأول
┃ وبعدين جرّب تاني
┃
╰━━━━━━━━━━━━━━╯
`
        });
    }
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 🔔 Auto Promotion Event
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

async function handlePromotionEvent(sock, groupId, participants, author) {
    try {
        if (!Array.isArray(participants) || participants.length === 0) return;

        const promotedUsernames = participants.map(jid => {
            const id = typeof jid === 'string'
                ? jid
                : (jid.id || jid.toString());

            return `@${id.split('@')[0]}`;
        });

        let mentionList = participants.map(jid =>
            typeof jid === 'string'
                ? jid
                : (jid.id || jid.toString())
        );

        let promotedBy = 'System';

        if (author) {
            const authorJid = typeof author === 'string'
                ? author
                : (author.id || author.toString());

            promotedBy = `@${authorJid.split('@')[0]}`;
            mentionList.push(authorJid);
        }

        const promotionMessage = `
╭━━━〔 🔔 إشعار ترقية 〕━━━╮
┃
┃ في حد اتـرقي هنا 👑
┃
┃ 👥 العضو:
┃ ${promotedUsernames.map(u => `┃ • ${u}`).join('\n')}
┃
┃ 🛡️ بواسطة:
┃ ${promotedBy}
┃
┃ 📅 التاريخ:
┃ ${new Date().toLocaleString('ar-EG')}
┃
┃ 🤖 𝗞𝗡𝗜𝗚𝗛𝗧 — 𝗕𝗢𝗧
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯
`;

        await sock.sendMessage(groupId, {
            text: promotionMessage,
            mentions: mentionList
        });

    } catch (error) {
        console.error('Error handling promotion event:', error);
    }
}

module.exports = { promoteCommand, handlePromotionEvent };