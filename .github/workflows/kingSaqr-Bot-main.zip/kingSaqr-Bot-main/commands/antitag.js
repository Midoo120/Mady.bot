const { setAntitag, getAntitag, removeAntitag } = require('../lib/index');
const isAdmin = require('../lib/isAdmin');

async function handleAntitagCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message) {
try {
if (!isSenderAdmin) {
await sock.sendMessage(chatId, { text: '𓆩⚠️𓆪 دي أوامر الأدمن بس يا نجم… متحاولش تتنطط 😏' },{quoted :message});
return;
}

    const prefix = '.';
    const args = userMessage.slice(9).toLowerCase().trim().split(' ');
    const action = args[0];

    if (!action) {
        const usage = `╭───⟢ 𓇢𓆸𝑴𝒂♪𝒅𝒚➛ 𝗔𝗡𝗧𝗜 𝗧𝗔𝗚 ⟢───╮

│
│  ⌁ ${prefix}antitag on
│  ⌁ ${prefix}antitag set delete | kick
│  ⌁ ${prefix}antitag off
│
╰───────────────╯`;
await sock.sendMessage(chatId, { text: usage },{quoted :message});
return;
}

    switch (action) {
        case 'on':
            const existingConfig = await getAntitag(chatId, 'on');
            if (existingConfig?.enabled) {
                await sock.sendMessage(chatId, { text: '𓆩😏𓆪 الأنتي تاج شغّال أصلاً… إنت بتجرب وخلاص ولا إيه؟' },{quoted :message});
                return;
            }
            const result = await setAntitag(chatId, 'on', 'delete');
            await sock.sendMessage(chatId, { 
                text: result ? '𓆩🔥𓆪 تم تشغيل الأنتي تاج… أي تاج عشوائي هيتفشخ فوراً 😈' : '𓆩❌𓆪 حصلت مشكلة وأنا بشغّله… جرّب تاني' 
            },{quoted :message});
            break;

        case 'off':
            await removeAntitag(chatId, 'on');
            await sock.sendMessage(chatId, { text: '𓆩🛑𓆪 تمام… قفلت الأنتي تاج… بس متجيش تعيط لما الجروب يتقلب سبام 😏' },{quoted :message});
            break;

        case 'set':
            if (args.length < 2) {
                await sock.sendMessage(chatId, { 
                    text: `𓆩⚙️𓆪 حدّد العقاب يا كبير:\n${prefix}antitag set delete | kick` 
                },{quoted :message});
                return;
            }
            const setAction = args[1];
            if (!['delete', 'kick'].includes(setAction)) {
                await sock.sendMessage(chatId, { 
                    text: '𓆩❌𓆪 اختيار غلط… يا Delete يا Kick مفيش هزار 😈' 
                },{quoted :message});
                return;
            }
            const setResult = await setAntitag(chatId, 'on', setAction);
            await sock.sendMessage(chatId, { 
                text: setResult ? `𓆩⚡𓆪 تم تعيين العقاب: ${setAction.toUpperCase()} … اللي هيغلط هيتفشخ فوراً 😏` : '𓆩❌𓆪 معرفتش أظبط الإعداد… جرّب تاني' 
            },{quoted :message});
            break;

        case 'get':
            const status = await getAntitag(chatId, 'on');
            const actionConfig = await getAntitag(chatId, 'on');
            await sock.sendMessage(chatId, { 
                text: `╭───⟢ 𓇢𓆸𝑴𝒂♪𝒅𝒚➛ ⟢───╮

│
│  ⌁ الحالة: ${status ? '🔥 شغّال' : '🛑 مقفول'}
│  ⌁ العقاب: ${actionConfig ? actionConfig.action : 'لسه متحددش'}
│
╰───────────────╯`
},{quoted :message});
break;

        default:
            await sock.sendMessage(chatId, { text: `𓆩📜𓆪 استخدم ${prefix}antitag وشوف الأوامر… متألفش من عندك 😏` },{quoted :message});
    }
} catch (error) {
    console.error('Error in antitag command:', error);
    await sock.sendMessage(chatId, { text: '𓆩💀𓆪 حصل Error وأنا بشغّل الأنتي تاج… شكلي هجلد حد 😈' },{quoted :message});
}

}

async function handleTagDetection(sock, chatId, message, senderId) {
try {
const antitagSetting = await getAntitag(chatId, 'on');
if (!antitagSetting || !antitagSetting.enabled) return;

    const mentionedJids = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    
    const messageText = (
        message.message?.conversation ||
        message.message?.extendedTextMessage?.text ||
        message.message?.imageMessage?.caption ||
        message.message?.videoMessage?.caption ||
        ''
    );

    const textMentions = messageText.match(/@[\d+\s\-()~.]+/g) || [];
    const numericMentions = messageText.match(/@\d{10,}/g) || [];
    
    const allMentions = [...new Set([...mentionedJids, ...textMentions, ...numericMentions])];
    
    const uniqueNumericMentions = new Set();
    numericMentions.forEach(mention => {
        const numMatch = mention.match(/@(\d+)/);
        if (numMatch) uniqueNumericMentions.add(numMatch[1]);
    });
    
    const mentionedJidCount = mentionedJids.length;
    const numericMentionCount = uniqueNumericMentions.size;
    const totalMentions = Math.max(mentionedJidCount, numericMentionCount);

    if (totalMentions >= 3) {
        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants || [];
        
        const mentionThreshold = Math.ceil(participants.length * 0.5);
        
        const hasManyNumericMentions = numericMentionCount >= 10 || 
                                      (numericMentionCount >= 5 && numericMentionCount >= mentionThreshold);
        
        if (totalMentions >= mentionThreshold || hasManyNumericMentions) {
            
            const action = antitagSetting.action || 'delete';
            
            if (action === 'delete') {
                await sock.sendMessage(chatId, {
                    delete: {
                        remoteJid: chatId,
                        fromMe: false,
                        id: message.key.id,
                        participant: senderId
                    }
                });
                
                await sock.sendMessage(chatId, {
                    text: `𓆩⚠️𓆪 إيه يا نجم… عامل Tagall ليه؟ الرسالة اتمسحت فوراً 😏`
                }, { quoted: message });
                
            } else if (action === 'kick') {
                await sock.sendMessage(chatId, {
                    delete: {
                        remoteJid: chatId,
                        fromMe: false,
                        id: message.key.id,
                        participant: senderId
                    }
                });

                await sock.groupParticipantsUpdate(chatId, [senderId], "remove");

                const usernames = [`@${senderId.split('@')[0]}`];
                await sock.sendMessage(chatId, {
                    text: `𓆩🚫𓆪 مسكناك بتعمل Tagall يا شبح… اتطردت برا الجروب 😈🔥`,
                    mentions: [senderId]
                }, { quoted: message });
            }
        }
    }
} catch (error) {
    console.error('Error in tag detection:', error);
}

}

module.exports = {
handleAntitagCommand,
handleTagDetection
};