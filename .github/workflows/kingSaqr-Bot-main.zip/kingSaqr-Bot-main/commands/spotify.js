const axios = require('axios');

async function spotifyCommand(sock, chatId, message) {
    try {
        const sender =
            message.key.participant || message.key.remoteJid;
        const user = sender.split('@')[0];

        const rawText =
            message.message?.conversation?.trim() ||
            message.message?.extendedTextMessage?.text?.trim() ||
            message.message?.imageMessage?.caption?.trim() ||
            message.message?.videoMessage?.caption?.trim() ||
            '';

        const used =
            (rawText || '').split(/\s+/)[0] || '.spotify';

        const query = rawText.slice(used.length).trim();

        // ❌ مفيش بحث
        if (!query) {
            return await sock.sendMessage(
                chatId,
                {
                    text: `
╔═══〔 🎧 تحميل من سبوتيفاي 〕═══╗
║
║ 📌 الاستخدام:
║ .spotify <اسم الأغنية>
║
║ 🧠 مثال:
║ .spotify con calma
║
║ 👤 الطلب بواسطة:
║ @${user}
║
╚════════════════════╝
`.trim(),
                    mentions: [sender]
                },
                { quoted: message }
            );
        }

        // ⏳ رسالة انتظار
        await sock.sendMessage(
            chatId,
            {
                text: `
⏳ استنى يا @${user}

بدورلك على:
🎶 ${query}

ثواني كدا و أجيبهالك 💿🔥
`.trim(),
                mentions: [sender]
            },
            { quoted: message }
        );

        // 🌐 API
        const apiUrl =
            `https://okatsu-rolezapiiz.vercel.app/search/spotify?q=${encodeURIComponent(query)}`;

        const { data } = await axios.get(apiUrl, {
            timeout: 20000,
            headers: { 'user-agent': 'Mozilla/5.0' }
        });

        if (!data?.status || !data?.result) {
            throw new Error('No result from Spotify API');
        }

        const r = data.result;
        const audioUrl = r.audio;

        if (!audioUrl) {
            return await sock.sendMessage(
                chatId,
                {
                    text: `
❌ للأسف يا @${user}

ملقتش تحميل للأغنية دي 😅
جرب اسم تاني أو فنان تاني
`.trim(),
                    mentions: [sender]
                },
                { quoted: message }
            );
        }

        // 🎶 كابشن النتيجة
        const caption = `
╔═══〔 🎶 تم العثور على الأغنية 〕═══╗
║
║ 🏷 الاسم:
║ ${r.title || r.name || 'غير معروف'}
║
║ 👤 الفنان:
║ ${r.artist || 'غير معروف'}
║
║ ⏱ المدة:
║ ${r.duration || 'غير محدد'}
║
║ 🔗 الرابط:
║ ${r.url || '—'}
║
║ 📥 تحميل تحت 👇
║
║ 👤 الطلب بواسطة:
║ @${user}
║
╚════════════════════╝
`.trim();

        // 🖼️ الغلاف
        if (r.thumbnails) {
            await sock.sendMessage(
                chatId,
                {
                    image: { url: r.thumbnails },
                    caption,
                    mentions: [sender]
                },
                { quoted: message }
            );
        } else {
            await sock.sendMessage(
                chatId,
                {
                    text: caption,
                    mentions: [sender]
                },
                { quoted: message }
            );
        }

        // 🎧 إرسال الصوت
        await sock.sendMessage(
            chatId,
            {
                audio: { url: audioUrl },
                mimetype: 'audio/mpeg',
                fileName: `${(r.title || r.name || 'track')
                    .replace(/[\\/:*?"<>|]/g, '')}.mp3`
            },
            { quoted: message }
        );

    } catch (error) {
        console.error('[SPOTIFY] error:', error?.message || error);

        const sender =
            message.key.participant || message.key.remoteJid;
        const user = sender.split('@')[0];

        await sock.sendMessage(
            chatId,
            {
                text: `
╔═══〔 ❌ حصلت مشكلة 〕═══╗
║
║ بص يا @${user}
║
║ السيرفر شكله نايم 😴
║ أو الأغنية مش متاحة
║
║ جرب تاني بعد شوية 🔄
║
╚════════════════════╝
`.trim(),
                mentions: [sender]
            },
            { quoted: message }
        );
    }
}

module.exports = spotifyCommand;