const fetch = require('node-fetch');

async function goodnightCommand(sock, chatId, message) {
    try {
        const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";
        const shizokeys = 'shizo';

        const res = await fetch(
            `https://shizoapi.onrender.com/api/texts/lovenight?apikey=${shizokeys}`
        );

        if (!res.ok) {
            throw await res.text();
        }

        const json = await res.json();
        const apiMessage = json.result;

        // 🌙 الرسالة المزخرفة
        const goodnightMessage = `
╭━━━〔 🌙 ${botName} 〕━━━╮

${apiMessage}

✨ تصبح على خير يا جميل  
🛌 نوم الهنا وأحلام سعيدة  

╰━━━━━━━━━━━━━━━━━━╯
`.trim();

        // 📤 إرسال الرسالة
        await sock.sendMessage(
            chatId,
            { text: goodnightMessage },
            { quoted: message }
        );

    } catch (error) {
        console.error('Error in goodnight command:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❌ 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 〕━━━╮

فشلـت أجيب رسالة تصبح على خير 😢  
حاول تاني بعد شوية

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
    }
}

module.exports = { goodnightCommand };