const axios = require('axios');
const { channelInfo } = require('../lib/messageConfig');

async function characterCommand(sock, chatId, message) {
    const BOT_NAME = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

    let userToAnalyze;
    
    // منشن
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToAnalyze = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    // رد
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToAnalyze = message.message.extendedTextMessage.contextInfo.participant;
    }
    
    if (!userToAnalyze) {
        await sock.sendMessage(chatId, { 
            text:
`╭━━━〔 ❌ خطأ 〕━━━╮

منشن على حد أو اعمل رد على رسالته
علشان أحلل شخصيته 🧠

╰━━━〔 ${BOT_NAME} 〕━━━╯`,
            ...channelInfo 
        });
        return;
    }

    try {
        // صورة البروفايل
        let profilePic;
        try {
            profilePic = await sock.profilePictureUrl(userToAnalyze, 'image');
        } catch {
            profilePic = 'https://i.imgur.com/2wzGhpF.jpeg';
        }

        // الصفات بالعربي
        const traits = [
            "ذكي 🧠",
            "دمه خفيف 😂",
            "جدع 💪",
            "طيب ❤️",
            "مبدع 🎨",
            "شخصية قيادية 👑",
            "حنين 🫶",
            "رايق 😎",
            "صاحب صاحبه 🤝",
            "طموح 🚀",
            "صبور 🕊️",
            "قلبه أبيض 🤍",
            "اجتماعي 🗣️",
            "غلبان شوية 🥹",
            "روش 🔥"
        ];

        // اختيار صفات
        const numTraits = Math.floor(Math.random() * 3) + 3;
        const selectedTraits = [];

        while (selectedTraits.length < numTraits) {
            const t = traits[Math.floor(Math.random() * traits.length)];
            if (!selectedTraits.includes(t)) selectedTraits.push(t);
        }

        // نسب
        const traitPercentages = selectedTraits.map(trait => {
            const percentage = Math.floor(Math.random() * 41) + 60;
            return `• ${trait} : ${percentage}%`;
        });

        // التقييم العام
        const overall = Math.floor(Math.random() * 21) + 80;

        // الرسالة
        const analysis =
`╭━━━〔 🔮 تحليل الشخصية 〕━━━╮

👤 الشخص :
@${userToAnalyze.split('@')[0]}

┈┈┈┈┈┈┈┈┈┈

✨ أبرز صفاته :

${traitPercentages.join('\n')}

┈┈┈┈┈┈┈┈┈┈

🎯 التقييم العام :
${overall}%

💬 ملحوظة :
التحليل للتسلية بس يا معلم 😂

╰━━━〔 ${BOT_NAME} 〕━━━╯`;

        await sock.sendMessage(chatId, {
            image: { url: profilePic },
            caption: analysis,
            mentions: [userToAnalyze],
            ...channelInfo
        });

    } catch (error) {
        console.error('Error in character command:', error);

        await sock.sendMessage(chatId, { 
            text:
`╭━━━〔 ❌ فشل التحليل 〕━━━╮

حصلت مشكلة وأنا بحلل الشخصية 😅
جرّب تاني بعد شوية

╰━━━〔 ${BOT_NAME} 〕━━━╯`,
            ...channelInfo 
        });
    }
}

module.exports = characterCommand;