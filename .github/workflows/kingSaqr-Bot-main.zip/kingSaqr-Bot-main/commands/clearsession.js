const fs = require('fs');
const path = require('path');
const isOwnerOrSudo = require('../lib/isOwner');

const BOT_NAME = "𓆩 King Saqr 𓆪";

const channelInfo = {
    contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
    }
};

async function clearSessionCommand(sock, chatId, msg) {
    try {
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);

        // ───── صلاحيات ─────
        if (!msg.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ❌ صلاحيات 〕━━━╮

الأمر ده للمالك بس يا كبير 👑

╰━━━〔 ${BOT_NAME} 〕━━━╯`,
                ...channelInfo
            });
            return;
        }

        // ───── مسار السيشن ─────
        const sessionDir = path.join(__dirname, '../session');

        if (!fs.existsSync(sessionDir)) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ❌ خطأ 〕━━━╮

فولدر السيشن مش موجود ❗

╰━━━〔 ${BOT_NAME} 〕━━━╯`,
                ...channelInfo
            });
            return;
        }

        // ───── رسالة بدء ─────
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 🔄 جاري التنظيف 〕━━━╮

بيتم تحسين ملفات السيشن
لزيادة السرعة والأداء ⚡

استنى ثواني بس…

╰━━━〔 ${BOT_NAME} 〕━━━╯`,
            ...channelInfo
        });

        const files = fs.readdirSync(sessionDir);

        let filesCleared = 0;
        let errors = 0;
        let errorDetails = [];

        let appStateSyncCount = 0;
        let preKeyCount = 0;

        // ───── إحصائيات ─────
        for (const file of files) {
            if (file.startsWith('app-state-sync-')) appStateSyncCount++;
            if (file.startsWith('pre-key-')) preKeyCount++;
        }

        // ───── حذف ─────
        for (const file of files) {
            if (file === 'creds.json') continue;

            try {
                const filePath = path.join(sessionDir, file);
                fs.unlinkSync(filePath);
                filesCleared++;
            } catch (error) {
                errors++;
                errorDetails.push(`• ${file}`);
            }
        }

        // ───── رسالة نجاح ─────
        const doneMsg =
`╭━━━〔 ✅ تم التنظيف 〕━━━╮

🧹 تم مسح ملفات السيشن بنجاح

📊 الإحصائيات:

• المحذوف: ${filesCleared}
• App State: ${appStateSyncCount}
• Pre-Keys: ${preKeyCount}
${errors > 0 ? `\n⚠️ أخطاء: ${errors}` : ''}

╰━━━〔 ${BOT_NAME} 〕