const settings = require('../settings');

async function ownerCommand(sock, chatId) {

    // رسالة قبل الكونتاكت
    await sock.sendMessage(chatId, {
        text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❖
╭━━━〔 👑 مـالـك البـوت 〕━━━╮
ده رقـم صـاحـب البـوت يـا نجـم 📞
لـو محتـاج مسـاعـدة كلمـه علطـول 💬
╰━━━━━━━━━━━━━━━━╯`
    });

    // إنشاء الفيكارد
    const vcard = `
BEGIN:VCARD
VERSION:3.0
FN:${settings.botOwner}
ORG:𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ Bot
TEL;type=CELL;type=VOICE;waid=${settings.ownerNumber}:${settings.ownerNumber}
END:VCARD
`;

    // إرسال الكونتاكت
    await sock.sendMessage(chatId, {
        contacts: {
            displayName: `👑 ${settings.botOwner}`,
            contacts: [{ vcard }]
        },
    });
}

module.exports = ownerCommand;