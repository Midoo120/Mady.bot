const fs = require('fs');

const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

// كلمات اللعبة
const words = [
    'javascript',
    'bot',
    'hangman',
    'whatsapp',
    'nodejs'
];

let hangmanGames = {};

// 🎮 بدء اللعبة
function startHangman(sock, chatId) {

    const word = words[Math.floor(Math.random() * words.length)];
    const maskedWord = '_ '.repeat(word.length).trim();

    hangmanGames[chatId] = {
        word,
        maskedWord: maskedWord.split(' '),
        guessedLetters: [],
        wrongGuesses: 0,
        maxWrongGuesses: 6,
    };

    sock.sendMessage(chatId, {
        text:
`╭━━━〔 🎮 ${botName} 〕━━━╮

بدأنا لعبة الرجل المشنوق 😈

🔤 الكلمة:

${maskedWord}

اكتب الحرف كده:
.hangman a

╰━━━━━━━━━━━━━━━━━━╯`
    });
}

// 🔤 تخمين حرف
function guessLetter(sock, chatId, letter) {

    if (!hangmanGames[chatId]) {
        sock.sendMessage(chatId, {
            text:
`╭━━━〔 ⚠️ ${botName} 〕━━━╮

مفيش لعبة شغالة دلوقتي ❌

ابدأ واحدة بـ:
.hangman

╰━━━━━━━━━━━━━━━━━━╯`
        });
        return;
    }

    const game = hangmanGames[chatId];
    const { word, guessedLetters, maskedWord, maxWrongGuesses } = game;

    // حرف متكرر
    if (guessedLetters.includes(letter)) {
        sock.sendMessage(chatId, {
            text:
`╭━━━〔 😑 ${botName} 〕━━━╮

الحرف "${letter}" اتقال قبل كده

جرب غيره يا نجم ⭐

╰━━━━━━━━━━━━━━━━━━╯`
        });
        return;
    }

    guessedLetters.push(letter);

    // ✅ تخمين صح
    if (word.includes(letter)) {

        for (let i = 0; i < word.length; i++) {
            if (word[i] === letter) {
                maskedWord[i] = letter;
            }
        }

        sock.sendMessage(chatId, {
            text:
`╭━━━〔 ✅ ${botName} 〕━━━╮

حرف صح 👏🔥

${maskedWord.join(' ')}

╰━━━━━━━━━━━━━━━━━━╯`
        });

        // 🎉 فوز
        if (!maskedWord.includes('_')) {

            sock.sendMessage(chatId, {
                text:
`╭━━━〔 🏆 ${botName} 〕━━━╮

مبروك كسبت يا بطل 🎉

الكلمة كانت:
『 ${word} 』

╰━━━━━━━━━━━━━━━━━━╯`
            });

            delete hangmanGames[chatId];
        }

    }

    // ❌ تخمين غلط
    else {

        game.wrongGuesses += 1;

        const triesLeft = maxWrongGuesses - game.wrongGuesses;

        sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ ${botName} 〕━━━╮

حرف غلط 😵

متبقي:
${triesLeft} محاولة

${maskedWord.join(' ')}

╰━━━━━━━━━━━━━━━━━━╯`
        });

        // 💀 خسارة
        if (game.wrongGuesses >= maxWrongGuesses) {

            sock.sendMessage(chatId, {
                text:
`╭━━━〔 💀 ${botName} 〕━━━╮

خسرت اللعبة 😢

الكلمة كانت:
『 ${word} 』

جرب تاني بـ:
.hangman

╰━━━━━━━━━━━━━━━━━━╯`
            });

            delete hangmanGames[chatId];
        }
    }
}

module.exports = { startHangman, guessLetter };