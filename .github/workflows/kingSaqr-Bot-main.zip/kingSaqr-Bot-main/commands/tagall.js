const isAdmin = require('../lib/isAdmin'); // فحص الأدمن

async function tagAllCommand(sock, chatId, senderId, message) {
try {
const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

    // 🤖 لو البوت مش أدمن
    if (!isBotAdmin) {
        await sock.sendMessage(chatId, {
            text:

`❌ البوت مش أدمن!

📌 لازم تخلّي البوت أدمن
علشان يقدر يعمل منشن لكل الأعضاء 👮‍♂️`
}, { quoted: message });
return;
}

    // 👑 لو المستخدم مش أدمن
    if (!isSenderAdmin) {
        await sock.sendMessage(chatId, {
            text:

`❌ مش مسموح!

الأمر ده خاص بمسؤولي الجروب بس 👮‍♂️

لو محتاج تعمله،
اطلب من أدمن ينفذه 👍`
}, { quoted: message });
return;
}

    // 📋 بيانات الجروب
    const groupMetadata = await sock.groupMetadata(chatId);
    const participants = groupMetadata.participants;

    if (!participants || participants.length === 0) {
        await sock.sendMessage(chatId, {
            text:

`⚠️ مشكلة في جلب الأعضاء

البوت مقدرش يجيب قائمة المشاركين ❌`
}, { quoted: message });
return;
}

    // 📢 رسالة المنشن الجماعي
    let messageText =

`🔊 نداء عام لكل الأعضاء

━━━━━━━━━━━━━━━
👥 الحضور بسرعة يحبايبي :

`;

    participants.forEach(participant => {
        messageText += `➤ @${participant.id.split('@')[0]}\n`;
    });

    messageText +=

"\n━━━━━━━━━━━━━━━ 📌 تم المنشن بواسطة الأدمن 👑";

    // 🚀 إرسال الرسالة مع المنشن
    await sock.sendMessage(chatId, {
        text: messageText,
        mentions: participants.map(p => p.id)
    });

} catch (error) {
    console.error('خطأ في أمر tagall:', error);

    await sock.sendMessage(chatId, {
        text:

`❌ حصل خطأ أثناء المنشن

فشل البوت يعمل تاج لكل الأعضاء…
حاول تاني بعد شوية ⚠️`
});
}
}

module.exports = tagAllCommand;