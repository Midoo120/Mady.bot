const sharp = require('sharp');
const fs = require('fs');
const fsPromises = require('fs/promises');
const fse = require('fs-extra');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

const tempDir = './temp';
if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);

// حذف الملفات المؤقتة
const scheduleFileDeletion = (filePath) => {
    setTimeout(async () => {
        try {
            await fse.remove(filePath);
            console.log(`Deleted: ${filePath}`);
        } catch (error) {
            console.error(`Delete failed:`, error);
        }
    }, 10000);
};

const convertStickerToImage = async (sock, quotedMessage, chatId, message) => {
    try {

        const stickerMessage = quotedMessage.stickerMessage;

        if (!stickerMessage) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ❌ يسطا استنى 〕━━━╮
┃
┃ رد على استيكر بس
┃ واكتب .simage
┃
┃ متحطليش كلام فاضي 😂
┃
╰━━━━━━━━━━━━━━━╯`
            }, { quoted: message });
            return;
        }

        const stickerFilePath =
            path.join(tempDir, `sticker_${Date.now()}.webp`);

        const outputImagePath =
            path.join(tempDir, `converted_${Date.now()}.png`);

        // تحميل الاستيكر
        const stream =
            await downloadContentFromMessage(stickerMessage, 'sticker');

        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        await fsPromises.writeFile(stickerFilePath, buffer);

        // التحويل
        await sharp(stickerFilePath)
            .toFormat('png')
            .toFile(outputImagePath);

        const imageBuffer =
            await fsPromises.readFile(outputImagePath);

        // الكابشن المزخرف
        const caption =
`╭━━━〔 🖼️ تم التحويل 〕━━━╮
┃
┃ الاستيكر بقا صورة عادي
┃ تقدر تحفـظها بقا 📥
┃
┃ خدمة تحويل الاستيكرات
┃ شغالة 24 ساعة 😎
┃
╰━━━━━━━━━━━━━━━╯`;

        // إرسال الصورة
        await sock.sendMessage(chatId, {
            image: imageBuffer,
            caption: caption
        }, { quoted: message });

        // حذف المؤقت
        scheduleFileDeletion(stickerFilePath);
        scheduleFileDeletion(outputImagePath);

    } catch (error) {
        console.error('Error converting sticker:', error);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ حصلت خيبة 〕━━━╮
┃
┃ معرفتش أحول الاستيكر
┃ جرّب تاني كدا
┃
╰━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
    }
};

module.exports = convertStickerToImage;