const fetch = require('node-fetch');

async function handleTranslateCommand(sock, chatId, message, match) {
    try {
        // ⌨️ Typing indicator
        await sock.presenceSubscribe(chatId);
        await sock.sendPresenceUpdate('composing', chatId);

        let textToTranslate = '';
        let lang = '';

        // 🔁 لو ريبلاي
        const quotedMessage =
            message.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (quotedMessage) {
            textToTranslate =
                quotedMessage.conversation ||
                quotedMessage.extendedTextMessage?.text ||
                quotedMessage.imageMessage?.caption ||
                quotedMessage.videoMessage?.caption ||
                '';

            lang = match.trim();
        } else {
            // 📝 لو كتابة مباشرة
            const args = match.trim().split(' ');
            if (args.length < 2) {
                return sock.sendMessage(
                    chatId,
                    {
                        text:
`🌍✨ *TRANSLATOR*

📌 *Usage:*

1️⃣ رد على رسالة واكتب:
.translate <lang>
.trt <lang>

2️⃣ أو اكتب مباشرة:
.translate <text> <lang>

📖 *Example:*
.translate hello fr
.trt good morning ar

🌐 *Languages:*
fr 🇫🇷 French
es 🇪🇸 Spanish
de 🇩🇪 German
it 🇮🇹 Italian
pt 🇵🇹 Portuguese
ru 🇷🇺 Russian
ja 🇯🇵 Japanese
ko 🇰🇷 Korean
zh 🇨🇳 Chinese
ar 🇸🇦 Arabic
hi 🇮🇳 Hindi`
                    },
                    { quoted: message }
                );
            }

            lang = args.pop();
            textToTranslate = args.join(' ');
        }

        if (!textToTranslate) {
            return sock.sendMessage(
                chatId,
                {
                    text: '❌ مفيش نص أترجمه… ابعت نص أو اعمل ريبلاي.',
                },
                { quoted: message }
            );
        }

        // 🔎 APIs
        let translatedText = null;

        // API 1 — Google
        try {
            const res = await fetch(
                `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(
                    textToTranslate
                )}`
            );
            if (res.ok) {
                const data = await res.json();
                translatedText = data?.[0]?.[0]?.[0] || null;
            }
        } catch {}

        // API 2 — MyMemory
        if (!translatedText) {
            try {
                const res = await fetch(
                    `https://api.mymemory.translated.net/get?q=${encodeURIComponent(
                        textToTranslate
                    )}&langpair=auto|${lang}`
                );
                if (res.ok) {
                    const data = await res.json();
                    translatedText =
                        data?.responseData?.translatedText || null;
                }
            } catch {}
        }

        // API 3 — Backup
        if (!translatedText) {
            try {
                const res = await fetch(
                    `https://api.dreaded.site/api/translate?text=${encodeURIComponent(
                        textToTranslate
                    )}&lang=${lang}`
                );
                if (res.ok) {
                    const data = await res.json();
                    translatedText = data?.translated || null;
                }
            } catch {}
        }

        if (!translatedText) {
            throw new Error('All APIs failed');
        }

        // 📤 Send result
        await sock.sendMessage(
            chatId,
            {
                text:
`🌍✨ *Translation Result*

📝 *Original:*
${textToTranslate}

🔄 *Translated (${lang}):*
${translatedText}`
            },
            { quoted: message }
        );

    } catch (error) {
        console.error('❌ Translate Error:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`❌ فشل الترجمة حالياً…

🔁 جرّب تاني بعد شوية.

📌 Usage:
.translate <text> <lang>
أو ريبلاي + اللغة`
            },
            { quoted: message }
        );
    }
}

module.exports = {
    handleTranslateCommand
};