const fs = require('fs');
const path = require('path');
const isOwnerOrSudo = require('../lib/isOwner');

// ───────────── مسح فولدر ─────────────
function clearDirectory(dirPath) {
    try {
        if (!fs.existsSync(dirPath)) {
            return {
                success: false,
                message: `الفولدر مش موجود: ${path.basename(dirPath)}`
            };
        }

        const files = fs.readdirSync(dirPath);
        let deletedCount = 0;

        for (const file of files) {
            try {
                const filePath = path.join(dirPath, file);
                const stat = fs.lstatSync(filePath);

                if (stat.isDirectory()) {
                    fs.rmSync(filePath, { recursive: true, force: true });
                } else {
                    fs.unlinkSync(filePath);
                }

                deletedCount++;
            } catch (err) {
                console.error(`Error deleting ${file}:`, err);
            }
        }

        return {
            success: true,
            message: `تم مسح ${deletedCount} ملف من ${path.basename(dirPath)}`,
            count: deletedCount
        };

    } catch (error) {
        console.error('Error in clearDirectory:', error);

        return {
            success: false,
            message: `فشل مسح ملفات ${path.basename(dirPath)}`,
            error: error.message
        };
    }
}

// ───────────── مسح tmp + temp ─────────────
async function clearTmpDirectory() {
    const tmpDir = path.join(process.cwd(), 'tmp');
    const tempDir = path.join(process.cwd(), 'temp');

    const results = [
        clearDirectory(tmpDir),
        clearDirectory(tempDir)
    ];

    const success = results.every(r => r.success);
    const totalDeleted = results.reduce((s, r) => s + (r.count || 0), 0);
    const message = results.map(r => r.message).join('\n');

    return { success, message, count: totalDeleted };
}

// ───────────── الأمر اليدوي ─────────────
async function clearTmpCommand(sock, chatId, msg) {
    try {
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);

        if (!msg.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ❌ صلاحيات 〕━━━╮

الأمر ده للمالك بس يا نجم 👑

╰━━━〔 🤖 البوت 〕━━━╯`
            });
            return;
        }

        const result = await clearTmpDirectory();

        if (result.success) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 🧹 تنظيف تم 〕━━━╮

${result.message}

🗑️ إجمالي المحذوف: ${result.count}

╰━━━〔 🤖 البوت 〕━━━╯`
            });
        } else {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ❌ حصلت مشكلة 〕━━━╮

${result.message}

╰━━━〔 🤖 البوت 〕━━━╯`
            });
        }

    } catch (error) {
        console.error('Error in cleartmp command:', error);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ Error 〕━━━╮

فشل تنظيف الملفات المؤقتة 😅

╰━━━〔 🤖 البوت 〕━━━╯`
        });
    }
}

// ───────────── الأوتو كلير ─────────────
function startAutoClear() {

    async function runClear() {
        const result = await clearTmpDirectory();

        if (!result.success) {
            console.error(`[AutoClear Error] ${result.message}`);
        } else {
            console.log(`[AutoClear] Deleted ${result.count} files`);
        }
    }

    // أول تشغيل
    runClear();

    // كل 6 ساعات
    setInterval(runClear, 6 * 60 * 60 * 1000);
}

// تشغيل الأوتو
startAutoClear();

module.exports = clearTmpCommand;