async function unmuteCommand(sock, chatId) {
    await sock.groupSettingUpdate(chatId, 'not_announcement'); // فك كتم الجروب
    await sock.sendMessage(chatId, { text: 'تم إلغاء كتم الجروب.' });
}

module.exports = unmuteCommand;