const fs = require('fs');

function readJsonSafe(path, fallback) {
    try {
        const txt = fs.readFileSync(path, 'utf8');
        return JSON.parse(txt);
    } catch (_) {
        return fallback;
    }
}

const isOwnerOrSudo = require('../lib/isOwner');

async function settingsCommand(sock, chatId, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
        
        if (!message.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 🚫 إستنى يا نجم 〕━━━╮
┃
┃ الأمر دا بتاع مالك البوت بس 👑
┃ متحاولش تلعب في الإعدادات 😏
┃
╰━━━━━━━━━━━━━━━━╯`
            }, { quoted: message });
            return;
        }

        const isGroup = chatId.endsWith('@g.us');
        const dataDir = './data';

        const mode = readJsonSafe(`${dataDir}/messageCount.json`, { isPublic: true });
        const autoStatus = readJsonSafe(`${dataDir}/autoStatus.json`, { enabled: false });
        const autoread = readJsonSafe(`${dataDir}/autoread.json`, { enabled: false });
        const autotyping = readJsonSafe(`${dataDir}/autotyping.json`, { enabled: false });
        const pmblocker = readJsonSafe(`${dataDir}/pmblocker.json`, { enabled: false });
        const anticall = readJsonSafe(`${dataDir}/anticall.json`, { enabled: false });
        const userGroupData = readJsonSafe(`${dataDir}/userGroupData.json`, {
            antilink: {}, antibadword: {}, welcome: {}, goodbye: {}, chatbot: {}, antitag: {}
        });

        const autoReaction = Boolean(userGroupData.autoReaction);

        const groupId = isGroup ? chatId : null;

        const antilinkOn = groupId ? Boolean(userGroupData.antilink?.[groupId]) : false;
        const antibadwordOn = groupId ? Boolean(userGroupData.antibadword?.[groupId]) : false;
        const welcomeOn = groupId ? Boolean(userGroupData.welcome?.[groupId]) : false;
        const goodbyeOn = groupId ? Boolean(userGroupData.goodbye?.[groupId]) : false;
        const chatbotOn = groupId ? Boolean(userGroupData.chatbot?.[groupId]) : false;
        const antitagCfg = groupId ? userGroupData.antitag?.[groupId] : null;

        // النص المزخرف
        const text =
`╭━━━〔 ⚙️ إعدادات البــوت 〕━━━╮

🤖 وضع البوت : ${mode.isPublic ? '🌍 عام' : '🔒 خاص'}
📡 أوتو ستاتس : ${autoStatus.enabled ? '✅ شغال' : '❌ مقفول'}
👀 أوتو قراءة : ${autoread.enabled ? '✅ شغال' : '❌ مقفول'}
⌨️ أوتو كتابة : ${autotyping.enabled ? '✅ شغال' : '❌ مقفول'}
📩 حظر الخاص : ${pmblocker.enabled ? '✅ شغال' : '❌ مقفول'}
📞 مانع الإتصال : ${anticall.enabled ? '✅ شغال' : '❌ مقفول'}
💫 رياكشن تلقائي : ${autoReaction ? '✅ شغال' : '❌ مقفول'}
`;

        let groupText = '';

        if (groupId) {
            groupText =
`
╭━━━〔 🏠 إعدادات الجروب 〕━━━╮

🔗 مانع اللينكات : ${antilinkOn ? '✅ شغال' : '❌ مقفول'}
🤬 مانع الألفاظ : ${antibadwordOn ? '✅ شغال' : '❌ مقفول'}
🎉 الترحيب : ${welcomeOn ? '✅ شغال' : '❌ مقفول'}
👋 المغادرة : ${goodbyeOn ? '✅ شغال' : '❌ مقفول'}
🤖 الشات بوت : ${chatbotOn ? '✅ شغال' : '❌ مقفول'}
🚷 مانع المنشن : ${antitagCfg?.enabled ? '✅ شغال' : '❌ مقفول'}

╰━━━━━━━━━━━━━━━━╯`;
        } else {
            groupText =
`
╭━━━〔 ℹ️ ملحوظة 〕━━━╮
┃ استخدم الأمر جوا جروب
┃ عشان تشوف إعداداته 🏠
╰━━━━━━━━━━━━━━━━╯`;
        }

        await sock.sendMessage(
            chatId,
            {
                text: text + groupText
            },
            { quoted: message }
        );

    } catch (error) {
        console.error('Error in settings command:', error);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ حصلت مشكله 〕━━━╮
┃
┃ معرفتش أقرأ الإعدادات 😕
┃ جرّب تاني بعدين
┃
╰━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
    }
}

module.exports = settingsCommand;