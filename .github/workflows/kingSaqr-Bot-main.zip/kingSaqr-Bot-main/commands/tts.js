const gTTS = require('gtts');
const fs = require('fs');
const path = require('path');

async function ttsCommand(sock, chatId, text, message, language = 'en') {

    // لو مفيش نص
    if (!text) {
        await sock.sendMessage(chatId, { 
            text: '🗣️ اكتب النص اللي تحب أحوّله لصوت الأول.' 
        }, { quoted: message });
        return;
    }

    const fileName = `tts-${Date.now()}.mp3`;
    const filePath = path.join(__dirname, '..', 'assets', fileName);

    const gtts = new gTTS(text, language);

    gtts.save(filePath, async function (err) {

        // لو حصل خطأ
        if (err) {
            await sock.sendMessage(chatId, { 
                text: '❌ حصل خطأ وأنا بحوّل النص لصوت… جرّب تاني.' 
            }, { quoted: message });
            return;
        }

        // إرسال الصوت
        await sock.sendMessage(chatId, {
            audio: { url: filePath },
            mimetype: 'audio/mpeg'
        }, { quoted: message });

        // مسح الملف بعد الإرسال
        fs.unlinkSync(filePath);
    });
}

module.exports = ttsCommand;