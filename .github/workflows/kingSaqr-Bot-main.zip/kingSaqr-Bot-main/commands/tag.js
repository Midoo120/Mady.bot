const isAdmin = require('../lib/isAdmin');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

// 📥 تحميل الميديا
async function downloadMediaMessage(message, mediaType) {
const stream = await downloadContentFromMessage(message, mediaType);
let buffer = Buffer.from([]);

for await (const chunk of stream) {
    buffer = Buffer.concat([buffer, chunk]);
}

const filePath = path.join(__dirname, '../temp/', `${Date.now()}.${mediaType}`);
fs.writeFileSync(filePath, buffer);
return filePath;

}

async function tagCommand(sock, chatId, senderId, messageText, replyMessage, message) {

const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

// 🤖 لو البوت مش أدمن
if (!isBotAdmin) {
    await sock.sendMessage(chatId, {
        text:

`❌ البوت مش أدمن!

📌 لازم تخلّي البوت أدمن
علشان يقدر يعمل منشن مخفي لكل الأعضاء 👮‍♂️`
}, { quoted: message });
return;
}

// 👑 لو المستخدم مش أدمن
if (!isSenderAdmin) {

    const stickerPath = './assets/sticktag.webp';

    if (fs.existsSync(stickerPath)) {
        const stickerBuffer = fs.readFileSync(stickerPath);

        await sock.sendMessage(chatId, {
            sticker: stickerBuffer
        }, { quoted: message });
    } else {
        await sock.sendMessage(chatId, {
            text:

`🚫 مش مسموح!

الأمر ده خاص بمسؤولي الجروب بس 👮‍♂️`
}, { quoted: message });
}

    return;
}

// 📋 بيانات الجروب
const groupMetadata = await sock.groupMetadata(chatId);
const participants = groupMetadata.participants;
const mentionedJidList = participants.map(p => p.id);

// 📌 لو فيه ريبلاي
if (replyMessage) {

    let messageContent = {};

    // 🖼️ صورة
    if (replyMessage.imageMessage) {
        const filePath = await downloadMediaMessage(replyMessage.imageMessage, 'image');

        messageContent = {
            image: { url: filePath },
            caption:

`📢 منشن جماعي

${messageText || replyMessage.imageMessage.caption || ''}`,
mentions: mentionedJidList
};
}

    // 🎥 فيديو
    else if (replyMessage.videoMessage) {
        const filePath = await downloadMediaMessage(replyMessage.videoMessage, 'video');

        messageContent = {
            video: { url: filePath },
            caption:

`📢 منشن جماعي

${messageText || replyMessage.videoMessage.caption || ''}`,
mentions: mentionedJidList
};
}

    // 💬 نص
    else if (replyMessage.conversation || replyMessage.extendedTextMessage) {
        messageContent = {
            text:

`📢 منشن جماعي

${replyMessage.conversation || replyMessage.extendedTextMessage.text}`,
mentions: mentionedJidList
};
}

    // 📄 ملف
    else if (replyMessage.documentMessage) {
        const filePath = await downloadMediaMessage(replyMessage.documentMessage, 'document');

        messageContent = {
            document: { url: filePath },
            fileName: replyMessage.documentMessage.fileName,
            caption:

`📢 منشن جماعي

${messageText || ''}`,
mentions: mentionedJidList
};
}

    if (Object.keys(messageContent).length > 0) {
        await sock.sendMessage(chatId, messageContent);
    }

} else {

    // 📢 منشن عادي بدون ريبلاي
    await sock.sendMessage(chatId, {
        text:

`📢 منشن جماعي

${messageText || 'حضور جميع الأعضاء لو سمحتم 👥'}`,
mentions: mentionedJidList
});
}
}

module.exports = tagCommand;