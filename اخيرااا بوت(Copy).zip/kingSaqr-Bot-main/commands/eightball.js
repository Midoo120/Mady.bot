const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

const eightBallResponses = [
    "أيوه طبعًا 🔥",
    "لا يا عم مستحيل 😂",
    "اسألني كمان شوية ⏳",
    "أكيد 100% 💯",
    "شبه مستحيل 😶",
    "من غير تفكير… أيوه 😎",
    "ردي هو لأ ❌",
    "كل العلامات بتقول أيوه 👀",
    "حاسس إنها هتمشي 🤝",
    "مش باين خير الصراحة 😅",
    "الدنيا مبشرة ✨",
    "ركّز وهتعرف الإجابة 😉"
];

async function eightBallCommand(sock, chatId, question, msg) {

    // ───────────── لو مفيش سؤال ─────────────
    if (!question) {
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 🎱 كرة الحظ 〕━━━╮

اسأل سؤالك الأول يا نجم ✨

مثال:
.8ball هل هنجح؟ 🤔

╰━━━〔 🤖 ${botName} 〕━━━╯`
        }, { quoted: msg });
        return;
    }

    // ───────────── اختيار رد عشوائي ─────────────
    const randomResponse =
        eightBallResponses[
            Math.floor(Math.random() * eightBallResponses.length)
        ];

    // ───────────── إرسال الرد ─────────────
    await sock.sendMessage(chatId, {
        text:
`╭━━━〔 🎱 سؤال وجواب 〕━━━╮

❓ سؤالك:
${question}

🎱 الرد:
${randomResponse}

╰━━━〔 🤖 ${botName} 〕━━━╯`
    }, { quoted: msg });
}

module.exports = { eightBallCommand };