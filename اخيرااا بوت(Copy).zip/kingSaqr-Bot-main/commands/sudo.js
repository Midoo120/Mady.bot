const settings = require('../settings');
const { addSudo, removeSudo, getSudoList } = require('../lib/index');
const isOwnerOrSudo = require('../lib/isOwner');

// 📌 استخراج المنشن أو الرقم
function extractMentionedJid(message) {
const mentioned = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

if (mentioned.length > 0) return mentioned[0];

const text =
    message.message?.conversation ||
    message.message?.extendedTextMessage?.text ||
    '';

const match = text.match(/\b(\d{7,15})\b/);

if (match) return match[1] + '@s.whatsapp.net';

return null;

}

async function sudoCommand(sock, chatId, message) {

const senderJid = message.key.participant || message.key.remoteJid;
const isOwner = message.key.fromMe || await isOwnerOrSudo(senderJid, sock, chatId);

const rawText =
    message.message?.conversation ||
    message.message?.extendedTextMessage?.text ||
    '';

const args = rawText.trim().split(' ').slice(1);
const sub = (args[0] || '').toLowerCase();

// 📖 شرح الاستخدام
if (!sub || !['add', 'del', 'remove', 'list'].includes(sub)) {
    await sock.sendMessage(chatId, {
        text:

`👑 أوامر السودو

➕ إضافة سودو:
.sudo add @user

➖ حذف سودو:
.sudo del @user

📋 عرض القائمة:
.sudo list`
}, { quoted: message });
return;
}

// 📋 عرض قائمة السودو
if (sub === 'list') {

    const list = await getSudoList();

    if (list.length === 0) {
        await sock.sendMessage(chatId, {
            text: '📭 لا يوجد مستخدمين سودو حالياً.'
        }, { quoted: message });
        return;
    }

    const text =

`👑 قائمة مستخدمين السودو

${list.map((j, i) => "▢ ${i + 1} → ${j}").join('\n')}`;

    await sock.sendMessage(chatId, { text }, { quoted: message });
    return;
}

// ❌ لو مش مالك
if (!isOwner) {
    await sock.sendMessage(chatId, {
        text:

`🚫 غير مسموح

هذا الأمر متاح للمالك فقط 👑

يمكنك استخدام:
.sudo list`
}, { quoted: message });
return;
}

// 🎯 استخراج الهدف
const targetJid = extractMentionedJid(message);

if (!targetJid) {
    await sock.sendMessage(chatId, {
        text: '❌ منشن الشخص أو اكتب رقمه لإكمال العملية.'
    }, { quoted: message });
    return;
}

// ➕ إضافة سودو
if (sub === 'add') {

    const ok = await addSudo(targetJid);

    await sock.sendMessage(chatId, {
        text: ok
            ? `✅ تم إضافة المستخدم إلى قائمة السودو بنجاح 👑\n\n${targetJid}`
            : '❌ فشل في إضافة السودو.'
    }, { quoted: message });

    return;
}

// ➖ حذف سودو
if (sub === 'del' || sub === 'remove') {

    const ownerJid = settings.ownerNumber + '@s.whatsapp.net';

    if (targetJid === ownerJid) {
        await sock.sendMessage(chatId, {
            text: '🚫 لا يمكن حذف المالك من قائمة السودو.'
        }, { quoted: message });
        return;
    }

    const ok = await removeSudo(targetJid);

    await sock.sendMessage(chatId, {
        text: ok
            ? `✅ تم حذف المستخدم من السودو 🗑️\n\n${targetJid}`
            : '❌ فشل في حذف السودو.'
    }, { quoted: message });

    return;
}

}

module.exports = sudoCommand;