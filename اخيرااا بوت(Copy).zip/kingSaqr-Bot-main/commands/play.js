const yts = require('yt-search');
const axios = require('axios');

async function playCommand(sock, chatId, message) {
    try {

        const text =
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text;

        const searchQuery =
            text.split(' ').slice(1).join(' ').trim();

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// ⚠️ No Query
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

        if (!searchQuery) {
            return await sock.sendMessage(chatId, {
                text: `
╭━━━〔 🎧 تحميل أغنية 〕━━━╮
┃
┃ اكتب اسم الأغنية بعد الأمر
┃
┃ مثال:
┃ .play Shape of you
┃
╰━━━━━━━━━━━━━━━━━━╯`
            }, { quoted: message });
        }

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 🔎 Search
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

        const { videos } = await yts(searchQuery);

        if (!videos || videos.length === 0) {
            return await sock.sendMessage(chatId, {
                text: `
╭━━━〔 ❌ مفيش نتائج 〕━━━╮
┃
┃ ملقتش الأغنية دي 😢
┃ جرب اسم تاني
┃
╰━━━━━━━━━━━━━━╯`
            }, { quoted: message });
        }

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// ⏳ Loading
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

        await sock.sendMessage(chatId, {
            text: `
╭━━━〔 ⏳ جاري التحميل 〕━━━╮
┃
┃ استنى شوية…
┃ بنحمل الأغنية 🎶
┃
╰━━━━━━━━━━━━━━━━━━╯`
        });

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 🎵 Get First Result
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

        const video = videos[0];
        const urlYt = video.url;

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 📥 API Request
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

        const response =
            await axios.get(
                `https://apis-keith.vercel.app/download/dlmp3?url=${urlYt}`
            );

        const data = response.data;

        if (
            !data ||
            !data.status ||
            !data.result ||
            !data.result.downloadUrl
        ) {
            return await sock.sendMessage(chatId, {
                text: `
╭━━━〔 ❌ فشل التحميل 〕━━━╮
┃
┃ حصل خطأ في السيرفر
┃ جرب تاني بعد شوية
┃
╰━━━━━━━━━━━━━━╯`
            }, { quoted: message });
        }

        const audioUrl = data.result.downloadUrl;
        const title = data.result.title;

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 🎧 Send Audio
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

        await sock.sendMessage(chatId, {
            audio: { url: audioUrl },
            mimetype: "audio/mpeg",
            fileName: `${title}.mp3`,
            caption: `
╭━━━〔 🎶 تم التحميل 〕━━━╮
┃
┃ 📝 العنوان:
┃ ${title}
┃
┃ 🤖 بواسطة:
┃ mady — BOT
┃
╰━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });

    } catch (error) {

        console.error('Error in play command:', error);

        await sock.sendMessage(chatId, {
            text: `
╭━━━〔 ⚠️ خطأ 〕━━━╮
┃
┃ التحميل فشل ❌
┃ حاول تاني بعد شوية
┃
╰━━━━━━━━━━━━━━╯`
        }, { quoted: message });
    }
}

module.exports = playCommand;

/*
╭──────────────────╮
│  
 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ — BOT   │
│ Powered by    mady │
╰──────────────────╯
*/