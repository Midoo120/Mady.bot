const axios = require('axios');

module.exports = async function (sock, chatId, message) {

    const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

    try {
        const response = await axios.get(
            'https://icanhazdadjoke.com/',
            {
                headers: { Accept: 'application/json' }
            }
        );

        const joke = response.data.joke;

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 😂 ${botName} 〕━━━╮

📢 اسمع النكتة دي بقا:

「 ${joke} 」

ضحكت؟ ولا أجيب أقوى؟ 😏

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );

    } catch (error) {

        console.error('Error fetching joke:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❌ ${botName} 〕━━━╮

مش قادر أجيب نكتة دلوقتي 😔

غالباً السيرفر نايم 💤
جرب تاني كمان شوية

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
    }
};