const fs = require('fs');
const { channelInfo } = require('../lib/messageConfig');
const isAdmin = require('../lib/isAdmin');
const { isSudo } = require('../lib/index');

const botName = '『𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬』';

async function banCommand(sock, chatId, message) {

    const isGroup = chatId.endsWith('@g.us');

    if (isGroup) {
        const senderId = message.key.participant || message.key.remoteJid;
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

        if (!isBotAdmin) {
            await sock.sendMessage(chatId, {
                text: `╭─❖「 ${botName} 」❖─╮
⚠️ لازم ترفع البوت أدمن الأول
╰───────────────╯`,
                ...channelInfo
            }, { quoted: message });
            return;
        }

        if (!isSenderAdmin && !message.key.fromMe) {
            await sock.sendMessage(chatId, {
                text: `╭─❖「 ${botName} 」❖─╮
🚫 الأمر ده للإدمن بس يا نجم
╰───────────────╯`,
                ...channelInfo
            }, { quoted: message });
            return;
        }

    } else {
        const senderId = message.key.participant || message.key.remoteJid;
        const senderIsSudo = await isSudo(senderId);

        if (!message.key.fromMe && !senderIsSudo) {
            await sock.sendMessage(chatId, {
                text: `╭─❖「 ${botName} 」❖─╮
🔒 الأمر ده للمالك / السودو فقط
╰───────────────╯`,
                ...channelInfo
            }, { quoted: message });
            return;
        }
    }

    let userToBan;

    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToBan = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToBan = message.message.extendedTextMessage.contextInfo.participant;
    }

    if (!userToBan) {
        await sock.sendMessage(chatId, {
            text: `╭─❖「 ${botName} 」❖─╮
📌 منشن الشخص أو اعمل رد على رسالته
╰───────────────╯`,
            ...channelInfo
        });
        return;
    }

    try {
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        if (userToBan === botId || userToBan === botId.replace('@s.whatsapp.net', '@lid')) {
            await sock.sendMessage(chatId, {
                text: `❌ مينفعش تبند البوت يا معلم 😅`,
                ...channelInfo
            }, { quoted: message });
            return;
        }
    } catch {}

    try {
        const bannedUsers = JSON.parse(fs.readFileSync('./data/banned.json'));

        if (!bannedUsers.includes(userToBan)) {
            bannedUsers.push(userToBan);
            fs.writeFileSync('./data/banned.json', JSON.stringify(bannedUsers, null, 2));

            await sock.sendMessage(chatId, {
                text: `╭─❖「 ${botName} 」❖─╮
🚫 تم حظر العضو بنجاح
👤 @${userToBan.split('@')[0]}
╰───────────────╯`,
                mentions: [userToBan],
                ...channelInfo
            });

        } else {
            await sock.sendMessage(chatId, {
                text: `⚠️ العضو ده متحظر قبل كده`,
                mentions: [userToBan],
                ...channelInfo
            });
        }

    } catch (error) {
        console.error('Error in ban command:', error);
        await sock.sendMessage(chatId, {
            text: `❌ حصل خطأ أثناء الحظر`,
            ...channelInfo
        });
    }
}

module.exports = banCommand;