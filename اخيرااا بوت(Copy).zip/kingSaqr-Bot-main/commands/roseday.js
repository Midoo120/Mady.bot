const fetch = require('node-fetch');

async function rosedayCommand(sock, chatId, message) {
    try {

        // رسالة انتظار خفيفة
        await sock.sendMessage(chatId, {
            text: '🌹 استنى أقطفلك أحلى وردة...'
        }, { quoted: message });

        const res = await fetch(
            `https://api.princetechn.com/api/fun/roseday?apikey=prince`
        );

        if (!res.ok) {
            throw await res.text();
        }

        const json = await res.json();
        const rosedayMessage = json.result;

        // الرسالة المزخرفة
        const finalText =
`╭━━━〔 🌹  Rose Day 〕━━━╮
┃
┃ ${rosedayMessage}
┃
┃ 🌸 يومك كله ورد
┃ 💖 وحب يملّى قلبك
┃
╰━━━━━━━━━━━━━━━━╯`;

        await sock.sendMessage(chatId, {
            text: finalText
        }, { quoted: message });

    } catch (error) {
        console.error('Error in roseday command:', error);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ حصلت مشكلة 〕━━━╮
┃
┃ معرفتش أجيب الورد دلوقتي 😢
┃ تعالى جرّب تاني بعد شوية
┃
╰━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });
    }
}

module.exports = { rosedayCommand };