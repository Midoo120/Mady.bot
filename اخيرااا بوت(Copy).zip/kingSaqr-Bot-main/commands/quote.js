const fetch = require('node-fetch');

module.exports = async function quoteCommand(sock, chatId, message) {
    try {
        const shizokeys = 'shizo';
        const res = await fetch(`https://shizoapi.onrender.com/api/texts/quotes?apikey=${shizokeys}`);
        
        if (!res.ok) {
            throw await res.text();
        }
        
        const json = await res.json();
        const quoteMessage = json.result;

        // Send the decorated quote
        await sock.sendMessage(chatId, { 
            text: `
╭━━━〔 🧠 𝗤𝗨𝗢𝗧𝗘 𝗧𝗜𝗠𝗘 〕━━━╮
┃
┃ ✨ حكمة النهارده:
┃
┃ 「 ${quoteMessage} 」
┃
┃ 📜 خلّيها على الله يا بطل
┃ وكمّل سعيك 💪
┃
┃ 🤖 𝗣𝗢𝗪𝗘𝗥𝗘𝗗 𝗕𝗬
┃ 『 𝗞𝗡𝗜𝗚𝗛𝗧 — 𝗕𝗢𝗧 』
┃
╰━━━━━━━━━━━━━━━━╯
`
        }, { quoted: message });

    } catch (error) {
        console.error('Error in quote command:', error);

        await sock.sendMessage(chatId, { 
            text: `
╭━━━〔 ❌ 𝗘𝗥𝗥𝗢𝗥 〕━━━╮
┃
┃ مقدرتش أجيب حكمة دلوقتي 😔
┃ السيرفر شكله نايم
┃
┃ جرّب تاني بعد شوية يا نجم
┃
╰━━━━━━━━━━━━━━━╯
`
        }, { quoted: message });
    }
};