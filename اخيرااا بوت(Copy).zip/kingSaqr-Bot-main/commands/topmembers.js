const fs = require('fs');
const path = require('path');

const dataFilePath = path.join(__dirname, '..', 'data', 'messageCount.json');

// 📥 تحميل الداتا
function loadMessageCounts() {
    if (fs.existsSync(dataFilePath)) {
        const data = fs.readFileSync(dataFilePath);
        return JSON.parse(data);
    }
    return {};
}

// 💾 حفظ الداتا
function saveMessageCounts(messageCounts) {
    fs.writeFileSync(dataFilePath, JSON.stringify(messageCounts, null, 2));
}

// ➕ زيادة العداد
function incrementMessageCount(groupId, userId) {
    const messageCounts = loadMessageCounts();

    if (!messageCounts[groupId]) {
        messageCounts[groupId] = {};
    }

    if (!messageCounts[groupId][userId]) {
        messageCounts[groupId][userId] = 0;
    }

    messageCounts[groupId][userId] += 1;

    saveMessageCounts(messageCounts);
}

// 🏆 توب الأعضاء
function topMembers(sock, chatId, isGroup) {
    if (!isGroup) {
        sock.sendMessage(chatId, {
            text: '❌ الأمر ده شغال في الجروبات بس.'
        });
        return;
    }

    const messageCounts = loadMessageCounts();
    const groupCounts = messageCounts[chatId] || {};

    const sortedMembers = Object.entries(groupCounts)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5); // 🔝 Top 5

    if (sortedMembers.length === 0) {
        sock.sendMessage(chatId, {
            text: '📭 لسه مفيش نشاط رسائل متسجل.'
        });
        return;
    }

    let message =
`🏆✨ *Top Active Members*

🔥 أكتر الأعضاء تفاعلاً في الجروب:

`;

    sortedMembers.forEach(([userId, count], index) => {
        const medals = ['🥇', '🥈', '🥉', '🏅', '🏅'];
        message += `${medals[index]} @${userId.split('@')[0]}\n`;
        message += `💬 Messages: ${count}\n\n`;
    });

    message += '🚀 خليك نشيط يمكن تطلع التوب الجاية!';

    sock.sendMessage(chatId, {
        text: message,
        mentions: sortedMembers.map(([userId]) => userId)
    });
}

module.exports = { incrementMessageCount, topMembers };