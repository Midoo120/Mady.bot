const insults = [
    "إنت لو كنت برنامج… كنت هتبقى فيرس 😂",
    "امك شطورة و ابوك عارف 👏",
    " زبي مانجة تعا مص 😭",
    "إنت لو بطارية… كنت هتبقى 1% دايماً 🔋",
    "إنت حضورك بيخلّي أي مكان… يطلب إخلاء فوري 🚨",
    "إنت زي النت الضعيف… ملوش لازمة وقت الجد 📶",
    "إنت لو زرار… كنت هتبقى زرار كتم الصوت 🔇",
    "إنت مش مزعج… إنت مشروع إزعاج متكامل 🏗️",
    "إنت لو فكرة… محدش هيطبّقها 🤦‍♂️",
    "إنت زي التحديثات… بتظهر فجأة ومحدش عايزك 💻"
];

async function insultCommand(sock, chatId, message) {

    const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

    try {
        if (!message || !chatId) return;

        let userToInsult;

        // لو في منشن
        if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
            userToInsult =
                message.message.extendedTextMessage.contextInfo.mentionedJid[0];
        }

        // لو ريبلاي
        else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToInsult =
                message.message.extendedTextMessage.contextInfo.participant;
        }

        // مفيش حد
        if (!userToInsult) {
            return await sock.sendMessage(
                chatId,
                {
                    text:
`╭━━━〔 ⚠️ ${botName} 〕━━━╮

فين الشخص اللي أشتمه؟ 😏

📌 منشن حد  
أو اعمل ريبلاي على رسالته

╰━━━━━━━━━━━━━━━━━━╯`
                },
                { quoted: message }
            );
        }

        const insult =
            insults[Math.floor(Math.random() * insults.length)];

        await new Promise(r => setTimeout(r, 1000));

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 🤡 ${botName} 〕━━━╮

اسمع بقا يا نجم 👇

@${userToInsult.split('@')[0]}

「 ${insult} 」

متزعلش… هزار بوتات بس 😎

╰━━━━━━━━━━━━━━━━━━╯`,
                mentions: [userToInsult]
            },
            { quoted: message }
        );

    } catch (error) {

        console.error('Error in insult command:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❌ ${botName} 〕━━━╮

حصلت غلطة وانا بشتمه 😂

جرب تاني كدا…

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
    }
}

module.exports = { insultCommand };