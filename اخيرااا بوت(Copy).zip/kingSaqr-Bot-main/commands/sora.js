const axios = require('axios');

async function soraCommand(sock, chatId, message) {
    try {
        const sender =
            message.key.participant || message.key.remoteJid;
        const user = sender.split('@')[0];

        const rawText =
            message.message?.conversation?.trim() ||
            message.message?.extendedTextMessage?.text?.trim() ||
            message.message?.imageMessage?.caption?.trim() ||
            message.message?.videoMessage?.caption?.trim() ||
            '';

        // استخراج البرومبت
        const used =
            (rawText || '').split(/\s+/)[0] || '.sora';

        const args = rawText.slice(used.length).trim();

        const quoted =
            message.message?.extendedTextMessage
                ?.contextInfo?.quotedMessage;

        const quotedText =
            quoted?.conversation ||
            quoted?.extendedTextMessage?.text ||
            '';

        const input = args || quotedText;

        // ❌ مفيش برومبت
        if (!input) {
            return await sock.sendMessage(
                chatId,
                {
                    text: `
╔═══〔 🎬 توليد فيديو بالذكاء 〕═══╗
║
║ اكتب وصف للفيديو يا @${user}
║
║ 📌 مثال:
║ .sora anime girl blue hair
║
║ أو اعمل ريبلاي على نص
║ والبوت يحوله فيديو
║
╚════════════════════╝
`.trim(),
                    mentions: [sender]
                },
                { quoted: message }
            );
        }

        // ⏳ رسالة انتظار
        await sock.sendMessage(
            chatId,
            {
                text: `
⏳ استنى يا @${user}

بجهزلك فيديو من وصفك:
🎥 "${input}"

الـ AI شغال دلوقتي 🤖🔥
`.trim(),
                mentions: [sender]
            },
            { quoted: message }
        );

        // 🌐 API
        const apiUrl =
            `https://okatsu-rolezapiiz.vercel.app/ai/txt2video?text=${encodeURIComponent(input)}`;

        const { data } = await axios.get(apiUrl, {
            timeout: 60000,
            headers: { 'user-agent': 'Mozilla/5.0' }
        });

        const videoUrl =
            data?.videoUrl ||
            data?.result ||
            data?.data?.videoUrl;

        if (!videoUrl) {
            throw new Error('No videoUrl in API response');
        }

        // 🎬 إرسال الفيديو
        await sock.sendMessage(
            chatId,
            {
                video: { url: videoUrl },
                mimetype: 'video/mp4',
                caption: `
╔═══〔 🎬 تم إنشاء الفيديو 〕═══╗
║
║ 🧠 الوصف:
║ ${input}
║
║ 👤 الطلب بواسطة:
║ @${user}
║
║ 🔥 مشاهدة ممتعة
║
╚════════════════════╝
`.trim(),
                mentions: [sender]
            },
            { quoted: message }
        );

    } catch (error) {
        console.error('[SORA] error:', error?.message || error);

        const sender =
            message.key.participant || message.key.remoteJid;
        const user = sender.split('@')[0];

        await sock.sendMessage(
            chatId,
            {
                text: `
╔═══〔 ❌ حصلت مشكلة 〕═══╗
║
║ بص يا @${user}
║
║ الفيديو مرضيش يتولد 😅
║ يمكن الوصف صعب
║ أو السيرفر مضغوط
║
║ جرب تاني بعد شوية 🔄
║
╚════════════════════╝
`.trim(),
                mentions: [sender]
            },
            { quoted: message }
        );
    }
}

module.exports = soraCommand;