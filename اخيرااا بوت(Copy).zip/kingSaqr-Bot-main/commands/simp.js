const fetch = require('node-fetch');

async function simpCommand(sock, chatId, quotedMsg, mentionedJid, sender, message) {
    try {

        // نحدد الشخص المستهدف
        let who = quotedMsg
            ? quotedMsg.sender
            : mentionedJid && mentionedJid[0]
                ? mentionedJid[0]
                : sender;

        // نجيب صورته
        let avatarUrl;
        try {
            avatarUrl = await sock.profilePictureUrl(who, 'image');
        } catch {
            avatarUrl = 'https://telegra.ph/file/24fa902ead26340f3df2c.png';
        }

        // API
        const apiUrl =
`https://some-random-api.com/canvas/misc/simpcard?avatar=${encodeURIComponent(avatarUrl)}`;

        const response = await fetch(apiUrl);
        if (!response.ok) throw new Error('API Error');

        const imageBuffer = await response.buffer();

        // المنشن
        const tag = `@${who.split('@')[0]}`;

        // الكابشن المزخرف
        const caption =
`╭━━━〔 🧻 تقرير السمبنة 〕━━━╮
┃
┃ 🕵️‍♂️ الشخص المتهم :
┃ ${tag}
┃
┃ 📊 نسبة السمبنة :
┃ 999999999% 💀
┃
┃ 💬 الحكم :
┃ دينك الرسمي هو
┃ "السمبنة العظمى" 😂
┃
╰━━━━━━━━━━━━━━━━━━╯`;

        // إرسال الصورة
        await sock.sendMessage(chatId, {
            image: imageBuffer,
            caption: caption,
            mentions: [who],
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true
            }
        }, { quoted: message });

    } catch (error) {
        console.error('Error in simp command:', error);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ حصلت خيبة 〕━━━╮
┃
┃ معرفتش أطلّع تقرير السمبنة
┃ جرّب تاني كدا يا نجم
┃
╰━━━━━━━━━━━━━━━━╯`
        });
    }
}

module.exports = { simpCommand };