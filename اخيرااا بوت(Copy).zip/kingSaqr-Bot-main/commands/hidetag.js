const isAdmin = require('../lib/isAdmin');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

async function downloadMediaMessage(message, mediaType) {
    const stream = await downloadContentFromMessage(message, mediaType);
    let buffer = Buffer.from([]);

    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }

    const filePath = path.join(__dirname, '../temp/', `${Date.now()}.${mediaType}`);
    fs.writeFileSync(filePath, buffer);
    return filePath;
}

async function hideTagCommand(sock, chatId, senderId, messageText, replyMessage, message) {

    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

    // ❌ البوت مش أدمن
    if (!isBotAdmin) {
        return await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ⚠️ ${botName} 〕━━━╮

ارفعني أدمن الأول يا زعيم 👮‍♂️  
عشان أعرف أعمل تاج مخفي

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
    }

    // ❌ الشخص مش أدمن
    if (!isSenderAdmin) {
        return await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 🚫 ${botName} 〕━━━╮

الأمر ده للأدمنز بس يا نجم ⭐

متجيش على الكبير 😏

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
    }

    const groupMetadata = await sock.groupMetadata(chatId);
    const participants = groupMetadata.participants || [];

    // كل الأعضاء ما عدا الأدمنز
    const nonAdmins = participants
        .filter(p => !p.admin)
        .map(p => p.id);

    // 📌 لو فيه ريبلاي
    if (replyMessage) {

        let content = {};

        // 🖼️ صورة
        if (replyMessage.imageMessage) {

            const filePath = await downloadMediaMessage(
                replyMessage.imageMessage,
                'image'
            );

            content = {
                image: { url: filePath },
                caption:
messageText ||
replyMessage.imageMessage.caption ||
`╭━━━〔 🏷️ ${botName} 〕━━━╮

تاج مخفي لكل الأعضاء 📢

╰━━━━━━━━━━━━━━━━━━╯`,
                mentions: nonAdmins
            };
        }

        // 🎥 فيديو
        else if (replyMessage.videoMessage) {

            const filePath = await downloadMediaMessage(
                replyMessage.videoMessage,
                'video'
            );

            content = {
                video: { url: filePath },
                caption:
messageText ||
replyMessage.videoMessage.caption ||
`╭━━━〔 🎬 ${botName} 〕━━━╮

تاج مخفي يا رجالة 🔥

╰━━━━━━━━━━━━━━━━━━╯`,
                mentions: nonAdmins
            };
        }

        // 📝 نص
        else if (
            replyMessage.conversation ||
            replyMessage.extendedTextMessage
        ) {

            content = {
                text:
`╭━━━〔 🏷️ ${botName} 〕━━━╮

${replyMessage.conversation ||
replyMessage.extendedTextMessage.text}

╰━━━━━━━━━━━━━━━━━━╯`,
                mentions: nonAdmins
            };
        }

        // 📄 ملف
        else if (replyMessage.documentMessage) {

            const filePath = await downloadMediaMessage(
                replyMessage.documentMessage,
                'document'
            );

            content = {
                document: { url: filePath },
                fileName: replyMessage.documentMessage.fileName,
                caption:
messageText ||
`╭━━━〔 📂 ${botName} 〕━━━╮

تاج مخفي مع ملف 📎

╰━━━━━━━━━━━━━━━━━━╯`,
                mentions: nonAdmins
            };
        }

        if (Object.keys(content).length > 0) {
            await sock.sendMessage(chatId, content);
        }

    }

    // 📌 لو مفيش ريبلاي
    else {

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 📢 ${botName} 〕━━━╮

${messageText || 'تاج مخفي لكل الأعضاء 👥'}

╰━━━━━━━━━━━━━━━━━━╯`,
                mentions: nonAdmins
            }
        );
    }
}

module.exports = hideTagCommand;