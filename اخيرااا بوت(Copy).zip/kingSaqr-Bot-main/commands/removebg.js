const axios = require('axios');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { uploadImage } = require('../lib/uploadImage');

async function getQuotedOrOwnImageUrl(sock, message) {

    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;

    if (quoted?.imageMessage) {
        const stream = await downloadContentFromMessage(quoted.imageMessage, 'image');
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        const buffer = Buffer.concat(chunks);
        return await uploadImage(buffer);
    }

    if (message.message?.imageMessage) {
        const stream = await downloadContentFromMessage(message.message.imageMessage, 'image');
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        const buffer = Buffer.concat(chunks);
        return await uploadImage(buffer);
    }

    return null;
}

module.exports = {
    name: 'removebg',
    alias: ['rmbg', 'nobg'],
    category: 'general',
    desc: 'Remove background from images',

    async exec(sock, message, args) {
        try {
            const chatId = message.key.remoteJid;

            let imageUrl = null;

            // لو فيه لينك
            if (args.length > 0) {

                const url = args.join(' ');

                if (isValidUrl(url)) {
                    imageUrl = url;
                } else {
                    return sock.sendMessage(chatId, {
                        text:
`╭━━━〔 ❌ لينك غلط 〕━━━╮
┃
┃ اللينك اللي بعتّه مش مظبوط 😑
┃ ابعت لينك صورة صحيح
┃
╰━━━━━━━━━━━━━━━━╯`
                    }, { quoted: message });
                }

            } else {

                imageUrl = await getQuotedOrOwnImageUrl(sock, message);

                if (!imageUrl) {
                    return sock.sendMessage(chatId, {
                        text:
`╭━━━〔 🖼️ أمر حذف الخلفية 〕━━━╮
┃
┃ ابعت صورة مع الأمر:
┃ .removebg
┃
┃ أو رد على صورة
┃
┃ أو حط لينك:
┃ .removebg رابط_الصورة
┃
╰━━━━━━━━━━━━━━━━━━━━╯`
                    }, { quoted: message });
                }
            }

            // رسالة انتظار
            await sock.sendMessage(chatId, {
                text: '✂️ ثانية كدا… بقصّ الخلفية بالمقص الذهبي…'
            }, { quoted: message });

            // API
            const apiUrl =
`https://api.siputzx.my.id/api/iloveimg/removebg?image=${encodeURIComponent(imageUrl)}`;

            const response = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                timeout: 30000,
                headers: { 'User-Agent': 'Mozilla/5.0' }
            });

            if (response.status === 200 && response.data) {

                await sock.sendMessage(chatId, {
                    image: response.data,
                    caption:
`╭━━━〔 ✨ تم بنجاح 〕━━━╮
┃
┃ الخلفية اتشالت يا معلم 😎
┃ جاهزة للتصميم بقى 🔥
┃
┃ 🤖 تم التنفيذ بواسطة البوت
╰━━━━━━━━━━━━━━━━╯`
                }, { quoted: message });

            } else {
                throw new Error('Processing failed');
            }

        } catch (error) {

            console.error('RemoveBG Error:', error.message);

            let errorMessage =
`╭━━━〔 ❌ فشل التنفيذ 〕━━━╮
┃
┃ معرفتش أشيل الخلفية 😢
┃ جرّب تاني بعد شوية
┃
╰━━━━━━━━━━━━━━━━╯`;

            if (error.response?.status === 429) {
                errorMessage =
`╭━━━〔 ⏰ ضغط جامد 〕━━━╮
┃
┃ السيرفر واقع من الزحمة 😵
┃ جرّب بعد شوية
┃
╰━━━━━━━━━━━━━━━━╯`;
            }

            await sock.sendMessage(chatId, {
                text: errorMessage
            }, { quoted: message });
        }
    }
};

// فحص اللينك
function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch {
        return false;
    }
}