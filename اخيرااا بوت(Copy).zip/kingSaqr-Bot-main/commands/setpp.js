const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const isOwnerOrSudo = require('../lib/isOwner');

async function setProfilePicture(sock, chatId, msg) {
    try {
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
        
        // صلاحيات
        if (!msg.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 🚫 صلاحيات مرفوضة 〕━━━╮
┃
┃ الأمر دا لمالك البوت بس 👑
┃ متحاولش تغيّر صورتي 😏
┃
╰━━━━━━━━━━━━━━━━╯`
            });
            return;
        }

        // هل في ريبلاي
        const quotedMessage =
            msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quotedMessage) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ⚠️ إستخدم الأمر صح 〕━━━╮
┃
┃ اعمل رد على صورة 🖼️
┃ واكتب .setpp
┃
╰━━━━━━━━━━━━━━━━╯`
            });
            return;
        }

        // هل صورة أو استيكر
        const imageMessage =
            quotedMessage.imageMessage ||
            quotedMessage.stickerMessage;

        if (!imageMessage) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ❌ نوع غير مدعوم 〕━━━╮
┃
┃ لازم ترد على صورة بس 🖼️
┃ مش أي حاجة تانية
┃
╰━━━━━━━━━━━━━━━━╯`
            });
            return;
        }

        // مجلد tmp
        const tmpDir = path.join(process.cwd(), 'tmp');
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }

        // تحميل الصورة
        const stream = await downloadContentFromMessage(imageMessage, 'image');
        let buffer = Buffer.from([]);

        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        const imagePath = path.join(
            tmpDir,
            `profile_${Date.now()}.jpg`
        );

        fs.writeFileSync(imagePath, buffer);

        // رسالة انتظار
        await sock.sendMessage(chatId, {
            text: '⏳ جاري تحديث صورة البوت...'
        });

        // تغيير الصورة
        await sock.updateProfilePicture(sock.user.id, {
            url: imagePath
        });

        // حذف الملف
        fs.unlinkSync(imagePath);

        // نجاح
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ✅ تمت العملية 〕━━━╮
┃
┃ تم تغيير صورة البوت 🖼️✨
┃ بقت روش ولا لسه؟ 😎
┃
╰━━━━━━━━━━━━━━━━╯`
        });

    } catch (error) {
        console.error('Error in setpp command:', error);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ فشل التغيير 〕━━━╮
┃
┃ حصلت مشكلة وأنا بغيّر الصورة 😢
┃ جرّب تاني بعد شوية
┃
╰━━━━━━━━━━━━━━━━╯`
        });
    }
}

module.exports = setProfilePicture;