const isAdmin = require('../lib/isAdmin');

const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

async function demoteCommand(sock, chatId, mentionedJids, message) {
    try {

        // ───────────── تأكد إن الجروب ─────────────
        if (!chatId.endsWith('@g.us')) {
            return await sock.sendMessage(chatId, {
                text: "❌ الأمر ده شغال في الجروبات بس."
            });
        }

        // ───────────── فحص الأدمن ─────────────
        const sender =
            message.key.participant || message.key.remoteJid;

        const adminStatus = await isAdmin(
            sock,
            chatId,
            sender
        );

        if (!adminStatus.isBotAdmin) {
            return await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ⚠️ صلاحيات ناقصة 〕━━━╮

لازم تخلّي البوت أدمن الأول 🛠️

╰━━━〔 🤖 ${botName} 〕━━━╯`
            });
        }

        if (!adminStatus.isSenderAdmin) {
            return await sock.sendMessage(chatId, {
                text:
`╭━━━〔 🚫 مفيش صلاحية 〕━━━╮

الأمر ده للأدمن بس 👑

╰━━━〔 🤖 ${botName} 〕━━━╯`
            });
        }

        // ───────────── تحديد الشخص ─────────────
        let userToDemote = [];

        if (mentionedJids?.length > 0) {
            userToDemote = mentionedJids;
        } 
        else if (
            message.message?.extendedTextMessage
                ?.contextInfo?.participant
        ) {
            userToDemote = [
                message.message.extendedTextMessage
                    .contextInfo.participant
            ];
        }

        if (userToDemote.length === 0) {
            return await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ❌ خطأ 〕━━━╮

منشن الشخص أو اعمل ريبلاي على رسالته 👤

╰━━━〔 🤖 ${botName} 〕━━━╯`
            });
        }

        // ───────────── تنفيذ التخفيض ─────────────
        await sock.groupParticipantsUpdate(
            chatId,
            userToDemote,
            "demote"
        );

        // ───────────── تجهيز المنشن ─────────────
        const usernames = userToDemote.map(
            jid => `@${jid.split('@')[0]}`
        );

        const by =
            sender.split('@')[0];

        // ───────────── الرسالة ─────────────
        const demotionMessage =
`╭━━━〔 📉 تخفيض رتبة 〕━━━╮

👤 المستخدم:
${usernames.map(u => `• ${u}`).join('\n')}

👑 بواسطة:
@${by}

📅 التاريخ:
${new Date().toLocaleString("ar-EG")}

╰━━━〔 🤖 ${botName} 〕━━━╯`;

        await sock.sendMessage(chatId, {
            text: demotionMessage,
            mentions: [...userToDemote, sender]
        });

    } catch (error) {
        console.error("Demote Error:", error);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ حصل خطأ 〕━━━╮

تأكد إن البوت أدمن  
وحاول تاني 🔄

╰━━━〔 🤖 ${botName} 〕━━━╯`
        });
    }
}

module.exports = { demoteCommand };