const fs = require('fs');
const isOwnerOrSudo = require('../lib/isOwner');

const PMBLOCKER_PATH = './data/pmblocker.json';

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 📂 Read State
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

function readState() {
    try {
        if (!fs.existsSync(PMBLOCKER_PATH)) {
            return {
                enabled: false,
                message: `
╭━━━〔 🚫 الخاص مقفول 〕━━━╮
┃
┃ متبعتش للبوت خاص ❌
┃
┃ لو عايز حاجة كلم الأونر
┃ من الجروبات بس 👑
┃
╰━━━━━━━━━━━━━━━━╯`
            };
        }

        const raw = fs.readFileSync(PMBLOCKER_PATH, 'utf8');
        const data = JSON.parse(raw || '{}');

        return {
            enabled: !!data.enabled,
            message: data.message
        };

    } catch {
        return { enabled: false, message: 'PM Blocker Error' };
    }
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 💾 Write State
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

function writeState(enabled, message) {
    try {
        if (!fs.existsSync('./data')) {
            fs.mkdirSync('./data', { recursive: true });
        }

        const current = readState();

        const payload = {
            enabled: !!enabled,
            message: message || current.message
        };

        fs.writeFileSync(
            PMBLOCKER_PATH,
            JSON.stringify(payload, null, 2)
        );

    } catch {}
}

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 🛡️ Command
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

async function pmblockerCommand(sock, chatId, message, args) {

    const senderId =
        message.key.participant ||
        message.key.remoteJid;

    const isOwner =
        await isOwnerOrSudo(senderId, sock, chatId);

    if (!message.key.fromMe && !isOwner) {
        await sock.sendMessage(chatId, {
            text: `
╭━━━〔 ⛔ ممنوع 〕━━━╮
┃
┃ الأمر ده للأونر بس 👑
┃ متحاولش تاني يا نجم 😅
┃
╰━━━━━━━━━━━━━━╯`
        }, { quoted: message });

        return;
    }

    const argStr = (args || '').trim();
    const [sub, ...rest] = argStr.split(' ');
    const state = readState();

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 📜 Help
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

    if (!sub) {
        await sock.sendMessage(chatId, {
            text: `
╭━━━〔 🛡️ نظام حظر الخاص 〕━━━╮
┃
┃ 📌 الأوامر:
┃
┃ • .pmblocker on
┃ • .pmblocker off
┃ • .pmblocker status
┃ • .pmblocker setmsg <رسالة>
┃
┃ 🤖 KNIGHT — BOT
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });

        return;
    }

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// 📊 Status
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

    if (sub === 'status') {
        await sock.sendMessage(chatId, {
            text: `
╭━━━〔 📊 الحالة الحالية 〕━━━╮
┃
┃ 🛡️ الحظر:
┃ ${state.enabled ? 'مفعل ✅' : 'مقفول ❌'}
┃
┃ 💬 الرسالة:
┃
${state.message}
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`
        }, { quoted: message });

        return;
    }

//━━━━━━━━━━━━━━━━━━━━━━━━━━━//
// ✏️ Set Message
//━━━━━━━━━━━━━━━━━━━━━━━━━━━//

    if (sub === 'setmsg') {

        const newMsg = rest.join(' ').trim();

        if (!newMsg) {
            await sock.sendMessage(chatId, {
                text: `
╭━━━〔 ⚠️ خطأ 〕━━━╮
┃
┃ اكتب الرسالة بعد الأمر
┃
┃ مثال:
┃ .pmblocker setmsg متبعتش خاص
┃
╰━━━━━━━━━━━━━━╯`
            }, { quoted: message });

            return;
        }

        writeState(state.enabled, newMsg);

        await sock.sendMessage(chatId, {
            text: `
╭━━━〔 ✅ تم التعديل 〕━━━╮
┃
┃ غير