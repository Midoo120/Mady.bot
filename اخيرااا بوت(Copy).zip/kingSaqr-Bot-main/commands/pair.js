const axios = require('axios');
const { sleep } = require('../lib/myfunc');

async function pairCommand(sock, chatId, message, q) {
    try {
        if (!q) {
            return await sock.sendMessage(chatId, {
                text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❖
╭━━━〔 🔗 ربط البوت 〕━━━╮
يـا صـاحـبـي ابعـت رقـم واتـس صـح 👀
مثــال:
.pair 2010XXXXXXX
╰━━━━━━━━━━━━━━━╯`,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                }
            });
        }

        const numbers = q.split(',')
            .map((v) => v.replace(/[^0-9]/g, ''))
            .filter((v) => v.length > 5 && v.length < 20);

        if (numbers.length === 0) {
            return await sock.sendMessage(chatId, {
                text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❖
الرقـم اللي بعـتـه غلـط يـنجم ❌
ابعتـه بالصيغة الصح كده:
201XXXXXXXX`,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                }
            });
        }

        for (const number of numbers) {
            const whatsappID = number + '@s.whatsapp.net';
            const result = await sock.onWhatsApp(whatsappID);

            if (!result[0]?.exists) {
                return await sock.sendMessage(chatId, {
                    text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❖
الرقـم ده مش مسجـل واتـس ❗️
اتأكـد منـه وجـرّب تانـي`,
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                    }
                });
            }

            await sock.sendMessage(chatId, {
                text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❖
استنـى ثوانـي يـا كبيـر… ⏳
بجهـزلك كـود الربـط دلوقـتي 🔐`,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                }
            });

            try {
                const response = await axios.get(`https://knight-bot-paircode.onrender.com/code?number=${number}`);
                
                if (response.data && response.data.code) {
                    const code = response.data.code;
                    if (code === "Service Unavailable") {
                        throw new Error('Service Unavailable');
                    }
                    
                    await sleep(5000);

                    await sock.sendMessage(chatId, {
                        text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❖
╭━━━〔 🔑 كـود الربـط 〕━━━╮
الكـود بتاعـك هـو:

${code}

خلي بالك محدش يشوفه 👀
╰━━━━━━━━━━━━━━━╯`,
                        contextInfo: {
                            forwardingScore: 1,
                            isForwarded: true,
                        }
                    });
                } else {
                    throw new Error('Invalid response from server');
                }
            } catch (apiError) {
                console.error('API Error:', apiError);

                const errorMessage =
                    apiError.message === 'Service Unavailable'
                        ? `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❖
السيـرفـر واقـع دلوقـتي 😵‍💫
جـرّب كمان شـويـة`
                        : `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❖
حصـل مشكـلة وأنا بطلـع الكـود ❌
جـرّب تانـي بعـد شـويـة`;

                await sock.sendMessage(chatId, {
                    text: errorMessage,
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                    }
                });
            }
        }
    } catch (error) {
        console.error(error);

        await sock.sendMessage(chatId, {
            text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❖
في غلـط حصـل يـا نجم ❌
جـرّب تاني بعـد شـويـة`,
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
            }
        });
    }
}

module.exports = pairCommand;