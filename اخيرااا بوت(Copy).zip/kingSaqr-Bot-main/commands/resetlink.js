async function resetlinkCommand(sock, chatId, senderId) {
    try {
        const groupMetadata = await sock.groupMetadata(chatId);

        // الأدمنز
        const admins = groupMetadata.participants
            .filter(p => p.admin)
            .map(p => p.id);

        const isAdmin = admins.includes(senderId);

        // البوت أدمن؟
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const isBotAdmin = admins.includes(botId);

        // لو مش أدمن
        if (!isAdmin) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 🚫 استنى يا نجم 〕━━━╮
┃
┃ الأمر دا للأدمن بس 😏
┃ روح هات صلاحيات وارجعلي
┃
╰━━━━━━━━━━━━━━━━╯`
            });
            return;
        }

        // لو البوت مش أدمن
        if (!isBotAdmin) {
            await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ⚠️ تنبيه 〕━━━╮
┃
┃ لازم تخلّيني أدمن الأول 👑
┃ عشان أعرف أغيّر الرابط
┃
╰━━━━━━━━━━━━━━━━╯`
            });
            return;
        }

        // رسالة انتظار
        await sock.sendMessage(chatId, {
            text: '🔄 ثانية كدا… بغيّر الرابط القديم...'
        });

        // Reset link
        const newCode = await sock.groupRevokeInvite(chatId);

        const newLink = `https://chat.whatsapp.com/${newCode}`;

        // الرسالة المزخرفة
        const finalText =
`╭━━━〔 🔗 رابط جديد 〕━━━╮
┃
┃ ✅ تم تصفير الرابط بنجاح
┃
┃ 📌 الرابط الجديد:
┃ ${newLink}
┃
┃ ⚠️ أي رابط قديم اتلغى خلاص
┃
╰━━━━━━━━━━━━━━━━╯`;

        await sock.sendMessage(chatId, { text: finalText });

    } catch (error) {
        console.error('Error in resetlink command:', error);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ حصلت مشكلة 〕━━━╮
┃
┃ معرفتش أغيّر الرابط 😢
┃ جرّب تاني بعد شوية
┃
╰━━━━━━━━━━━━━━━━╯`
        });
    }
}

module.exports = resetlinkCommand;