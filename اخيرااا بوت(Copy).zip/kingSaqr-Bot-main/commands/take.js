const fs = require('fs');
const path = require('path');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const webp = require('node-webpmux');
const crypto = require('crypto');

async function takeCommand(sock, chatId, message, args) {
try {
// 🔎 التأكد إن الرسالة رد على ستيكر
const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;

    if (!quotedMessage?.stickerMessage) {
        await sock.sendMessage(chatId, {
            text:

`❌ مفيش ستيكر!

📌 لازم ترد على ستيكر وتكتب:
➤ .take اسم-الباك

✨ مثال:
➤ .take باك الملك`
}, { quoted: message });
return;
}

    // 🏷️ اسم الباك
    const packname = args.join(' ') || '👑 باك الملك';

    try {
        // 📥 تحميل الستيكر
        const stickerBuffer = await downloadMediaMessage(
            {
                key: message.message.extendedTextMessage.contextInfo.stanzaId,
                message: quotedMessage,
                messageType: 'stickerMessage'
            },
            'buffer',
            {},
            {
                logger: console,
                reuploadRequest: sock.updateMediaMessage
            }
        );

        if (!stickerBuffer) {
            await sock.sendMessage(chatId, {
                text: '❌ فشل تحميل الستيكر… حاول تاني بعدين!'
            }, { quoted: message });
            return;
        }

        // 🧠 تحميل الصورة
        const img = new webp.Image();
        await img.load(stickerBuffer);

        // 📦 بيانات الباك
        const json = {
            'sticker-pack-id': crypto.randomBytes(32).toString('hex'),
            'sticker-pack-name': packname,
            'emojis': ['👑','🔥','🤖']
        };

        // 🧩 إنشاء EXIF
        const exifAttr = Buffer.from([
            0x49,0x49,0x2A,0x00,0x08,0x00,0x00,0x00,
            0x01,0x00,0x41,0x57,0x07,0x00,0x00,0x00,
            0x00,0x00,0x16,0x00,0x00,0x00
        ]);

        const jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8');
        const exif = Buffer.concat([exifAttr, jsonBuffer]);
        exif.writeUIntLE(jsonBuffer.length, 14, 4);

        img.exif = exif;

        // 💾 حفظ الستيكر
        const finalBuffer = await img.save(null);

        // 📤 إرسال الستيكر
        await sock.sendMessage(chatId, {
            sticker: finalBuffer
        }, { quoted: message });

        // ✅ رسالة نجاح
        await sock.sendMessage(chatId, {
            text:

`✅ تم أخذ الستيكر بنجاح!

📦 اسم الباك: ${packname}
🤖 البوت: مدير الستيكرات

استمتع 👑✨`
}, { quoted: message });

    } catch (error) {
        console.error('Sticker processing error:', error);

        await sock.sendMessage(chatId, {
            text:

`❌ حصل خطأ أثناء التعديل

⚠️ البوت فشل يضيف البيانات للستيكر.
جرب تاني بعدين…`
}, { quoted: message });
}

} catch (error) {
    console.error('Error in take command:', error);

    await sock.sendMessage(chatId, {
        text:

`❌ خطأ في تنفيذ الأمر

الأمر فشل يشتغل.
حاول مرة تانية…`
}, { quoted: message });
}
}

module.exports = takeCommand;