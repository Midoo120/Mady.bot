const axios = require('axios');
const settings = require('../settings'); // API KEY

async function gifCommand(sock, chatId, query, message) {
    const apiKey = settings.giphyApiKey;
    const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

    // ❌ لو مفيش كلمة بحث
    if (!query) {
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 🎬 ${botName} 〕━━━╮

فين كلمة البحث يا نجم؟ 🤨  
اكتب مثلاً:

.gif cat  
.gif anime

╰━━━━━━━━━━━━━━╯`
        }, { quoted: message });
        return;
    }

    try {
        const response = await axios.get(
            'https://api.giphy.com/v1/gifs/search',
            {
                params: {
                    api_key: apiKey,
                    q: query,
                    limit: 1,
                    rating: 'g'
                }
            }
        );

        const gifUrl =
            response.data.data[0]?.images?.downsized_medium?.url;

        // ✅ لو لقى GIF
        if (gifUrl) {
            await sock.sendMessage(
                chatId,
                {
                    video: { url: gifUrl },
                    gifPlayback: true,
                    caption:
`╭━━━〔 🎬 GIF 〕━━━╮

طلبك:
➤ ${query}

اتفرج وفلّها 😂🔥

╰━━━〔 🤖 ${botName} 〕━━━╯`
                },
                { quoted: message }
            );
        } 
        
        // ❌ لو ملقاش
        else {
            await sock.sendMessage(
                chatId,
                {
                    text:
`╭━━━〔 ❌ ${botName} 〕━━━╮

ملقتش أي GIF للكلمة دي 😢  
جرّب كلمة تانية

╰━━━━━━━━━━━━━━╯`
                },
                { quoted: message }
            );
        }

    } catch (error) {
        console.error('Error fetching GIF:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ⚠️ ${botName} 〕━━━╮

حصل خطأ وأنا بجيب الـ GIF 😓  
جرّب تاني بعد شوية

╰━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
    }
}

module.exports = gifCommand;