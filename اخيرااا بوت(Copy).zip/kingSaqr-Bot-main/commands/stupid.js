const fetch = require('node-fetch');

async function stupidCommand(sock, chatId, quotedMsg, mentionedJid, sender, args) {
try {
// 🎯 تحديد الشخص المستهدف
let who = quotedMsg
? quotedMsg.sender
: mentionedJid && mentionedJid[0]
? mentionedJid[0]
: sender;

    // 📝 النص المكتوب على الكارد
    let text = args && args.length > 0 
        ? args.join(' ') 
        : 'im+stupid';

    // 🖼️ جلب صورة البروفايل
    let avatarUrl;
    try {
        avatarUrl = await sock.profilePictureUrl(who, 'image');
    } catch (error) {
        console.error('خطأ في جلب صورة البروفايل:', error);

        // صورة افتراضية
        avatarUrl = 'https://telegra.ph/file/24fa902ead26340f3df2c.png';
    }

    // 🌐 رابط الـ API
    const apiUrl =

"https://some-random-api.com/canvas/misc/its-so-stupid?avatar=${encodeURIComponent(avatarUrl)}&dog=${encodeURIComponent(text)}";

    const response = await fetch(apiUrl);

    if (!response.ok) {
        throw new Error(`API Status: ${response.status}`);
    }

    // 📥 تحميل الصورة
    const imageBuffer = await response.buffer();

    // 📤 إرسال الكارد
    await sock.sendMessage(chatId, {
        image: imageBuffer,
        caption:

`😂 كارت الغباء وصل!

@${who.split('@')[0]}

🧠 مستوى الذكاء: تحت الصفر 📉`,
mentions: [who]
});

} catch (error) {
    console.error('خطأ في أمر stupid:', error);

    await sock.sendMessage(chatId, { 
        text:

`❌ حدث خطأ أثناء إنشاء الكارد.

🔁 حاول مرة أخرى لاحقاً.`
});
}
}

module.exports = { stupidCommand };