const fs = require('fs');
const path = require('path');
const { channelInfo } = require('../lib/messageConfig');
const isAdmin = require('../lib/isAdmin');
const { isSudo } = require('../lib/index');

async function unbanCommand(sock, chatId, message) {
    // في الجروبات الأدمن بس / في الخاص الأونر أو السودو
    const isGroup = chatId.endsWith('@g.us');
    if (isGroup) {
        const senderId = message.key.participant || message.key.remoteJid;
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

        if (!isBotAdmin) {
            await sock.sendMessage(chatId, { 
                text: 'لازم تدي البوت أدمن الأول عشان تستخدم .unban', 
                ...channelInfo 
            }, { quoted: message });
            return;
        }

        if (!isSenderAdmin && !message.key.fromMe) {
            await sock.sendMessage(chatId, { 
                text: 'الأمر ده للأدمن بس.', 
                ...channelInfo 
            }, { quoted: message });
            return;
        }
    } else {
        const senderId = message.key.participant || message.key.remoteJid;
        const senderIsSudo = await isSudo(senderId);

        if (!message.key.fromMe && !senderIsSudo) {
            await sock.sendMessage(chatId, { 
                text: 'الأمر ده للأونر أو السودو بس في الخاص.', 
                ...channelInfo 
            }, { quoted: message });
            return;
        }
    }

    let userToUnban;
    
    // لو في منشن
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToUnban = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    // لو ريبلاي
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToUnban = message.message.extendedTextMessage.contextInfo.participant;
    }
    
    if (!userToUnban) {
        await sock.sendMessage(chatId, { 
            text: 'منشن على الشخص أو اعمل ريبلاي على رسايله عشان تفك الباند.', 
            ...channelInfo 
        }, { quoted: message });
        return;
    }

    try {
        const bannedUsers = JSON.parse(fs.readFileSync('./data/banned.json'));
        const index = bannedUsers.indexOf(userToUnban);

        if (index > -1) {
            bannedUsers.splice(index, 1);
            fs.writeFileSync('./data/banned.json', JSON.stringify(bannedUsers, null, 2));
            
            await sock.sendMessage(chatId, { 
                text: `تم فك الباند عن ${userToUnban.split('@')[0]} بنجاح ✅`,
                mentions: [userToUnban],
                ...channelInfo 
            });
        } else {
            await sock.sendMessage(chatId, { 
                text: `${userToUnban.split('@')[0]} مش متبند أصلاً.`,
                mentions: [userToUnban],
                ...channelInfo 
            });
        }

    } catch (error) {
        console.error('Error in unban command:', error);
        await sock.sendMessage(chatId, { 
            text: 'حصل خطأ وأنا بفك الباند!', 
            ...channelInfo 
        }, { quoted: message });
    }
}

module.exports = unbanCommand;