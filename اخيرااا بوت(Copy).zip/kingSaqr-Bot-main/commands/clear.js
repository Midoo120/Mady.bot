async function clearCommand(sock, chatId) {
    const BOT_NAME = "𓆩 King Saqr 𓆪";

    try {
        // رسالة مؤقتة
        const sentMsg = await sock.sendMessage(chatId, {
            text:
`╭━━━〔 🧹 تنظيف 〕━━━╮

جاري مسح رسايل البوت…

استنى ثانية يا كبير ⚡

╰━━━〔 ${BOT_NAME} 〕━━━╯`
        });

        // حذف الرسالة المؤقتة
        await sock.sendMessage(chatId, {
            delete: sentMsg.key
        });

    } catch (error) {
        console.error('Error clearing messages:', error);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ Error 〕━━━╮

حصل مشكلة وأنا بمسح الرسايل 😅

جرّب تاني بعد شوية

╰━━━〔 ${BOT_NAME} 〕━━━╯`
        });
    }
}

module.exports = { clearCommand };