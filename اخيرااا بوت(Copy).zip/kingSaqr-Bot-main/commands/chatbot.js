const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

const USER_GROUP_DATA = path.join(__dirname, '../data/userGroupData.json');

// تخزين مؤقت للدردشة وبيانات المستخدم
const chatMemory = {
messages: new Map(), // بيخزن آخر 5 رسايل لكل مستخدم
userInfo: new Map()  // بيخزن معلومات المستخدم
};

// تحميل بيانات الجروبات
function loadUserGroupData() {
try {
return JSON.parse(fs.readFileSync(USER_GROUP_DATA));
} catch (error) {
console.error('❌ حصل خطأ أثناء تحميل بيانات الجروبات:', error.message);
return { groups: [], chatbot: {} };
}
}

// حفظ بيانات الجروبات
function saveUserGroupData(data) {
try {
fs.writeFileSync(USER_GROUP_DATA, JSON.stringify(data, null, 2));
} catch (error) {
console.error('❌ حصل خطأ أثناء حفظ بيانات الجروبات:', error.message);
}
}

// تأخير عشوائي بين 2 لـ 5 ثواني
function getRandomDelay() {
return Math.floor(Math.random() * 3000) + 2000;
}

// إظهار إن البوت بيكتب
async function showTyping(sock, chatId) {
try {
await sock.presenceSubscribe(chatId);
await sock.sendPresenceUpdate('composing', chatId);
await new Promise(resolve => setTimeout(resolve, getRandomDelay()));
} catch (error) {
console.error('حصل خطأ في إظهار حالة الكتابة:', error);
}
}

// استخراج بيانات المستخدم من الرسالة
function extractUserInfo(message) {
const info = {};

if (message.toLowerCase().includes('my name is')) {
    info.name = message.split('my name is')[1].trim().split(' ')[0];
}

if (message.toLowerCase().includes('i am') && message.toLowerCase().includes('years old')) {
    info.age = message.match(/\d+/)?.[0];
}

if (message.toLowerCase().includes('i live in') || message.toLowerCase().includes('i am from')) {
    info.location = message.split(/(?:i live in|i am from)/i)[1].trim().split(/[.,!?]/)[0];
}

return info;

}

async function handleChatbotCommand(sock, chatId, message, match) {
if (!match) {
await showTyping(sock, chatId);
return sock.sendMessage(chatId, {
text: "*إعدادات الشات بوت*\n\n*.chatbot on*\nتشغيل الشات بوت\n\n*.chatbot off*\nإيقاف الشات بوت في الجروب",
quoted: message
});
}

const data = loadUserGroupData();

const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';

const senderId = message.key.participant || message.participant || message.pushName || message.key.remoteJid;
const isOwner = senderId === botNumber;

if (isOwner) {
    if (match === 'on') {
        await showTyping(sock, chatId);
        if (data.chatbot[chatId]) {
            return sock.sendMessage(chatId, { 
                text: '*الشات بوت شغال بالفعل في الجروب*',
                quoted: message
            });
        }
        data.chatbot[chatId] = true;
        saveUserGroupData(data);
        console.log(`✅ Chatbot enabled for group ${chatId}`);
        return sock.sendMessage(chatId, { 
            text: '*تم تشغيل الشات بوت في الجروب*',
            quoted: message
        });
    }

    if (match === 'off') {
        await showTyping(sock, chatId);
        if (!data.chatbot[chatId]) {
            return sock.sendMessage(chatId, { 
                text: '*الشات بوت متوقف بالفعل في الجروب*',
                quoted: message
            });
        }
        delete data.chatbot[chatId];
        saveUserGroupData(data);
        console.log(`✅ Chatbot disabled for group ${chatId}`);
        return sock.sendMessage(chatId, { 
            text: '*تم إيقاف الشات بوت في الجروب*',
            quoted: message
        });
    }
}

let isAdmin = false;
if (chatId.endsWith('@g.us')) {
    try {
        const groupMetadata = await sock.groupMetadata(chatId);
        isAdmin = groupMetadata.participants.some(p => p.id === senderId && (p.admin === 'admin' || p.admin === 'superadmin'));
    } catch (e) {
        console.warn('⚠️ مقدرتش أجيب بيانات الجروب — ممكن البوت مش أدمن.');
    }
}

if (!isAdmin && !isOwner) {
    await showTyping(sock, chatId);
    return sock.sendMessage(chatId, {
        text: '❌ الأمر ده للأدمن أو صاحب البوت بس.',
        quoted: message
    });
}

if (match === 'on') {
    await showTyping(sock, chatId);
    if (data.chatbot[chatId]) {
        return sock.sendMessage(chatId, { 
            text: '*الشات بوت شغال بالفعل في الجروب*',
            quoted: message
        });
    }
    data.chatbot[chatId] = true;
    saveUserGroupData(data);
    return sock.sendMessage(chatId, { 
        text: '*تم تشغيل الشات بوت في الجروب*',
        quoted: message
    });
}

if (match === 'off') {
    await showTyping(sock, chatId);
    if (!data.chatbot[chatId]) {
        return sock.sendMessage(chatId, { 
            text: '*الشات بوت متوقف بالفعل في الجروب*',
            quoted: message
        });
    }
    delete data.chatbot[chatId];
    saveUserGroupData(data);
    return sock.sendMessage(chatId, { 
        text: '*تم إيقاف الشات بوت في الجروب*',
        quoted: message
    });
}

await showTyping(sock, chatId);
return sock.sendMessage(chatId, { 
    text: '*أمر غلط — استخدم .chatbot عشان تشوف الاستخدام*',
    quoted: message
});

}

async function handleChatbotResponse(sock, chatId, message, userMessage, senderId) {
const data = loadUserGroupData();
if (!data.chatbot[chatId]) return;

try {

    await showTyping(sock, chatId);

    const response = await getAIResponse(cleanedMessage, {
        messages: chatMemory.messages.get(senderId),
        userInfo: chatMemory.userInfo.get(senderId)
    });

    if (!response) {
        await sock.sendMessage(chatId, { 
            text: "استنى أفكر شوية… 🤔\nحاسس إني مش عارف أرد دلوقتي.",
            quoted: message
        });
        return;
    }

    await new Promise(resolve => setTimeout(resolve, getRandomDelay()));

    await sock.sendMessage(chatId, {
        text: response
    }, {
        quoted: message
    });

} catch (error) {
    console.error('❌ Error in chatbot response:', error.message);
    
    if (error.message && error.message.includes('No sessions')) {
        console.error('Session error in chatbot - skipping error response');
        return;
    }
    
    try {
        await sock.sendMessage(chatId, { 
            text: "أوبا 😅 لخبطت شوية… جرب تكتب تاني.",
            quoted: message
        });
    } catch (sendError) {
        console.error('Failed to send chatbot error message:', sendError.message);
    }
}

}

module.exports = {
handleChatbotCommand,
handleChatbotResponse
};