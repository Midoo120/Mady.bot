const { bots } = require('../lib/antilink');
const { setAntilink, getAntilink, removeAntilink } = require('../lib/index');
const isAdmin = require('../lib/isAdmin');

async function handleAntilinkCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message) {
    try {
        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { 
                text: '𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❌\n\nيـاباشـا الأوامـر دي للأدمنـيـة بس 😏🔥' 
            }, { quoted: message });
            return;
        }

        const prefix = '.';
        const args = userMessage.slice(9).toLowerCase().trim().split(' ');
        const action = args[0];

        if (!action) {
            const usage = 
`𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ✨

╭───〔 إعدادات الانتي لينك 〕───╮
│
│ ${prefix}antilink on
│ ${prefix}antilink set delete | kick | warn
│ ${prefix}antilink off
│
╰────────────────────╯`;

            await sock.sendMessage(chatId, { text: usage }, { quoted: message });
            return;
        }

        switch (action) {
            case 'on':
                const existingConfig = await getAntilink(chatId, 'on');
                if (existingConfig?.enabled) {
                    await sock.sendMessage(chatId, { 
                        text: '𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ⚡\n\nالانتي لينك شغـال أصـلاً يـا نجم 😉' 
                    }, { quoted: message });
                    return;
                }
                const result = await setAntilink(chatId, 'on', 'delete');
                await sock.sendMessage(chatId, { 
                    text: result 
                    ? '𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 🔥\n\nتـم تشغيـل الانتي لينك… اللي هينزل لينك هيتفشخ 😈'
                    : '𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❌\n\nحصلت مشكـلة و معرفتش أشغّله 🥲' 
                },{ quoted: message });
                break;

            case 'off':
                await removeAntilink(chatId, 'on');
                await sock.sendMessage(chatId, { 
                    text: '𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 📴\n\nقفلت الانتي لينك… خلو الناس تنزل اللي تنزله بقا 😏' 
                }, { quoted: message });
                break;

            case 'set':
                if (args.length < 2) {
                    await sock.sendMessage(chatId, { 
                        text: 
`𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ⚙️

حـدد العقوبـة يـاباشـا:

${prefix}antilink set delete
${prefix}antilink set kick
${prefix}antilink set warn` 
                    }, { quoted: message });
                    return;
                }

                const setAction = args[1];
                if (!['delete', 'kick', 'warn'].includes(setAction)) {
                    await sock.sendMessage(chatId, { 
                        text: '𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❌\n\nاختـار delete أو kick أو warn يـا حـلو 😎' 
                    }, { quoted: message });
                    return;
                }

                const setResult = await setAntilink(chatId, 'on', setAction);
                await sock.sendMessage(chatId, { 
                    text: setResult 
                    ? `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ⚡\n\nتم تعيين العقوبة: ${setAction} 😈`
                    : '𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ❌\n\nمعرفتش أظبط الإعدادات 🥲' 
                }, { quoted: message });
                break;

            case 'get':
                const status = await getAntilink(chatId, 'on');
                const actionConfig = await getAntilink(chatId, 'on');

                await sock.sendMessage(chatId, { 
                    text: 
`𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 📊

الحالة: ${status ? 'شغـال 🔥' : 'مقفـول 📴'}
العقوبة: ${actionConfig ? actionConfig.action : 'لسه متحددش'}` 
                }, { quoted: message });
                break;

            default:
                await sock.sendMessage(chatId, { 
                    text: '𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 🤨\n\nاكتب .antilink عشان تشوف الاستخدام صح' 
                });
        }

    } catch (error) {
        console.error('Error in antilink command:', error);
        await sock.sendMessage(chatId, { 
            text: '𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 💥\n\nحصل ايرور وانا بشغـل الانتي لينك 😵' 
        });
    }
}

async function handleLinkDetection(sock, chatId, message, userMessage, senderId) {
    const antilinkSetting = getAntilinkSetting(chatId);
    if (antilinkSetting === 'off') return;

    let shouldDelete = false;

    const linkPatterns = {
        whatsappGroup: /chat\.whatsapp\.com\/[A-Za-z0-9]{20,}/i,
        whatsappChannel: /wa\.me\/channel\/[A-Za-z0-9]{20,}/i,
        telegram: /t\.me\/[A-Za-z0-9_]+/i,
        allLinks: /https?:\/\/\S+|www\.\S+|(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/\S*)?/i,
    };

    if (antilinkSetting === 'whatsappGroup') {
        if (linkPatterns.whatsappGroup.test(userMessage)) shouldDelete = true;
    } 
    else if (antilinkSetting === 'whatsappChannel' && linkPatterns.whatsappChannel.test(userMessage)) {
        shouldDelete = true;
    } 
    else if (antilinkSetting === 'telegram' && linkPatterns.telegram.test(userMessage)) {
        shouldDelete = true;
    } 
    else if (antilinkSetting === 'allLinks' && linkPatterns.allLinks.test(userMessage)) {
        shouldDelete = true;
    }

    if (shouldDelete) {
        const quotedMessageId = message.key.id;
        const quotedParticipant = message.key.participant || senderId;

        await sock.sendMessage(chatId, {
            delete: { 
                remoteJid: chatId, 
                fromMe: false, 
                id: quotedMessageId, 
                participant: quotedParticipant 
            },
        });

        const mentionedJidList = [senderId];
        await sock.sendMessage(chatId, { 
            text: `𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 🚫

استنى يـا نجم… اللينكات ممنوعـة هنا ❌
@${senderId.split('@')[0]} خُد بالك المرة الجاية 😏`,
            mentions: mentionedJidList 
        });
    }
}

module.exports = {
    handleAntilinkCommand,
    handleLinkDetection,
};