const isAdmin = require('../lib/isAdmin');

async function tagNotAdminCommand(sock, chatId, senderId, message) {
try {
const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

    // 🤖 لو البوت مش أدمن
    if (!isBotAdmin) {
        await sock.sendMessage(chatId, {
            text:

`❌ البوت مش أدمن!

📌 لازم تخلّي البوت أدمن الأول
علشان يقدر يعمل منشن للأعضاء 👮‍♂️`
}, { quoted: message });
return;
}

    // 👑 لو المستخدم مش أدمن
    if (!isSenderAdmin) {
        await sock.sendMessage(chatId, {
            text:

`❌ مش مسموح!

الأمر ده للأدمن بس 👮‍♂️

لو محتاج تستخدمه،
اطلب من أحد الأدمن ينفذه 👍`
}, { quoted: message });
return;
}

    // 📋 بيانات الجروب
    const groupMetadata = await sock.groupMetadata(chatId);
    const participants = groupMetadata.participants || [];

    // 👥 الأعضاء اللي مش أدمن
    const nonAdmins = participants
        .filter(p => !p.admin)
        .map(p => p.id);

    if (nonAdmins.length === 0) {
        await sock.sendMessage(chatId, {
            text:

`✅ كل الأعضاء أدمن!

مفيش أعضاء عاديين أعملهم منشن 🎉`
}, { quoted: message });
return;
}

    // 📢 رسالة المنشن
    let text =

`🔊 نداء للأعضاء غير الأدمن:

━━━━━━━━━━━━━━━
👥 الحضور بسرعة يحبايبي :

`;

    nonAdmins.forEach(jid => {
        text += `➤ @${jid.split('@')[0]}\n`;
    });

    text += `\n━━━━━━━━━━━━━━━

📌 تم المنشن بواسطة الأدمن 👑`;

    await sock.sendMessage(chatId, {
        text,
        mentions: nonAdmins
    }, { quoted: message });

} catch (error) {
    console.error('Error in tagnotadmin command:', error);

    await sock.sendMessage(chatId, {
        text:

`❌ حصل خطأ أثناء المنشن

البوت فشل يعمل تاج للأعضاء…
حاول تاني بعد شوية ⚠️`
}, { quoted: message });
}
}

module.exports = tagNotAdminCommand;