const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

function loadState() {
	try {
		const raw = fs.readFileSync(path.join(__dirname, '..', 'data', 'mention.json'), 'utf8');
		return JSON.parse(raw);
	} catch {
		return { enabled: false, assetPath: '', type: 'text' };
	}
}

function saveState(state) {
	fs.writeFileSync(
		path.join(__dirname, '..', 'data', 'mention.json'),
		JSON.stringify(state, null, 2)
	);
}

/*━━━━━━━━━━━━━━━
   DETECTION
━━━━━━━━━━━━━━━*/

async function handleMentionDetection(sock, chatId, message) {
	try {
		if (message.key?.fromMe) return;

		const state = loadState();
		if (!state.enabled) return;

		const rawId = sock.user?.id || '';
		const botNum = rawId.split('@')[0].split(':')[0];

		const mentioned =
			message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

		const isBotMentioned = mentioned.some(j =>
			j.includes(botNum)
		);

		if (!isBotMentioned) return;

		/*──── الرد ────*/

		if (!state.assetPath) {
			await sock.sendMessage(chatId, {
				text:
`𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ✨
╭━━━〔 ناديتني؟ 〕━━━╮
ايه يا عم بتمنشن ليه 😏
قول عايز ايه وانا حاضر 👑
╰━━━━━━━━━━━━━━━━╯`
			}, { quoted: message });
			return;
		}

		const assetPath = path.join(__dirname, '..', state.assetPath);

		if (!fs.existsSync(assetPath)) {
			await sock.sendMessage(chatId, {
				text:
`𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ⚠️
╭━━━〔 خطأ 〕━━━╮
الملف مش موجود 😅
ظبطه تاني يا مالك
╰━━━━━━━━━━━━╯`
			}, { quoted: message });
			return;
		}

		if (state.type === 'sticker') {
			await sock.sendMessage(
				chatId,
				{ sticker: fs.readFileSync(assetPath) },
				{ quoted: message }
			);
		}

		else if (state.type === 'image') {
			await sock.sendMessage(
				chatId,
				{ image: fs.readFileSync(assetPath) },
				{ quoted: message }
			);
		}

		else if (state.type === 'video') {
			await sock.sendMessage(
				chatId,
				{
					video: fs.readFileSync(assetPath),
					gifPlayback: true
				},
				{ quoted: message }
			);
		}

		else if (state.type === 'audio') {
			await sock.sendMessage(
				chatId,
				{
					audio: fs.readFileSync(assetPath),
					mimetype: state.mimetype || 'audio/mpeg',
					ptt: state.ptt || false
				},
				{ quoted: message }
			);
		}

		else if (state.type === 'text') {
			await sock.sendMessage(
				chatId,
				{
					text: fs.readFileSync(assetPath, 'utf8')
				},
				{ quoted: message }
			);
		}

	} catch (err) {
		console.error(err);
	}
}

/*━━━━━━━━━━━━━━━
   TOGGLE
━━━━━━━━━━━━━━━*/

async function mentionToggleCommand(sock, chatId, message, args, isOwner) {

	if (!isOwner) {
		return sock.sendMessage(chatId, {
			text:
`𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 🚫
╭━━━〔 ممنوع 〕━━━╮
الأمر ده للمالك بس 😎
متجيش جنب إعداداتي تاني
╰━━━━━━━━━━━━╯`
		}, { quoted: message });
	}

	const onoff = (args || '').trim().toLowerCase();

	if (!['on','off'].includes(onoff)) {
		return sock.sendMessage(chatId, {
			text:
`𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 📜
╭━━━〔 الاستخدام 〕━━━╮
.mention on
.mention off
╰━━━━━━━━━━━━━━╯`
		}, { quoted: message });
	}

	const state = loadState();
	state.enabled = onoff === 'on';
	saveState(state);

	return sock.sendMessage(chatId, {
		text:
`𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ⚙️
╭━━━〔 تم التنفيذ 〕━━━╮
نظام المنشن بقى
${state.enabled ? 'شغال 🔥' : 'مقفول ❌'}
╰━━━━━━━━━━━━━━━━╯`
	}, { quoted: message });
}

/*━━━━━━━━━━━━━━━
   SET MEDIA
━━━━━━━━━━━━━━━*/

async function setMentionCommand(sock, chatId, message, isOwner) {

	if (!isOwner) {
		return sock.sendMessage(chatId, {
			text: 'الأمر ده للمالك بس 👑'
		}, { quoted: message });
	}

	const ctx = message.message?.extendedTextMessage?.contextInfo;
	const qMsg = ctx?.quotedMessage;

	if (!qMsg) {
		return sock.sendMessage(chatId, {
			text:
`𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 📌
╭━━━〔 تنبيه 〕━━━╮
رد على صورة / ملصق / فيديو
علشان أحطه رد منشن
╰━━━━━━━━━━━━╯`
		}, { quoted: message });
	}

	let type = 'text', buf;

	if (qMsg.stickerMessage) type = 'sticker';
	else if (qMsg.imageMessage) type = 'image';
	else if (qMsg.videoMessage) type = 'video';
	else if (qMsg.audioMessage) type = 'audio';
	else if (qMsg.conversation || qMsg.extendedTextMessage?.text) {
		type = 'text';
		buf = Buffer.from(
			qMsg.conversation ||
			qMsg.extendedTextMessage?.text
		);
	}

	if (!buf && type !== 'text') {

		const media = qMsg[`${type}Message`];
		const stream = await downloadContentFromMessage(media, type);
		const chunks = [];

		for await (const chunk of stream) chunks.push(chunk);
		buf = Buffer.concat(chunks);
	}

	const ext =
		type === 'sticker' ? 'webp' :
		type === 'image' ? 'jpg' :
		type === 'video' ? 'mp4' :
		type === 'audio' ? 'mp3' :
		'txt';

	const outName = `mention_custom.${ext}`;
	const outPath = path.join(__dirname, '..', 'assets', outName);

	fs.writeFileSync(outPath, buf);

	const state = loadState();
	state.assetPath = `assets/${outName}`;
	state.type = type;
	saveState(state);

	return sock.sendMessage(chatId, {
		text:
`𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ ✅
╭━━━〔 تم الحفظ 〕━━━╮
رد المنشن اتغير بنجاح 😎
أي حد هيمنشني هرد عليه بيه
╰━━━━━━━━━━━━━━╯`
	}, { quoted: message });
}

module.exports = {
	handleMentionDetection,
	mentionToggleCommand,
	setMentionCommand
};