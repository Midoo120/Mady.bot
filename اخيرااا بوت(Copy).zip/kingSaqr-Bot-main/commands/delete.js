const isAdmin = require('../lib/isAdmin');
const store = require('../lib/lightweight_store');

const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

async function deleteCommand(sock, chatId, message, senderId) {
    try {

        // ───────────── فحص الأدمن ─────────────
        const { isSenderAdmin, isBotAdmin } =
            await isAdmin(sock, chatId, senderId);

        if (!isBotAdmin) {
            return await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ⚠️ صلاحيات ناقصة 〕━━━╮

لازم تخلّي البوت أدمن  
عشان يقدر يمسح الرسائل 🧹

╰━━━〔 🤖 ${botName} 〕━━━╯`
            }, { quoted: message });
        }

        if (!isSenderAdmin) {
            return await sock.sendMessage(chatId, {
                text:
`╭━━━〔 🚫 مفيش صلاحية 〕━━━╮

الأمر ده للأدمن بس 👑

╰━━━〔 🤖 ${botName} 〕━━━╯`
            }, { quoted: message });
        }

        // ───────────── قراءة الأمر ─────────────
        const text =
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text ||
            '';

        const parts = text.trim().split(/\s+/);
        let countArg = null;

        if (parts.length > 1) {
            const num = parseInt(parts[1]);
            if (!isNaN(num) && num > 0) {
                countArg = Math.min(num, 50);
            }
        }

        const ctx =
            message.message?.extendedTextMessage?.contextInfo || {};

        const repliedUser = ctx.participant || null;
        const mentioned =
            Array.isArray(ctx.mentionedJid) &&
            ctx.mentionedJid.length > 0
                ? ctx.mentionedJid[0]
                : null;

        if (countArg === null && repliedUser) countArg = 1;
        if (countArg === null && mentioned) countArg = 1;

        if (!countArg) {
            return await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ❌ استخدام خاطئ 〕━━━╮

🧾 أمثلة:

• .del 5  
↳ مسح آخر 5 رسائل من الجروب

• .del 3 @user  
↳ مسح 3 رسائل من شخص

• رد + .del 2  
↳ مسح من الشخص المردود عليه

╰━━━〔 🤖 ${botName} 〕━━━╯`
            }, { quoted: message });
        }

        // ───────────── تحديد الهدف ─────────────
        let targetUser = null;
        let deleteGroup = false;

        if (repliedUser) {
            targetUser = repliedUser;
        } else if (mentioned) {
            targetUser = mentioned;
        } else {
            deleteGroup = true;
        }

        const chatMessages =
            Array.isArray(store.messages[chatId])
                ? store.messages[chatId]
                : [];

        const toDelete = [];

        for (
            let i = chatMessages.length - 1;
            i >= 0 && toDelete.length < countArg;
            i--
        ) {
            const m = chatMessages[i];

            if (m.key.id === message.key.id) continue;
            if (m.message?.protocolMessage) continue;

            const participant =
                m.key.participant || m.key.remoteJid;

            if (
                deleteGroup ||
                participant === targetUser
            ) {
                toDelete.push(m);
            }
        }

        if (toDelete.length === 0) {
            return await sock.sendMessage(chatId, {
                text:
`╭━━━〔 ⚠️ مفيش رسائل 〕━━━╮

ملقتش رسائل كفاية للمسح 🧹

╰━━━〔 🤖 ${botName} 〕━━━╯`
            }, { quoted: message });
        }

        // ───────────── تنفيذ المسح ─────────────
        for (const m of toDelete) {
            try {
                await sock.sendMessage(chatId, {
                    delete: {
                        remoteJid: chatId,
                        fromMe: false,
                        id: m.key.id,
                        participant:
                            m.key.participant ||
                            m.key.remoteJid
                    }
                });

                await new Promise(r =>
                    setTimeout(r, 250)
                );
            } catch {}
        }

        // ───────────── رسالة تأكيد ─────────────
        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 🧹 تم المسح 〕━━━╮

✅ تم مسح ${toDelete.length} رسالة

👑 بواسطة:
@${senderId.split('@')[0]}

╰━━━〔 🤖 ${botName} 〕━━━╯`,
            mentions: [senderId]
        });

    } catch (err) {
        console.error(err);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ خطأ 〕━━━╮

فشل مسح الرسائل 😢  
حاول تاني بعد شوية

╰━━━〔 🤖 ${botName} 〕━━━╯`
        }, { quoted: message });
    }
}

module.exports = deleteCommand;