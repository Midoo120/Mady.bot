async function groupInfoCommand(sock, chatId, msg) {
    try {

        const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

        // 📊 بيانات الجروب
        const groupMetadata = await sock.groupMetadata(chatId);

        // 🖼️ صورة الجروب
        let pp;
        try {
            pp = await sock.profilePictureUrl(chatId, 'image');
        } catch {
            pp = 'https://i.imgur.com/2wzGhpF.jpeg';
        }

        // 👮 الأدمنية
        const participants = groupMetadata.participants;
        const groupAdmins = participants.filter(p => p.admin);

        const listAdmin = groupAdmins
            .map((v, i) => `│ ${i + 1} ➛ @${v.id.split('@')[0]}`)
            .join('\n');

        // 👑 المالك
        const owner =
            groupMetadata.owner ||
            groupAdmins.find(p => p.admin === 'superadmin')?.id ||
            chatId.split('-')[0] + '@s.whatsapp.net';

        // 📝 الوصف
        const description =
            groupMetadata.desc?.toString() || 'مفيش وصف للجروب 😅';

        // 📜 الرسالة المزخرفة
        const text = `
╭━━━〔 📊 ${botName} 〕━━━╮

│ 🆔 ايدي الجروب:
│ ${groupMetadata.id}

├━━━━━━━━━━━━━━━━

│ 🏷️ اسم الجروب:
│ ${groupMetadata.subject}

├━━━━━━━━━━━━━━━━

│ 👥 عدد الأعضاء:
│ ${participants.length}

├━━━━━━━━━━━━━━━━

│ 👑 مالك الجروب:
│ @${owner.split('@')[0]}

├━━━━━━━━━━━━━━━━

│ 👮 الأدمنية:
${listAdmin || '│ مفيش أدمنية'}

├━━━━━━━━━━━━━━━━

│ 📌 وصف الجروب:
│ ${description}

╰━━━━━━━━━━━━━━━━━━╯
`.trim();

        // 📤 إرسال الرسالة
        await sock.sendMessage(chatId, {
            image: { url: pp },
            caption: text,
            mentions: [...groupAdmins.map(v => v.id), owner]
        });

    } catch (error) {
        console.error('Error in groupinfo command:', error);

        await sock.sendMessage(chatId, {
            text:
`╭━━━〔 ❌ 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 〕━━━╮

حصل خطأ وأنا بجيب معلومات الجروب 😢

╰━━━━━━━━━━━━━━━━━━╯`
        });
    }
}

module.exports = groupInfoCommand;