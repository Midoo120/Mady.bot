const TicTacToe = require('../lib/tictactoe');

const games = {};

async function tictactoeCommand(sock, chatId, senderId, text) {
    try {

        // 🧠 لو اللاعب بالفعل في جيم
        if (Object.values(games).find(room =>
            room.id.startsWith('tictactoe') &&
            [room.game.playerX, room.game.playerO].includes(senderId)
        )) {
            await sock.sendMessage(chatId, {
                text: '❌ إنت لسه في جيم شغالة!\nاكتب *surrender* لو عايز تستسلم.'
            });
            return;
        }

        // 🔍 البحث عن روم انتظار
        let room = Object.values(games).find(room =>
            room.state === 'WAITING' &&
            (text ? room.name === text : true)
        );

        if (room) {

            // ✅ دخول لاعب تاني
            room.o = chatId;
            room.game.playerO = senderId;
            room.state = 'PLAYING';

            const arr = room.game.render().map(v => ({
                'X': '❎',
                'O': '⭕',
                '1': '1️⃣',
                '2': '2️⃣',
                '3': '3️⃣',
                '4': '4️⃣',
                '5': '5️⃣',
                '6': '6️⃣',
                '7': '7️⃣',
                '8': '8️⃣',
                '9': '9️⃣',
            }[v]));

            const str = `
🎮┃لعبة XO بدأت!
━━━━━━━━━━━━━━

🎲 الدور على:
@${room.game.currentTurn.split('@')[0]}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

📌 قوانين اللعبة:
• اعمل 3 رموز جنب بعض عشان تكسب
• اكتب رقم (1-9) عشان تلعب
• اكتب *surrender* عشان تستسلم

🦅 Powered By King Saqr
`;

            await sock.sendMessage(chatId, {
                text: str,
                mentions: [
                    room.game.currentTurn,
                    room.game.playerX,
                    room.game.playerO
                ]
            });

        } else {

            // 🆕 إنشاء روم جديدة
            room = {
                id: 'tictactoe-' + (+new Date),
                x: chatId,
                o: '',
                game: new TicTacToe(senderId, 'o'),
                state: 'WAITING'
            };

            if (text) room.name = text;

            await sock.sendMessage(chatId, {
                text:
`⏳ جارِ انتظار لاعب تاني...

اكتب:
*.ttt ${text || ''}*
عشان تدخل الجيم 🎮`
            });

            games[room.id] = room;
        }

    } catch (error) {
        console.error('TTT Start Error:', error);

        await sock.sendMessage(chatId, {
            text: '❌ حصل خطأ أثناء تشغيل اللعبة.'
        });
    }
}

async function handleTicTacToeMove(sock, chatId, senderId, text) {
    try {

        const room = Object.values(games).find(room =>
            room.id.startsWith('tictactoe') &&
            [room.game.playerX, room.game.playerO].includes(senderId) &&
            room.state === 'PLAYING'
        );

        if (!room) return;

        const isSurrender = /^(surrender|give up)$/i.test(text);

        if (!isSurrender && !/^[1-9]$/.test(text)) return;

        if (senderId !== room.game.currentTurn && !isSurrender) {
            await sock.sendMessage(chatId, {
                text: '❌ مش دورك دلوقتي!'
            });
            return;
        }

        let ok = isSurrender ? true : room.game.turn(
            senderId === room.game.playerO,
            parseInt(text) - 1
        );

        if (!ok) {
            await sock.sendMessage(chatId, {
                text: '❌ الخانة دي متاخدة قبل كده.'
            });
            return;
        }

        let winner = room.game.winner;
        let isTie = room.game.turns === 9;

        const arr = room.game.render().map(v => ({
            'X': '❎',
            'O': '⭕',
            '1': '1️⃣',
            '2': '2️⃣',
            '3': '3️⃣',
            '4': '4️⃣',
            '5': '5️⃣',
            '6': '6️⃣',
            '7': '7️⃣',
            '8': '8️⃣',
            '9': '9️⃣',
        }[v]));

        // 🏳️ استسلام
        if (isSurrender) {
            winner =
                senderId === room.game.playerX
                    ? room.game.playerO
                    : room.game.playerX;

            await sock.sendMessage(chatId, {
                text:
`🏳️ @${senderId.split('@')[0]} استسلم!

🏆 الفائز:
@${winner.split('@')[0]}`,
                mentions: [senderId, winner]
            });

            delete games[room.id];
            return;
        }

        let status;

        if (winner) {
            status = `🏆 الفائز: @${winner.split('@')[0]}`;
        } else if (isTie) {
            status = `🤝 تعادل!`;
        } else {
            status =
`🎲 الدور على:
@${room.game.currentTurn.split('@')[0]}`;
        }

        const str = `
🎮┃لعبة XO
━━━━━━━━━━━━━━

${status}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

❎:
@${room.game.playerX.split('@')[0]}

⭕:
@${room.game.playerO.split('@')[0]}

${!winner && !isTie ?
'اكتب رقم (1-9) عشان تلعب\nاكتب *surrender* عشان تستسلم' : ''}

🦅 King Saqr
`;

        const mentions = [
            room.game.playerX,
            room.game.playerO,
            ...(winner ? [winner] : [room.game.currentTurn])
        ];

        await sock.sendMessage(room.x, {
            text: str,
            mentions
        });

        if (room.x !== room.o) {
            await sock.sendMessage(room.o, {
                text: str,
                mentions
            });
        }

        if (winner || isTie) {
            delete games[room.id];
        }

    } catch (error) {
        console.error('TTT Move Error:', error);
    }
}

module.exports = {
    tictactoeCommand,
    handleTicTacToeMove
};