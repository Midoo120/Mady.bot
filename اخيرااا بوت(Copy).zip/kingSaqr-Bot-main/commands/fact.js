const axios = require('axios');

module.exports = async function (sock, chatId, message) {
    const botName = "𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬";

    try {
        // جلب حقيقة عشوائية
        const response = await axios.get(
            'https://uselessfacts.jsph.pl/random.json?language=en'
        );

        const factEn = response.data.text;

        // ترجمة باستخدام Google API مجاني
        const translateRes = await axios.get(
            `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t&q=${encodeURIComponent(factEn)}`
        );

        const factAr = translateRes.data[0][0][0];

        // الرسالة المزخرفة
        const text =
`╭━━━〔 📚 حقيقة عشوائية 〕━━━╮

🧠 ${factAr}

╰━━━〔 🤖 ${botName} 〕━━━╯`;

        await sock.sendMessage(
            chatId,
            { text },
            { quoted: message }
        );

    } catch (error) {
        console.error('Error fetching fact:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ❌ ${botName} 〕━━━╮

معرفتش أجيب حقيقة دلوقتي 😅  
جرّب تاني بعد شوية

╰━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
    }
};