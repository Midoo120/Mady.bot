async function staffCommand(sock, chatId, msg) {
    try {
        const sender = msg.key.participant || msg.key.remoteJid;
        const user = sender.split('@')[0];

        // 📊 بيانات الجروب
        const groupMetadata = await sock.groupMetadata(chatId);

        // 🖼️ صورة الجروب
        let pp;
        try {
            pp = await sock.profilePictureUrl(chatId, 'image');
        } catch {
            pp = 'https://i.imgur.com/2wzGhpF.jpeg';
        }

        // 👑 الأدمنز
        const participants = groupMetadata.participants;
        const groupAdmins = participants.filter(p => p.admin);

        const listAdmin = groupAdmins
            .map((v, i) => `│ ${i + 1} ⇢ @${v.id.split('@')[0]}`)
            .join('\n');

        // 👑 المالك
        const owner =
            groupMetadata.owner ||
            groupAdmins.find(p => p.admin === 'superadmin')?.id ||
            chatId.split('-')[0] + '@s.whatsapp.net';

        // 🧾 النص المزخرف
        const text = `
╔═══〔 👑 إداريين الجروب 〕═══╗
║
║ 🏷️ اسم الجروب:
║ 『 ${groupMetadata.subject} 』
║
╠═══〔 🛡️ طاقم الإدارة 〕═══╣
${listAdmin}
║
╠═══〔 🤖 طلب بواسطة 〕═══╣
║ 👤 @${user}
║
╚════════════════════╝
`.trim();

        // 📤 إرسال
        await sock.sendMessage(
            chatId,
            {
                image: { url: pp },
                caption: text,
                mentions: [
                    ...groupAdmins.map(v => v.id),
                    owner,
                    sender
                ]
            },
            { quoted: msg }
        );

    } catch (error) {
        console.error('Error in staff command:', error);

        await sock.sendMessage(chatId, {
            text: `❌ ياعم حصل حوار ومقدرتش أجيب الإداريين 😅`
        });
    }
}

module.exports = staffCommand;