const axios = require('axios');

let triviaGames = {};

async function startTrivia(sock, chatId) {
    if (triviaGames[chatId]) {
        await sock.sendMessage(chatId, {
            text: '⚠️ في لعبة Trivia شغالة بالفعل!\nاستنّى لما تخلص الأول ⏳'
        });
        return;
    }

    try {
        const response = await axios.get(
            'https://opentdb.com/api.php?amount=1&type=multiple'
        );

        const questionData = response.data.results[0];

        // ترتيب الاختيارات عشوائي
        const options = [
            ...questionData.incorrect_answers,
            questionData.correct_answer
        ].sort(() => Math.random() - 0.5);

        triviaGames[chatId] = {
            question: questionData.question,
            correctAnswer: questionData.correct_answer,
            options
        };

        // ترقيم الاختيارات
        const optionsText = options
            .map((opt, i) => `${i + 1}️⃣ ${opt}`)
            .join('\n');

        await sock.sendMessage(chatId, {
            text:
`🧠✨ *Trivia Time!*

❓ *السؤال:*
${questionData.question}

📌 *الاختيارات:*
${optionsText}

💬 اكتب الإجابة أو رقمها!`
        });

    } catch (error) {
        await sock.sendMessage(chatId, {
            text: '❌ حصل خطأ في جلب السؤال… جرّب تاني بعد شوية.'
        });
    }
}

async function answerTrivia(sock, chatId, answer) {
    if (!triviaGames[chatId]) {
        await sock.sendMessage(chatId, {
            text: '⚠️ مفيش لعبة Trivia شغالة دلوقتي.'
        });
        return;
    }

    const game = triviaGames[chatId];

    // لو المستخدم كتب رقم
    let chosenAnswer = answer;
    if (!isNaN(answer)) {
        const index = parseInt(answer) - 1;
        chosenAnswer = game.options[index];
    }

    if (
        chosenAnswer &&
        chosenAnswer.toLowerCase() === game.correctAnswer.toLowerCase()
    ) {
        await sock.sendMessage(chatId, {
            text:
`✅🔥 *إجابة صحيحة!*

🎉 برافو عليك!
الإجابة هي:
*${game.correctAnswer}*`
        });
    } else {
        await sock.sendMessage(chatId, {
            text:
`❌ إجابة غلط!

✔️ الإجابة الصح هي:
*${game.correctAnswer}*

حظ أوفر المرة الجاية 🎯`
        });
    }

    delete triviaGames[chatId];
}

module.exports = { startTrivia, answerTrivia };