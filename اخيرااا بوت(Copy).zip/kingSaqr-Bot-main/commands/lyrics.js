const fetch = require('node-fetch');

async function lyricsCommand(sock, chatId, songTitle, message) {

    // لو مفيش اسم أغنية
    if (!songTitle) {
        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 🎧 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ Lyrics 〕━━━╮

🔎 يسطا اكتب اسم الأغنية بعد الأمر

مثال:
lyrics اسم الأغنية

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
        return;
    }

    try {
        const apiUrl = `https://lyricsapi.fly.dev/api/lyrics?q=${encodeURIComponent(songTitle)}`;
        const res = await fetch(apiUrl);

        if (!res.ok) {
            const errText = await res.text();
            throw errText;
        }

        const data = await res.json();

        const lyrics =
            data &&
            data.result &&
            data.result.lyrics
                ? data.result.lyrics
                : null;

        // لو ملقاش كلمات
        if (!lyrics) {
            await sock.sendMessage(
                chatId,
                {
                    text:
`╭━━━〔 ❌ 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 〕━━━╮

ملقيتش كلمات للأغنية دي 👇
🎵 ${songTitle}

جرب تكتب الاسم صح أو كامل

╰━━━━━━━━━━━━━━━━━━╯`
                },
                { quoted: message }
            );
            return;
        }

        const maxChars = 4096;
        const output =
            lyrics.length > maxChars
                ? lyrics.slice(0, maxChars - 3) + '...'
                : lyrics;

        // إرسال الكلمات مزخرفة
        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 🎶 كلمات الأغنية 〕━━━╮
┃
┃ 🎤 بواسطة بوت:
┃ 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬
┃
┣━━━━━━━━━━━━━━━
${output}
┣━━━━━━━━━━━━━━━
┃ استمتع يا نجم ✨
╰━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );

    } catch (error) {
        console.error('Error in lyrics command:', error);

        await sock.sendMessage(
            chatId,
            {
                text:
`╭━━━〔 ⚠️ 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 〕━━━╮

حصلت مشكلة وانا بجيب الكلمات 😅
جرب تاني بعد شوية

╰━━━━━━━━━━━━━━━━━━╯`
            },
            { quoted: message }
        );
    }
}

module.exports = { lyricsCommand };