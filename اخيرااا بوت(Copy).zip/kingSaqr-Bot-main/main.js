// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🧹 حل نهائي لمشكلة التيمب لما السيرفر يتكتم / ENOSPC
// يعني لو المساحة المؤقتة فرقت… الكود دا بيظبط الدنيا
// ╚══════════════════════╝

const fs = require('fs');
const path = require('path');


// 📦 بنحوّل مسار التيمب من /tmp لمجلد جوه البوت
// عشان الاستضافة متقرفناش
const customTemp = path.join(process.cwd(), 'temp');

if (!fs.existsSync(customTemp))
  fs.mkdirSync(customTemp, { recursive: true });

process.env.TMPDIR = customTemp;
process.env.TEMP   = customTemp;
process.env.TMP    = customTemp;


// 🧽 منظف أوتوماتيك… كل 3 ساعات
// يمسح أي ملفات قديمة ركنت و مليتش المكان
setInterval(() => {

  fs.readdir(customTemp, (err, files) => {
    if (err) return;

    for (const file of files) {

      const filePath = path.join(customTemp, file);

      fs.stat(filePath, (err, stats) => {

        if (!err && Date.now() - stats.mtimeMs > 3 * 60 * 60 * 1000) {
          fs.unlink(filePath, () => {});
        }

      });
    }
  });

  console.log('🧹 التيمب اتمسح و الدنيا بقت فل');

}, 3 * 60 * 60 * 1000);



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// ⚙️ تحميل الإعدادات و الكونفج
// ╚══════════════════════╝

const settings = require('./settings');
require('./config.js');

const { isBanned } = require('./lib/isBanned');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🎬 مكتبات التحميل و الميديا
// ╚══════════════════════╝

const yts = require('yt-search');
const { fetchBuffer } = require('./lib/myfunc');
const fetch = require('node-fetch');
const ytdl = require('ytdl-core');
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 👑 صلاحيات المطورين الكبار
// ╚══════════════════════╝

const { isSudo } = require('./lib/index');
const isOwnerOrSudo = require('./lib/isOwner');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// ⌨️ أوامر الأوتو تايبنج و القراية التلقائية
// ╚══════════════════════╝

const {
  autotypingCommand,
  isAutotypingEnabled,
  handleAutotypingForMessage,
  handleAutotypingForCommand,
  showTypingAfterCommand
} = require('./commands/autotyping');

const {
  autoreadCommand,
  isAutoreadEnabled,
  handleAutoread
} = require('./commands/autoread');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 📜 استدعاء كل أوامر البوت
// اللي هيشيل الشغل كله فوق دماغه 😂
// ╚══════════════════════╝

const tagAllCommand = require('./commands/tagall');
const helpCommand = require('./commands/help');
const banCommand = require('./commands/ban');

const { promoteCommand } = require('./commands/promote');
const { demoteCommand } = require('./commands/demote');

const muteCommand = require('./commands/mute');
const unmuteCommand = require('./commands/unmute');

const stickerCommand = require('./commands/sticker');

const isAdmin = require('./lib/isAdmin');

const warnCommand = require('./commands/warn');
const warningsCommand = require('./commands/warnings');

const ttsCommand = require('./commands/tts');

const {
  tictactoeCommand,
  handleTicTacToeMove
} = require('./commands/tictactoe');

const {
  incrementMessageCount,
  topMembers
} = require('./commands/topmembers');

const ownerCommand = require('./commands/owner');
const deleteCommand = require('./commands/delete');

const {
  handleAntilinkCommand,
  handleLinkDetection
} = require('./commands/antilink');

const {
  handleAntitagCommand,
  handleTagDetection
} = require('./commands/antitag');

const { Antilink } = require('./lib/antilink');

const {
  handleMentionDetection,
  mentionToggleCommand,
  setMentionCommand
} = require('./commands/mention');

const memeCommand = require('./commands/meme');
const tagCommand = require('./commands/tag');
const tagNotAdminCommand = require('./commands/tagnotadmin');
const hideTagCommand = require('./commands/hidetag');

const jokeCommand = require('./commands/joke');
const quoteCommand = require('./commands/quote');
const factCommand = require('./commands/fact');

const weatherCommand = require('./commands/weather');
const newsCommand = require('./commands/news');

const kickCommand = require('./commands/kick');

const simageCommand = require('./commands/simage');
const attpCommand = require('./commands/attp');

const {
  startHangman,
  guessLetter
} = require('./commands/hangman');

const {
  startTrivia,
  answerTrivia
} = require('./commands/trivia');

const { complimentCommand } = require('./commands/compliment');
const { insultCommand } = require('./commands/insult');
const { eightBallCommand } = require('./commands/eightball');

const { lyricsCommand } = require('./commands/lyrics');

const { dareCommand } = require('./commands/dare');
const { truthCommand } = require('./commands/truth');

const { clearCommand } = require('./commands/clear');

const pingCommand = require('./commands/ping');
const aliveCommand = require('./commands/alive');

const blurCommand = require('./commands/img-blur');

const {
  welcomeCommand,
  handleJoinEvent
} = require('./commands/welcome');

const {
  goodbyeCommand,
  handleLeaveEvent
} = require('./commands/goodbye');

const githubCommand = require('./commands/github');

const {
  handleAntiBadwordCommand,
  handleBadwordDetection
} = require('./lib/antibadword');

const antibadwordCommand = require('./commands/antibadword');

const {
  handleChatbotCommand,
  handleChatbotResponse
} = require('./commands/chatbot');

const takeCommand = require('./commands/take');
// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🎭 أوامر الهزار و التفاعل و الجو اللطيف
// البوت هنا بيدخل يروش و يعمل شغل عالي 😂
// ╚══════════════════════╝

const { flirtCommand } = require('./commands/flirt');
const characterCommand = require('./commands/character');
const wastedCommand = require('./commands/wasted');
const shipCommand = require('./commands/ship');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 👥 أوامر إدارة الجروبات
// تحكم كامل… طرد… ترقيات… سيطرة 😂
// ╚══════════════════════╝

const groupInfoCommand = require('./commands/groupinfo');
const resetlinkCommand = require('./commands/resetlink');
const staffCommand = require('./commands/staff');
const unbanCommand = require('./commands/unban');

const emojimixCommand = require('./commands/emojimix');

const { handlePromotionEvent } = require('./commands/promote');
const { handleDemotionEvent } = require('./commands/demote');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🕵️ أوامر الخصوصية و الحماية
// ╚══════════════════════╝

const viewOnceCommand = require('./commands/viewonce');
const clearSessionCommand = require('./commands/clearsession');

const {
  autoStatusCommand,
  handleStatusUpdate
} = require('./commands/autostatus');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🤡 أوامر هزار و روشنة إضافية
// ╚══════════════════════╝

const { simpCommand } = require('./commands/simp');
const { stupidCommand } = require('./commands/stupid');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🖼️ أوامر الاستيكر و التعديل
// ╚══════════════════════╝

const stickerTelegramCommand = require('./commands/stickertelegram');
const textmakerCommand = require('./commands/textmaker');

const {
  handleAntideleteCommand,
  handleMessageRevocation,
  storeMessage
} = require('./commands/antidelete');

const clearTmpCommand = require('./commands/cleartmp');
const setProfilePicture = require('./commands/setpp');

const {
  setGroupDescription,
  setGroupName,
  setGroupPhoto
} = require('./commands/groupmanage');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🌐 أوامر السوشيال ميديا و التحميل
// ╚══════════════════════╝

const instagramCommand = require('./commands/instagram');
const facebookCommand = require('./commands/facebook');
const spotifyCommand = require('./commands/spotify');

const playCommand = require('./commands/play');
const tiktokCommand = require('./commands/tiktok');
const songCommand = require('./commands/song');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🤖 أوامر الذكاء الاصطناعي
// ╚══════════════════════╝

const aiCommand = require('./commands/ai');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🔗 أوامر الروابط و الأدوات
// ╚══════════════════════╝

const urlCommand = require('./commands/url');

const { handleTranslateCommand } = require('./commands/translate');
const { handleSsCommand } = require('./commands/ss');

const {
  addCommandReaction,
  handleAreactCommand
} = require('./lib/reactions');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🌙 أوامر المناسبات و الرسائل الجاهزة
// ╚══════════════════════╝

const { goodnightCommand } = require('./commands/goodnight');
const { shayariCommand } = require('./commands/shayari');
const { rosedayCommand } = require('./commands/roseday');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🎨 أوامر الميديا و التخيل
// ╚══════════════════════╝

const imagineCommand = require('./commands/imagine');
const videoCommand = require('./commands/video');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 👑 أوامر المطورين
// ╚══════════════════════╝

const sudoCommand = require('./commands/sudo');

const {
  miscCommand,
  handleHeart
} = require('./commands/misc');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🍥 أنمي و ألعاب
// ╚══════════════════════╝

const { animeCommand } = require('./commands/anime');

const {
  piesCommand,
  piesAlias
} = require('./commands/pies');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🛠️ أدوات إضافية
// ╚══════════════════════╝

const stickercropCommand = require('./commands/stickercrop');
const updateCommand = require('./commands/update');
const removebgCommand = require('./commands/removebg');

const { reminiCommand } = require('./commands/remini');
const { igsCommand } = require('./commands/igs');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// ☎️ الحمايات التلقائية
// ╚══════════════════════╝

const {
  anticallCommand,
  readState: readAnticallState
} = require('./commands/anticall');

const {
  pmblockerCommand,
  readState: readPmBlockerState
} = require('./commands/pmblocker');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// ⚙️ إعدادات عامة
// ╚══════════════════════╝

const settingsCommand = require('./commands/settings');
const soraCommand = require('./commands/sora');



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🌍 متغيرات عامة للبوت
// ╚══════════════════════╝

global.packname   = settings.packname;
global.author     = settings.author;

global.channelLink = "https://whatsapp.com/channel/0029VaxBkeeFSAt6CQafQh3h";

global.ytch = "The developer  ⏤͟͟͞͞ ◉ḾẤⅅỸ◉ ͟͞⏤";


// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// ⚙️ إعدادات القناة و التحويل
// البوت بيبعت الرسائل بشكل مُعاد توجيهه
// عشان الشكل الاحترافي و الهيبة 😎
// ╚══════════════════════╝

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
    }
};



// ╔═══𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬═══╗
// 🤖 المعالج الرئيسي للرسائل
// هنا المخ شغال… و البوت بيرد
// ╚══════════════════════╝

async function handleMessages(sock, messageUpdate, printLog) {
    try {

        const { messages, type } = messageUpdate;
        if (type !== 'notify') return;

        const message = messages[0];
        if (!message?.message) return;



        // ╔═══ قراءة تلقائية ═══╗
        // البوت يقرأ الرسالة أول ما توصل
        await handleAutoread(sock, message);



        // ╔═══ تخزين للأنـتـي ديليت ═══╗
        if (message.message) {
            storeMessage(sock, message);
        }



        // ╔═══ كشف حذف الرسائل ═══╗
        if (message.message?.protocolMessage?.type === 0) {
            await handleMessageRevocation(sock, message);
            return;
        }



        // ╔═══ بيانات أساسية ═══╗
        const chatId   = message.key.remoteJid;
        const senderId = message.key.participant || message.key.remoteJid;
        const isGroup  = chatId.endsWith('@g.us');

        const senderIsSudo = await isSudo(senderId);
        const senderIsOwnerOrSudo = await isOwnerOrSudo(senderId, sock, chatId);



        // ╔═══ ردود الأزرار ═══╗
        // لما حد يدوس زرار من البوت

        if (message.message?.buttonsResponseMessage) {

            const buttonId = message.message.buttonsResponseMessage.selectedButtonId;
            const chatId = message.key.remoteJid;



            // زرار القناة 📢
            if (buttonId === 'channel') {

                await sock.sendMessage(chatId, {
                    text:
`📢 *انضم لقناة البوت الرسمية 👑*
━━━━━━━━━━━━━━━
https://whatsapp.com/channel/0029VaxBkeeFSAt6CQafQh3h`
                }, { quoted: message });

                return;
            }



            // زرار المالك 👑
            else if (buttonId === 'owner') {

                const ownerCommand = require('./commands/owner');
                await ownerCommand(sock, chatId);
                return;
            }



            // زرار الدعم 🛠️
            else if (buttonId === 'support') {

                await sock.sendMessage(chatId, {
                    text:
`🔗 *دعم و مساعدة قناة 🤖*
━━━━━━━━━━━━━━━
https://youtube.com/@mady_elhackem?si=B1uKLO5RJVfbAEwk`
                }, { quoted: message });

                return;
            }
        }



        // ╔═══ استخراج نص الرسالة ═══╗

        const userMessage = (
            message.message?.conversation?.trim() ||
            message.message?.extendedTextMessage?.text?.trim() ||
            message.message?.imageMessage?.caption?.trim() ||
            message.message?.videoMessage?.caption?.trim() ||
            message.message?.buttonsResponseMessage?.selectedButtonId?.trim() ||
            ''
        )
        .toLowerCase()
        .replace(/\.\s+/g, '.')
        .trim();



        // ╔═══ النص الخام ═══╗
        // مهم لأوامر زي التاج

        const rawText =
            message.message?.conversation?.trim() ||
            message.message?.extendedTextMessage?.text?.trim() ||
            message.message?.imageMessage?.caption?.trim() ||
            
            
message.message?.videoMessage?.caption?.trim() ||
            '';



        // ╔═══ تسجيل الأوامر ═══╗
        // البوت بيراقب مين استخدم أمر
        // عشان اللوجات و المتابعة 👀

        if (userMessage.startsWith('.')) {
            console.log(`📝 أمر اتستخدم في ${isGroup ? 'جروب 👥' : 'خاص 📩'}: ${userMessage}`);
        }



        // ╔═══ وضع البوت ═══╗
        // عام ولا برايفت

        let isPublic = true;

        try {
            const data = JSON.parse(
                fs.readFileSync('./data/messageCount.json')
            );

            if (typeof data.isPublic === 'boolean')
                isPublic = data.isPublic;

        } catch (error) {

            console.error(
                '❌ حصلت مشكلة و احنا بنشيك على وضع البوت:',
                error
            );

            // الافتراضي = عام
        }



        const isOwnerOrSudoCheck =
            message.key.fromMe || senderIsOwnerOrSudo;



        // ╔═══ فحص الباند ═══╗

        if (isBanned(senderId) &&
            !userMessage.startsWith('.unban')) {

            // يرد أوقات بس عشان ميعملش سبام
            if (Math.random() < 0.1) {

                await sock.sendMessage(chatId, {
                    text:
`❌ إنت متبند من استخدام البوت يا نجم 🚫
━━━━━━━━━━━━━━━
لو شايف إن ده غلط…
كلم الأدمن يفكلك الباند 👑`,
                    ...channelInfo
                });
            }

            return;
        }



        // ╔═══ حركات لعبة XO ═══╗

        if (
            /^[1-9]$/.test(userMessage) ||
            userMessage.toLowerCase() === 'surrender'
        ) {

            await handleTicTacToeMove(
                sock,
                chatId,
                senderId,
                userMessage
            );

            return;
        }



        /*  
        ╔══════════════════════════════╗
        ║ 💬 رد تلقائي برايفت (مقفول) ║
        ║ ممكن تفتحه لو حبيت بعدين    ║
        ╚══════════════════════════════╝

        // Basic message response in private chat
        if (!isGroup &&
            (userMessage === 'hi' || userMessage === '