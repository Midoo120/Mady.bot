🤖 𓆩 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬ 𓆪

بوت واتساب جامد معمول بمكتبة Baileys مخصوص لإدارة الجروبات 🔥
يعني يخلي الأدمن ماسك الجروب نظام × نظام 👑
تاج للكل — ميوت — تحكم كامل — وأوامر كتير فشخ هتفيد أي جروب 😎

---

<div align="center"> 
  <a href="https://git.io/typing-svg"> 
    <img src="https://readme-typing-svg.demolab.com?font=Ribeye&size=50&pause=1000&color=33ff00&center=true&width=910&height=100&lines=Knight-Bot;Multi+Device+Whatsapp+Bot;Coded+By+Professor" alt="Typing SVG" />
  </a> 
</div> <div align="center"> 
  <a href="https://youtube.com/@mr_unique_hacker"> 
    <img src="https://github.com/mruniquehacker/Knightbot-MD/blob/main/assets/bot_image.jpg" alt="King Saqr" height="300"> 
  </a> 
</div>---

🚀 خطوات التشغيل

الخطوة 1 — اعمل Fork للريبو

دوس عالزرار اللي تحت عشان تنسخ مشروع 𓇢𓆸𝑴𝒂♪𝒅𝒚➛‬على حسابك 👇

<div align="center">
  <a href="https://youtube.com/@mady_elhackem?si=B1uKLO5RJVfbAEwk">
    <img src="https://img.shields.io/badge/Fork-Repository-blue?style=for-the-badge" alt="Fork the repository"/>
  </a>
</div>---

الخطوة 2 — هات Pair Code

شغّل البوت ووصل واتساب بتاعك بالكود 👇

<div align="center">
  <a href="https://knight-bot-paircode.onrender.com" target="_blank">
    <img src="https://img.shields.io/badge/GET%20PAIR%20CODE-Easy%20Method-ff4d4d?style=for-the-badge" alt="Generate Pair Code"/>
  </a>
</div>بعد ما تحمّل ملف creds.json
ارفعه جوا فولدر session

---

الخطوة 3 — التشغيل

لو عايز شرح تفصيلي 👇

<div align="center">
  <a href="https://youtu.be/-oz_u1iMgf8">
    <img src="https://img.shields.io/badge/Deploy Tutorial-dc3545?style=for-the-badge&logo=youtube" alt="YouTube Link"/>
  </a>
  <a href="https://bot-hosting.net/?aff=1068419752923508776">
    <img src="https://img.shields.io/badge/Deploy on Panel-28a745?style=for-the-badge" alt="Deploy on Panel"/>
  </a>
</div>---

تشغيل على VPS

<div align="center">
  <a href="https://client.petrosky.io/aff.php?aff=394" target="_blank">
    <img src="https://img.shields.io/badge/petrosky vps-0078E7?style=for-the-badge" alt="petrosky vps"/>
  </a>
</div>---

Panels جاهزة

<div align="center">
<a href="https://dashboard.katabump.com/auth/login#d6b7d6" target="_blank">
  <img src="https://img.shields.io/badge/Katabump-D6B7D6?style=for-the-badge&logo=server&logoColor=black" alt="Katabump"/>
</a>
</div>---

انضم لينا

<div align="center">
  <a href="https://t.me/+3QhFUZHx-nhhZmY1">
    <img src="https://img.shields.io/badge/Join%20Telegram-0078E7?style=for-the-badge&logo=telegram&logoColor=white" alt="Join Telegram"/>
  </a>
  <a href="https://whatsapp.com/channel/0029Va90zAnIHphOuO8Msp3A">
    <img src="https://img.shields.io/badge/Join%20WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" alt="Join WhatsApp"/>
  </a>
</div>---

⚙️ المميزات

- تاج لكل الأعضاء ".tagall"
- أوامر للأدمن بس 👮
- ألعاب زي XO 🎮
- تحويل نص لصوت ".tts" 🎙️
- عمل استيكر ".sticker" 🧷
- مانع روابط 🚫
- نظام تحذيرات ⚠️

---

📖 عن البوت

بوت King Saqr معمول يساعد أدمنز الجروبات الكبيرة
ويديهم تحكم كامل في الإدارة 💪

شغال بمكتبة Baileys
ويدعم Multi-Device

خفيف وسهل تعدل عليه وتزوّد أوامر براحتك 👨‍💻

---

🛠️ التسطيب

المتطلبات

- Node.js
- Git

الطريقة

1. Clone المشروع

git clone https://github.com/mruniquehacker/Knightbot-MD.git
cd Knightbot-MD

2. تسطيب المكتبات

npm install

3. تشغيل البوت

node index.js

4. اعمل Scan للـ QR
   ووصل واتساب ✔️

---

📄 License

المشروع برخصة MIT

---

🙌 المساهمات

أي اقتراح أو تطوير مرحب بيه جدًا 🤝

---

🌟 الدعم

لو البوت عجبك اعمله Star ⭐

---

Credits

- Professor
- Baileys
- TechGod143
- Dgxeon

---

⚠️ تحذير مهم

البوت للتعليم بس ❗
ممكن يعرّض رقمك للباند
استخدمه على مسؤوليتك

---

📝 قانوني

- مش تابع لواتساب
- بلاش سبام
- متستخدموش في حاجات مخالفة

---

© 2024 Professor — All Rights Reserved